import gc
import hashlib
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import traceback
import zipfile
from datetime import datetime, timedelta
from html import unescape
from urllib.parse import quote_plus, urlparse
from urllib.request import Request, urlopen


class KiraActionsMixin:
    def _seatbelt_available(self):
        return sys.platform == "darwin" and bool(shutil.which("sandbox-exec"))

    def _seatbelt_escape(self, value):
        return str(value or "").replace("\\", "\\\\").replace('"', '\\"')

    def _seatbelt_path_forms(self, paths, form="subpath"):
        entries = []
        for path in paths or []:
            if not path:
                continue
            resolved = os.path.abspath(os.path.expanduser(str(path)))
            entries.append(f'({form} "{self._seatbelt_escape(resolved)}")')
        return " ".join(entries)

    def _seatbelt_profile(self, mode="read_only", read_paths=None, write_paths=None, network=False):
        temp_paths = [
            tempfile.gettempdir(),
            "/tmp",
            "/private/tmp",
            "/private/var/folders"
        ]
        workspace_write_paths = [
            getattr(self, "agentic_workspace", ""),
            getattr(self, "agentic_logs_path", "")
        ]

        allowed_writes = list(temp_paths)
        if mode in {"artifact", "web"}:
            allowed_writes.extend([
                getattr(self, "agentic_workspace", ""),
                getattr(self, "agentic_logs_path", ""),
                getattr(self, "architect_workspace", ""),
                getattr(self, "mcp_workspace", "")
            ])
        elif mode == "project":
            allowed_writes.extend(workspace_write_paths)
            allowed_writes.extend(write_paths or [])
        elif mode == "mutation":
            allowed_writes.extend(write_paths or [])

        read_clause = "(allow file-read*)"
        if read_paths:
            read_clause = "(allow file-read* " + self._seatbelt_path_forms(read_paths) + ")"

        write_clause = ""
        allowed_writes = [path for path in dict.fromkeys(allowed_writes) if path]
        if allowed_writes:
            write_clause = "(allow file-write* " + self._seatbelt_path_forms(allowed_writes) + ")"

        network_clause = "(allow network*)\n" if network or mode == "web" else ""
        return (
            "(version 1)\n"
            "(deny default)\n"
            "(allow process*)\n"
            "(allow sysctl-read)\n"
            "(allow mach-lookup)\n"
            + network_clause
            + read_clause
            + "\n"
            + write_clause
            + "\n"
        )

    def _run_seatbelt_subprocess(
        self,
        command,
        *,
        mode="read_only",
        shell=False,
        cwd=None,
        timeout=20,
        input_text=None,
        write_paths=None,
        read_paths=None,
        network=False
    ):
        if shell:
            runner = ["/bin/zsh", "-lc", str(command or "")]
            display_command = str(command or "")
        else:
            runner = [str(part) for part in command]
            display_command = " ".join(shlex.quote(part) for part in runner)

        use_seatbelt = self._seatbelt_available()
        full_command = runner
        profile = ""
        if use_seatbelt:
            profile = self._seatbelt_profile(
                mode=mode,
                read_paths=read_paths,
                write_paths=write_paths,
                network=network
            )
            full_command = ["sandbox-exec", "-p", profile] + runner

        res = subprocess.run(
            full_command,
            cwd=cwd,
            input=input_text,
            capture_output=True,
            text=True,
            timeout=timeout
        )

        if (
            use_seatbelt
            and res.returncode == 71
            and "sandbox_apply" in ((res.stderr or "") + (res.stdout or ""))
        ):
            self._log_agentic_event("seatbelt_unavailable_fallback", {
                "mode": mode,
                "command": display_command,
                "reason": self._truncate((res.stderr or res.stdout or "").strip(), 1000)
            })
            res = subprocess.run(
                runner,
                cwd=cwd,
                input=input_text,
                capture_output=True,
                text=True,
                timeout=timeout
            )
            setattr(res, "kira_seatbelt_mode", "fallback_unavailable")
            return res

        setattr(res, "kira_seatbelt_mode", mode if use_seatbelt else "unavailable")
        return res

    def _handle_ui_control_prompt(self, prompt, chat_id):
        text = re.sub(r"\s+", " ", str(prompt or "").strip().lower())
        if not text:
            return False

        open_menu = any(phrase in text for phrase in [
            "open kira menu", "show kira menu", "open the kira menu",
            "show the kira menu", "open menu", "show menu"
        ])
        close_menu = any(phrase in text for phrase in [
            "close kira menu", "hide kira menu", "close the kira menu",
            "hide the kira menu", "close menu", "hide menu"
        ])

        if open_menu or close_menu:
            action = "close_kira_menu" if close_menu else "open_kira_menu"
            message = "Closing KIRA menu." if close_menu else "Opening KIRA menu."
            self._append_chat_message(chat_id, "user", str(prompt or "").strip(), "User")
            self._append_chat_message(chat_id, "assistant", message, "KIRA OS")
            self.response_queue.put({
                "type": "ui_action",
                "action": action,
                "content": message,
                "model_used": "KIRA OS",
                "chat_id": chat_id
            })
            self.response_queue.put({
                "type": "message",
                "content": message,
                "model_used": "KIRA OS",
                "chat_id": chat_id
            })
            return True

        quit_kira = any(phrase in text for phrase in [
            "close kira os", "quit kira os", "exit kira os", "shutdown kira os",
            "close this app", "quit this app", "close the app", "quit the app",
            "close this window", "quit application", "close it now", "quit it now"
        ])

        if quit_kira:
            message = "Closing KIRA OS."
            self._append_chat_message(chat_id, "user", str(prompt or "").strip(), "User")
            self._append_chat_message(chat_id, "assistant", message, "KIRA OS")
            self.response_queue.put({
                "type": "ui_action",
                "action": "quit_kira_os",
                "content": message,
                "model_used": "KIRA OS",
                "chat_id": chat_id
            })
            self.response_queue.put({
                "type": "message",
                "content": message,
                "model_used": "KIRA OS",
                "chat_id": chat_id
            })
            return True

        open_live = (
            any(phrase in text for phrase in [
                "open live", "show live", "start live", "activate live",
                "live view", "live monitor", "computer view", "system live",
                "what is going on in my computer", "what's going on in my computer",
                "whats going on in my computer"
            ])
            and not any(word in text for word in ["virus", "malware", "scan for threats"])
        )

        close_live = any(phrase in text for phrase in [
            "close live", "hide live", "stop live view", "turn off live monitor"
        ])

        if not open_live and not close_live:
            return False

        action = "close_live_monitor" if close_live else "open_live_monitor"
        message = "Closing Live computer view." if close_live else "Opening Live computer view. It will keep refreshing read-only."

        self._append_chat_message(chat_id, "user", str(prompt or "").strip(), "User")
        self._append_chat_message(chat_id, "assistant", message, "KIRA OS")
        self.response_queue.put({
            "type": "ui_action",
            "action": action,
            "content": message,
            "model_used": "KIRA OS",
            "chat_id": chat_id
        })
        self.response_queue.put({
            "type": "message",
            "content": message,
            "model_used": "KIRA OS",
            "chat_id": chat_id
        })
        self._maybe_update_personalization_rag(force=False)
        return True

    def _handle_slash_command(self, prompt, mode, selected_model, chat_id):
        text = str(prompt or "").strip()
        if not text.startswith("/"):
            return None

        if text in {"/", "/help", "/commands"}:
            return self._slash_help_text()

        try:
            tokens = shlex.split(text)
        except ValueError:
            tokens = text.split()

        if not tokens:
            return self._slash_help_text()

        command = tokens[0][1:].strip().lower()
        rest = text[len(tokens[0]):].strip()

        if command in {"quick", "learned", "auto"}:
            return self._run_learned_quick_command(rest, mode, selected_model, chat_id)

        if command in {"open", "launch"}:
            if not rest:
                return "Open what app, file, folder, or URL? Example: `/open Draw Things` or `/open ~/Downloads/file.pdf`"
            return self._open_target_tool(rest)

        if command in {"close", "quit"}:
            if not rest:
                return "Close what app? Example: `/close Safari` or `/close Draw Things`"
            return self._close_target_tool(rest)

        return None

    def _handle_natural_open_close(self, prompt, chat_id):
        text = re.sub(r"\s+", " ", str(prompt or "").strip())
        lowered = text.lower()
        if not text:
            return ""

        open_match = re.match(r"(?i)^(?:please\s+)?(?:open|launch|show)\s+(.+?)\s*$", text)
        close_match = re.match(r"(?i)^(?:please\s+)?(?:close|quit)\s+(.+?)\s*$", text)

        if open_match and not any(word in lowered for word in ["report", "it", "that", "this"]):
            target = open_match.group(1).strip()
            if target:
                return self._open_target_tool(target)

        if close_match:
            target = close_match.group(1).strip()
            if target:
                return self._close_target_tool(target)

        return ""

    def _parse_browse_web_target(self, target):
        text = re.sub(r"\s+", " ", str(target or "").strip())
        lowered = text.lower()

        if lowered in {"web", "internet", "google"}:
            return "https://www.google.com"

        if lowered in {"youtube", "yt"}:
            return "https://www.youtube.com"

        youtube_match = re.match(r"^(?:youtube|yt)\s+(.+)$", text, re.IGNORECASE)
        if not youtube_match:
            youtube_match = re.match(r"^(.+?)\s+\bin\s+(?:youtube|yt)$", text, re.IGNORECASE)

        if youtube_match:
            query = youtube_match.group(1).strip()
            return "https://www.youtube.com/results?search_query=" + quote_plus(query)

        web_match = re.match(r"^(?:web|internet|google)\s+(.+)$", text, re.IGNORECASE)
        if not web_match:
            web_match = re.match(r"^(.+?)\s+\bin\s+(?:web|internet|google)$", text, re.IGNORECASE)

        if web_match:
            query = web_match.group(1).strip()
            return "https://www.google.com/search?q=" + quote_plus(query)

        return ""

    def _slash_help_text(self):
        return (
            "Direct slash commands:\n"
            "```\n"
            "/open <app|file|folder|url>\n"
            "/close <app>\n"
            "/quick <learned-pathway>\n"
            "```\n"
            "Everything else goes to Orchestrator V1 so the AI chooses the pathway. "
            "Learned quick pathways are created locally from repeated chat patterns."
        )

    def _learned_quick_pathways(self):
        try:
            data = self._load_personalization_rag() if hasattr(self, "_load_personalization_rag") else {}
            pathways = data.get("learned_quick_pathways", []) if isinstance(data, dict) else []
            return [item for item in pathways if isinstance(item, dict) and item.get("id")]
        except Exception:
            return []

    def _match_learned_quick_pathway(self, query):
        text = re.sub(r"\s+", " ", str(query or "").strip().lower())
        if not text:
            return None

        normalized = re.sub(r"[^a-z0-9]+", "-", text).strip("-")
        pathways = self._learned_quick_pathways()

        for item in pathways:
            candidates = [
                item.get("id", ""),
                str(item.get("command", "")).replace("/quick", "").strip(),
                item.get("title", "")
            ]
            candidates.extend(item.get("trigger_phrases", []) if isinstance(item.get("trigger_phrases"), list) else [])
            for candidate in candidates:
                candidate_text = re.sub(r"\s+", " ", str(candidate or "").strip().lower())
                candidate_slug = re.sub(r"[^a-z0-9]+", "-", candidate_text).strip("-")
                if text == candidate_text or normalized == candidate_slug:
                    return item

        for item in pathways:
            haystack = " ".join([
                item.get("id", ""),
                item.get("title", ""),
                item.get("category", ""),
                " ".join(item.get("trigger_phrases", []) if isinstance(item.get("trigger_phrases"), list) else [])
            ]).lower()
            if all(part in haystack for part in text.split()):
                return item

        return None

    def _mark_learned_quick_pathway_used(self, pathway_id):
        if not pathway_id or not hasattr(self, "_load_personalization_rag"):
            return
        try:
            data = self._load_personalization_rag()
            now = time.time()
            changed = False
            for item in data.get("learned_quick_pathways", []):
                if item.get("id") == pathway_id:
                    item["usage_count"] = int(item.get("usage_count", 0) or 0) + 1
                    item["last_used_at"] = now
                    item["last_used_label"] = self._format_timestamp(now)
                    changed = True
                    break
            if changed and hasattr(self, "_save_personalization_rag"):
                self._save_personalization_rag(data)
        except Exception:
            pass

    def _run_learned_quick_command(self, rest, mode, selected_model, chat_id):
        pathways = self._learned_quick_pathways()
        if not rest:
            if not pathways:
                return (
                    "No learned quick pathways yet. After a few chats, KIRA will learn recurring workflows "
                    "and create commands like `/quick mac-optimisation-plan`."
                )
            lines = [
                f"- `{item.get('command', '/quick ' + item.get('id', ''))}` - {item.get('title', item.get('id'))} "
                f"(confidence {item.get('confidence', 0)})"
                for item in pathways[:12]
            ]
            return "Learned quick pathways:\n" + "\n".join(lines)

        pathway = self._match_learned_quick_pathway(rest)
        if not pathway:
            return (
                f"I could not find a learned quick pathway matching `{rest}`.\n\n"
                "Use `/quick` to list learned pathways."
            )

        self._mark_learned_quick_pathway_used(pathway.get("id", ""))
        prompt_template = str(pathway.get("prompt_template", "") or "").strip()
        prompt = (
            "Run learned quick pathway.\n"
            f"Pathway: {pathway.get('title', pathway.get('id'))}\n"
            f"Learned command: {pathway.get('command')}\n"
            f"User detail: {rest}\n\n"
            f"Task: {prompt_template}"
        )
        self.task_queue.put({
            "prompt": prompt,
            "mode": "agentic",
            "selected_model": "orchestrator",
            "chat_id": chat_id
        })
        return (
            f"Running learned quick pathway: **{pathway.get('title', pathway.get('id'))}**\n\n"
            f"Command: `{pathway.get('command')}`\n"
            f"Confidence: `{pathway.get('confidence', 0)}`"
        )

    def get_slash_suggestions(self, query="", context="", *args, **kwargs):
        try:
            if not self.slash_suggestions_cache:
                self.slash_suggestions_cache = self._base_slash_suggestions()

            if self.last_slash_suggestions_scan and time.time() - self.last_slash_suggestions_scan > 300 and not self.slash_suggestions_refreshing:
                threading.Thread(target=self._refresh_slash_suggestions, kwargs={"force": True}, daemon=True).start()

            items = list(self.slash_suggestions_cache)
            raw_query = str(query or context or "").strip().lower()
            if raw_query.startswith("/"):
                raw_query = raw_query[1:]

            if raw_query:
                command_token = raw_query.split()[0] if raw_query.split() else ""
                arg_text = raw_query[len(command_token):].strip()
                known_names = {
                    item.get("command", "").lstrip("/").split()[0].lower()
                    for item in items
                    if item.get("command")
                }
                filtered = []

                for item in items:
                    command_text = str(item.get("command", "")).lower()
                    command_name = command_text.lstrip("/").split()[0] if command_text else ""
                    haystack = " ".join([
                        command_text,
                        str(item.get("title", "")).lower(),
                        str(item.get("hint", "")).lower(),
                        str(item.get("category", "")).lower()
                    ])

                    if command_token in known_names:
                        if command_name != command_token:
                            continue
                        if not arg_text or arg_text in haystack or all(part in haystack for part in arg_text.split()):
                            filtered.append(item)
                    elif (
                        not command_token
                        or command_name.startswith(command_token)
                        or raw_query in haystack
                        or all(part in haystack for part in raw_query.split())
                    ):
                        filtered.append(item)

                items = filtered

            return items[:250]
        except Exception as e:
            return [{
                "command": "/help",
                "title": "Slash suggestions unavailable",
                "hint": str(e),
                "category": "system"
            }]

    def get_live_snapshot(self):
        try:
            now = time.time()
            top_processes = self._live_top_processes()
            disk = shutil.disk_usage(self.home_path)

            with self.permission_lock:
                pending_permissions = len(self.pending_permissions)

            top = top_processes[0] if top_processes else {}

            return {
                "status": "ok",
                "time_label": self._format_timestamp(now),
                "front_app": self._frontmost_app_name(),
                "current_brain": self.current_brain or "idle",
                "voice_mode_active": bool(self.voice_mode_active),
                "queue_depth": self.task_queue.qsize() if hasattr(self, "task_queue") else 0,
                "pending_permissions": pending_permissions,
                "last_agentic_intent": self.last_agentic_intent or "none",
                "last_agentic_result": self._truncate(str(self.last_agentic_result or ""), 600),
                "top_process": top,
                "top_processes": top_processes[:5],
                "disk": {
                    "total": disk.total,
                    "used": disk.used,
                    "free": disk.free,
                    "percent_used": round((disk.used / disk.total) * 100, 1) if disk.total else 0
                },
                "readable_roots": self.computer_roots,
                "agentic_workspace": self.agentic_workspace
            }
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def set_screen_overlay_state(self, state="off"):
        state = str(state or "off").strip().lower()
        allowed = {"off", "live", "listening", "thinking", "speaking", "agentic"}
        if state not in allowed:
            state = "off"

        try:
            os.makedirs(os.path.dirname(self.screen_overlay_state_path), exist_ok=True)
            with open(self.screen_overlay_state_path, "w", encoding="utf-8") as f:
                json.dump({
                    "state": state,
                    "updated_at": time.time(),
                    "updated_label": self._format_timestamp(time.time())
                }, f)

            if state != "off":
                self._start_screen_overlay_if_needed()

            return {"ok": True, "state": state}
        except Exception as e:
            return {"ok": False, "state": state, "error": str(e)}

    def _start_screen_overlay_if_needed(self):
        try:
            if self.screen_overlay_process and self.screen_overlay_process.poll() is None:
                return

            script_path = os.path.join(self.app_root, "kira_screen_overlay.py")
            if not os.path.exists(script_path):
                return

            self.screen_overlay_process = subprocess.Popen(
                [sys.executable, script_path, self.screen_overlay_state_path],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=self.app_root
            )
        except Exception:
            self.screen_overlay_process = None

    def _live_top_processes(self):
        try:
            res = subprocess.run(
                ["ps", "-axo", "pid=,rss=,%mem=,command="],
                capture_output=True,
                text=True,
                timeout=5
            )
            rows = []
            for line in (res.stdout or "").splitlines():
                parts = line.strip().split(None, 3)
                if len(parts) < 4:
                    continue
                pid, rss, mem_percent, command = parts
                try:
                    rss_int = int(float(rss))
                except Exception:
                    rss_int = 0
                rows.append({
                    "pid": pid,
                    "name": self._friendly_process_name(command),
                    "command": command,
                    "rss_mb": round(rss_int / 1024, 1),
                    "mem_percent": mem_percent
                })
            rows.sort(key=lambda item: item["rss_mb"], reverse=True)
            return rows[:8]
        except Exception:
            return []

    def _frontmost_app_name(self):
        try:
            res = subprocess.run(
                [
                    "osascript",
                    "-e",
                    'tell application "System Events" to get name of first application process whose frontmost is true'
                ],
                capture_output=True,
                text=True,
                timeout=3
            )
            if res.returncode == 0 and (res.stdout or "").strip():
                return res.stdout.strip()
        except Exception:
            pass

        return "Unavailable"

    def _refresh_slash_suggestions(self, force=False):
        now = time.time()
        if not force and self.slash_suggestions_cache:
            if not self.last_slash_suggestions_scan:
                self.last_slash_suggestions_scan = now
                return self.slash_suggestions_cache
            if now - self.last_slash_suggestions_scan < 300:
                return self.slash_suggestions_cache

        try:
            self.slash_suggestions_refreshing = True
            suggestions = []
            suggestions.extend(self._base_slash_suggestions())
            suggestions.extend(self._learned_quick_pathway_suggestions())
            suggestions.extend(self._scan_app_suggestions())
            suggestions.extend(self._scan_ide_suggestions())
            suggestions.extend(self._scan_mcp_suggestions())
            suggestions.extend(self._scan_app_integration_suggestions())
            suggestions.extend(self._scan_workspace_suggestions())
            suggestions = self._dedupe_slash_suggestions(suggestions)

            self.slash_suggestions_cache = suggestions
            self.last_slash_suggestions_scan = time.time()

            try:
                with open(self.slash_suggestions_path, "w", encoding="utf-8") as f:
                    json.dump({
                        "scanned_at": self.last_slash_suggestions_scan,
                        "scanned_label": self._format_timestamp(self.last_slash_suggestions_scan),
                        "source": "KIRA OS safe local scan",
                        "scan_roots": {
                            "apps": ["/Applications", os.path.join(self.home_path, "Applications")],
                            "files": [
                                self.app_root,
                                self.computer_roots.get("desktop"),
                                self.computer_roots.get("downloads"),
                                self.computer_roots.get("documents"),
                                self.mcp_workspace,
                                self.ide_bridge_path
                            ],
                            "mcp_targets": self.mcp_config_targets
                        },
                        "suggestions": suggestions
                    }, f, indent=2, ensure_ascii=False)
            except Exception:
                pass
        except Exception:
            pass
        finally:
            self.slash_suggestions_refreshing = False

        return self.slash_suggestions_cache

    def _base_slash_suggestions(self):
        return [
            {"command": "/open ", "title": "Open app, file, folder, or URL", "hint": "Ask for a target if missing. Opening is direct.", "category": "commands"},
            {"command": "/close ", "title": "Close an app", "hint": "Ask for an app target if missing. Closing is direct.", "category": "commands"},
            {"command": "/web ", "title": "Search or fetch with the headless browser", "hint": "Example: /web latest Blender Python API", "category": "web"},
            {"command": "/browser ", "title": "Headless browser fetch", "hint": "Example: /browser https://example.com", "category": "web"},
            {"command": "/app ", "title": "Inspect an app integration", "hint": "Example: /app blender", "category": "integrations"},
            {"command": "/blender", "title": "Inspect Blender integration", "hint": "Find Blender, CLI, scripts, add-ons, and project hooks.", "category": "integrations"},
            {"command": "/ide ", "title": "Codex-style IDE bridge", "hint": "Example: /ide context . or /ide open . cursor", "category": "ide"},
            {"command": "/mcp ", "title": "MCP connector workspace", "hint": "Discover, draft, and apply MCP configs with permission.", "category": "mcp"},
            {"command": "/quick ", "title": "Run learned quick pathway", "hint": "KIRA learns these from repeated chat patterns.", "category": "learned"},
            {"command": "/help", "title": "Explain direct commands", "hint": "All other tasks are AI-chosen by Orchestrator V1.", "category": "commands"},
        ]

    def _learned_quick_pathway_suggestions(self):
        suggestions = []
        for item in self._learned_quick_pathways():
            command = item.get("command") or f"/quick {item.get('id', '')}"
            suggestions.append({
                "command": command,
                "title": "Learned: " + str(item.get("title", item.get("id", "Quick Pathway"))),
                "hint": f"Confidence {item.get('confidence', 0)} - {item.get('prompt_template', '')}",
                "category": "learned"
            })
        return suggestions

    def _scan_app_suggestions(self, max_apps=160):
        suggestions = []
        seen = set()
        roots = ["/Applications", os.path.join(self.home_path, "Applications")]

        for root in roots:
            if not os.path.isdir(root):
                continue

            for current_root, dirs, _files in os.walk(root):
                depth = current_root.count(os.sep) - root.count(os.sep)
                app_dirs = [dirname for dirname in dirs if dirname.endswith(".app")]

                for dirname in app_dirs:
                    app_name = dirname[:-4]
                    key = re.sub(r"[^a-z0-9]+", "", app_name.lower())
                    if not key or key in seen:
                        continue

                    app_path = os.path.join(current_root, dirname)
                    suggestions.append({
                        "command": f"/open {app_name}",
                        "title": f"Open app: {app_name}",
                        "hint": app_path,
                        "category": "apps"
                    })
                    seen.add(key)

                    if len(suggestions) >= max_apps:
                        return suggestions

                dirs[:] = [
                    dirname for dirname in dirs
                    if not dirname.endswith(".app") and not dirname.startswith(".") and depth < 2
                ]

        return suggestions

    def _scan_ide_suggestions(self):
        suggestions = []
        candidates = [
            ("cursor", "Cursor", "cursor"),
            ("windsurf", "Windsurf", "windsurf"),
            ("code", "Visual Studio Code", "code"),
            ("xcode", "Xcode", "xed"),
            ("finder", "Finder", "open")
        ]

        for key, display, cli in candidates:
            cli_path = shutil.which(cli)
            app_path = self._find_app_bundle(display) if display not in {"Finder"} else "/System/Library/CoreServices/Finder.app"

            if not cli_path and not app_path and key != "finder":
                continue

            hint = cli_path or app_path or "macOS default opener"
            suggestions.extend([
                {
                    "command": f"/connect ide {key}",
                    "title": f"Connect IDE pathway: {display}",
                    "hint": hint,
                    "category": "ide"
                },
                {
                    "command": f"/ide open . {key}",
                    "title": f"Open current project in {display}",
                    "hint": self.app_root,
                    "category": "ide"
                },
                {
                    "command": f"/ide context .",
                    "title": f"Inspect current project for {display}",
                    "hint": self.app_root,
                    "category": "ide"
                }
            ])

        return suggestions

    def _scan_mcp_suggestions(self):
        suggestions = [{"command": "/mcp discover", "title": "Discover MCP surfaces", "hint": self.mcp_workspace, "category": "mcp"}]

        for target, path in self.mcp_config_targets.items():
            suggestions.extend([
                {
                    "command": f"/connect mcp {target}",
                    "title": f"Connect MCP target: {target}",
                    "hint": path,
                    "category": "mcp"
                },
                {
                    "command": f"/mcp bootstrap {target}",
                    "title": f"Create MCP draft for {target}",
                    "hint": path,
                    "category": "mcp"
                }
            ])

        try:
            for name in sorted(os.listdir(self.mcp_workspace))[:80]:
                if not name.endswith(".json"):
                    continue
                draft_path = os.path.join(self.mcp_workspace, name)
                if self._is_sensitive_path(draft_path):
                    continue
                suggestions.append({
                    "command": f"/mcp apply {self._quote_slash_arg(draft_path)} cursor_project",
                    "title": f"Apply MCP draft: {name}",
                    "hint": draft_path,
                    "category": "mcp"
                })
        except Exception:
            pass

        return suggestions

    def _scan_app_integration_suggestions(self):
        suggestions = []
        for key, profile in self._popular_app_profiles().items():
            app_path = self._find_app_bundle(profile["display"])
            cli_path = self._first_existing_cli(profile.get("cli", []))
            if not app_path and not cli_path and not profile.get("always_show"):
                continue

            display = profile["display"]
            hint = app_path or cli_path or profile.get("hint", "")
            suggestions.append({
                "command": f"/app {key}",
                "title": f"Inspect app integration: {display}",
                "hint": hint,
                "category": "integrations"
            })
            if key == "blender":
                suggestions.append({
                    "command": "/blender",
                    "title": "Blender scene/script bridge",
                    "hint": hint or "Blender integration context",
                    "category": "integrations"
                })
            if app_path:
                suggestions.append({
                    "command": f"/open {display}",
                    "title": f"Open {display}",
                    "hint": app_path,
                    "category": "apps"
                })

        return suggestions

    def _scan_workspace_suggestions(self, max_items=140):
        suggestions = []
        roots = [
            ("kira_project", self.app_root),
            ("desktop", self.computer_roots.get("desktop")),
            ("downloads", self.computer_roots.get("downloads")),
            ("documents", self.computer_roots.get("documents")),
            ("mcp_workspace", self.mcp_workspace),
            ("ide_bridge", self.ide_bridge_path)
        ]

        for label, root in roots:
            if not root or not os.path.exists(root) or self._is_sensitive_path(root):
                continue

            suggestions.append({
                "command": f"/browse {label}",
                "title": f"Browse {label}",
                "hint": root,
                "category": "places"
            })
            suggestions.append({
                "command": f"/index {self._quote_slash_arg(root)}",
                "title": f"Index {label}",
                "hint": root,
                "category": "projects"
            })

            try:
                for current_root, dirs, filenames in os.walk(root):
                    depth = current_root.count(os.sep) - root.count(os.sep)
                    dirs[:] = [
                        dirname for dirname in dirs
                        if not dirname.startswith(".")
                        and dirname not in {"node_modules", "__pycache__", ".venv", "venv", "DerivedData", "Library"}
                        and not self._is_sensitive_path(os.path.join(current_root, dirname))
                        and depth < 2
                    ]

                    if depth <= 1:
                        for dirname in dirs[:30]:
                            full = os.path.join(current_root, dirname)
                            if self._is_sensitive_path(full):
                                continue
                            suggestions.append({
                                "command": f"/browse {self._quote_slash_arg(full)}",
                                "title": f"Browse folder: {dirname}",
                                "hint": full,
                                "category": "places"
                            })
                            suggestions.append({
                                "command": f"/index {self._quote_slash_arg(full)}",
                                "title": f"Index project/folder: {dirname}",
                                "hint": full,
                                "category": "projects"
                            })

                    for filename in filenames[:50]:
                        if filename.startswith("."):
                            continue
                        full = os.path.join(current_root, filename)
                        if self._is_sensitive_path(full):
                            continue
                        ext = os.path.splitext(filename)[1].lower()
                        if ext in {".py", ".html", ".js", ".ts", ".tsx", ".jsx", ".json", ".md", ".txt", ".yaml", ".yml", ".pdf", ".pptx", ".docx", ".csv"}:
                            suggestions.append({
                                "command": f"/open {self._quote_slash_arg(full)}",
                                "title": f"Open file: {filename}",
                                "hint": full,
                                "category": "files"
                            })
                            if ext not in {".pdf", ".pptx", ".docx"}:
                                suggestions.append({
                                    "command": f"/read {self._quote_slash_arg(full)}",
                                    "title": f"Read file: {filename}",
                                    "hint": full,
                                    "category": "files"
                                })

                    if len(suggestions) >= max_items:
                        return suggestions
            except Exception:
                continue

        return suggestions

    def _quote_slash_arg(self, value):
        text = str(value or "").strip()
        if not text:
            return ""
        if re.search(r"\s|[()'\"&;$]", text):
            return shlex.quote(text)
        return text

    def _dedupe_slash_suggestions(self, suggestions):
        deduped = []
        seen = set()
        allowed_commands = {
            "/open", "/close", "/help", "/web", "/browser", "/app", "/blender",
            "/ide", "/mcp", "/connect", "/browse", "/search", "/read", "/index",
            "/automate", "/run", "/memory", "/virus", "/optimise", "/optimize", "/system"
        }

        for item in suggestions:
            command = str(item.get("command", ""))
            if not command.strip():
                continue
            first_token = command.strip().split()[0].lower()
            if first_token not in allowed_commands:
                continue
            key = command.strip().lower()
            if key in seen:
                continue
            seen.add(key)
            deduped.append({
                "command": command,
                "title": str(item.get("title", "")).strip() or command.strip(),
                "hint": str(item.get("hint", "")).strip(),
                "category": str(item.get("category", "commands")).strip() or "commands"
            })

        category_order = {
            "commands": 0,
            "web": 1,
            "integrations": 2,
            "apps": 3,
            "ide": 4,
            "mcp": 5,
            "places": 6,
            "projects": 7,
            "files": 8
        }
        return sorted(
            deduped,
            key=lambda item: (
                category_order.get(item.get("category"), 50),
                item.get("title", "").lower(),
                item.get("command", "").lower()
            )
        )

    def get_kira_menu(self, query="", force=False, *args, **kwargs):
        raw_query = re.sub(r"\s+", " ", str(query or "").strip().lower())
        sections = [
            {
                "id": "learned",
                "title": "Learned Quick Pathways",
                "items": self._kira_menu_learned_items()
            },
            {
                "id": "generate",
                "title": "Build & Generate",
                "items": self._kira_menu_generate_items()
            },
            {
                "id": "apps",
                "title": "Apps",
                "items": self._kira_menu_app_items()
            },
            {
                "id": "integrations",
                "title": "IDE, Browser & App Integrations",
                "items": self._kira_menu_integration_items()
            },
            {
                "id": "artifacts",
                "title": "PDFs, Decks, Docs & Generated Files",
                "items": self._kira_menu_artifact_items()
            },
            {
                "id": "projects",
                "title": "Projects & Build Surfaces",
                "items": self._kira_menu_project_items()
            }
        ]

        if raw_query:
            for section in sections:
                section["items"] = [
                    item for item in section.get("items", [])
                    if self._kira_menu_matches(item, raw_query)
                ]

        return {
            "status": "ok",
            "updated_at": time.time(),
            "updated_label": self._format_timestamp(time.time()),
            "query": query,
            "sections": sections
        }

    def open_menu_target(self, target):
        return self._open_target_tool(target)

    def _kira_menu_learned_items(self):
        items = []
        for pathway in self._learned_quick_pathways():
            items.append({
                "kind": "learned",
                "icon": "auto_awesome",
                "title": pathway.get("title", pathway.get("id", "Learned Pathway")),
                "subtitle": (
                    f"{pathway.get('command', '/quick')} - confidence {pathway.get('confidence', 0)} "
                    f"from {pathway.get('evidence_count', 0)} pattern hit(s)."
                ),
                "prompt": pathway.get("command", f"/quick {pathway.get('id', '')}"),
                "tags": ["learned", "quick", pathway.get("category", "workflow")] + (
                    pathway.get("trigger_phrases", []) if isinstance(pathway.get("trigger_phrases"), list) else []
                )
            })
        return items

    def _load_artifact_index(self, validate=True):
        path = getattr(self, "artifacts_index_path", "")
        if not path or not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            items = data.get("artifacts", []) if isinstance(data, dict) else []
            valid = []
            for item in items:
                if not isinstance(item, dict) or not item.get("path"):
                    continue
                if validate and not os.path.exists(item.get("path")):
                    continue
                valid.append(item)
            valid.sort(key=lambda item: item.get("created_at", 0), reverse=True)
            return valid[:200]
        except Exception:
            return []

    def _save_artifact_index(self):
        try:
            path = getattr(self, "artifacts_index_path", "")
            if not path:
                return
            os.makedirs(os.path.dirname(path), exist_ok=True)
            with open(path, "w", encoding="utf-8") as f:
                json.dump({
                    "updated_at": time.time(),
                    "updated_label": self._format_timestamp(time.time()),
                    "artifacts": getattr(self, "last_artifacts", [])[:200]
                }, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    def _record_artifact(self, path, kind="", title=""):
        artifact_path = self._resolve_path(path)
        ext = os.path.splitext(artifact_path)[1].lower()
        kind = kind or self._artifact_kind(ext)
        title = title or os.path.basename(artifact_path)

        item = {
            "path": artifact_path,
            "kind": kind,
            "title": title,
            "chat_id": getattr(self, "active_chat_id", "") or "",
            "created_at": time.time(),
            "created_label": self._format_timestamp(time.time())
        }

        artifacts = [
            existing for existing in getattr(self, "last_artifacts", [])
            if existing.get("path") != artifact_path
        ]
        artifacts.insert(0, item)
        self.last_artifacts = artifacts[:200]
        self.last_artifact_path = artifact_path
        self._save_artifact_index()
        self._log_agentic_event("artifact_recorded", item)
        return item

    def _is_artifact_noise(self, path, title=""):
        value = (os.path.basename(str(path or "")) + " " + str(title or "")).lower()
        return any(marker in value for marker in [
            "smoke", "test_deck", "test deck", "bridge_test", "bridge test",
            "kira_smoke", "resolver_test", "real_user_deck_resolver",
            "safe_system", "safe system", "safe-system", "kira os safe",
            "kira_os_safe", "system_report", "system report smoke",
            "sample", "dummy"
        ])

    def _artifact_mentions_in_chat(self, chat_id, preferred_exts=None):
        preferred = {ext.lower() for ext in (preferred_exts or [])}
        found = []
        if not chat_id:
            return found

        messages = self._load_chat_messages(chat_id)
        pattern = re.compile(r"`([^`]+\.(?:pptx|docx|pdf))`|(/[^\s`]+?\.(?:pptx|docx|pdf))", re.IGNORECASE)
        for message in messages:
            content = str(message.get("content", "") or "")
            created = float(message.get("created_at", 0) or 0)
            for match in pattern.finditer(content):
                raw_path = match.group(1) or match.group(2) or ""
                path = self._resolve_path(raw_path)
                ext = os.path.splitext(path)[1].lower()
                if preferred and ext not in preferred:
                    continue
                if self._is_artifact_noise(path):
                    continue
                if os.path.exists(path):
                    found.append((created or os.path.getmtime(path), path))

        found.sort(reverse=True)
        deduped = []
        seen = set()
        for timestamp, path in found:
            if path in seen:
                continue
            seen.add(path)
            deduped.append((timestamp, path))
        return deduped

    def _latest_artifact(self, preferred_exts=None, chat_id=None, prefer_current_chat=True, allow_global=True):
        preferred = {ext.lower() for ext in (preferred_exts or [])}
        candidates = []

        if prefer_current_chat and chat_id:
            for timestamp, path in self._artifact_mentions_in_chat(chat_id, preferred):
                candidates.append((5, timestamp, path))

        for item in getattr(self, "last_artifacts", []) or []:
            path = item.get("path", "")
            if path and os.path.exists(path):
                if not preferred or os.path.splitext(path)[1].lower() in preferred:
                    item_chat_id = item.get("chat_id", "")
                    if self._is_artifact_noise(path, item.get("title", "")):
                        continue
                    if chat_id and item_chat_id == chat_id:
                        candidates.append((4, item.get("created_at", os.path.getmtime(path)), path))
                    elif allow_global:
                        candidates.append((1, item.get("created_at", os.path.getmtime(path)), path))

        if allow_global:
            search_roots = [getattr(self, "agentic_workspace", ""), getattr(self, "mcp_workspace", "")]
            for root in search_roots:
                if not root or not os.path.isdir(root):
                    continue
                for current_root, _dirs, files in os.walk(root):
                    for filename in files:
                        ext = os.path.splitext(filename)[1].lower()
                        if ext not in {".pptx", ".docx", ".pdf"}:
                            continue
                        if preferred and ext not in preferred:
                            continue
                        full = os.path.join(current_root, filename)
                        if self._is_artifact_noise(full):
                            continue
                        try:
                            candidates.append((0, os.path.getmtime(full), full))
                        except Exception:
                            pass

        if not candidates:
            return ""
        candidates.sort(reverse=True)
        return candidates[0][2]

    def _artifact_exts_for_prompt(self, prompt):
        text = re.sub(r"\s+", " ", str(prompt or "").lower())
        if any(word in text for word in ["ppt", "pptx", "powerpoint", "presentation", "deck"]):
            return {".pptx"}
        if any(word in text for word in ["word", "docx", "document"]):
            return {".docx"}
        if "pdf" in text:
            return {".pdf"}
        return {".pptx", ".docx", ".pdf"}

    def _artifact_followup_requires_current_chat(self, prompt):
        text = re.sub(r"\s+", " ", str(prompt or "").lower())
        return any(phrase in text for phrase in [
            "i generated", "you generated", "just generated", "we generated",
            "the one i generated", "the ppt i generated", "the deck i generated",
            "the report i generated", "that i generated", "created above",
            "made above", "generated above", "from this chat", "this chat",
            "open it", "show it", "open the ppt", "open ppt", "open the deck",
            "show the ppt", "show the deck", "the ppt", "the deck", "the presentation"
        ])

    def _latest_artifact_for_followup(self, prompt, chat_id):
        preferred = self._artifact_exts_for_prompt(prompt)
        require_current = self._artifact_followup_requires_current_chat(prompt)

        target = self._latest_artifact(
            preferred,
            chat_id=chat_id,
            prefer_current_chat=True,
            allow_global=not require_current
        )
        if target:
            return target

        if require_current:
            return ""

        # Last fallback: if the user did not say "the one I generated", use
        # current chat first but allow older non-test artifacts.
        return self._latest_artifact(
            preferred,
            chat_id=chat_id,
            prefer_current_chat=True,
            allow_global=True
        )

    def _handle_artifact_followup(self, prompt, chat_id):
        text = re.sub(r"\s+", " ", str(prompt or "").strip().lower())
        if not text:
            return ""

        wants_open = any(phrase in text for phrase in [
            "open it", "open the report", "open report", "open the file",
            "open file", "show it", "show the report", "where is the report"
        ]) or (
            any(word in text for word in ["ppt", "pptx", "powerpoint", "presentation", "deck", "docx", "word", "document", "pdf", "artifact"])
            and any(verb in text for verb in ["open", "show", "view", "where", "find"])
        )
        wants_word = any(word in text for word in ["word", "docx", "document"])

        if not wants_open:
            return ""

        if wants_word:
            target = self._latest_artifact({".docx"}, chat_id=chat_id, allow_global=not self._artifact_followup_requires_current_chat(prompt))
        else:
            target = self._latest_artifact_for_followup(prompt, chat_id)

        if not target:
            return (
                "I cannot find a generated artifact from this chat to open yet. "
                "Generate the PPTX/report first, or open it from the KIRA Menu."
            )

        open_result = self._open_target_tool(target)
        return f"{open_result}\n\nLatest report file: `{target}`"

    def _kira_menu_matches(self, item, query):
        haystack = " ".join([
            str(item.get("title", "")),
            str(item.get("subtitle", "")),
            str(item.get("path", "")),
            str(item.get("prompt", "")),
            str(item.get("kind", "")),
            " ".join(item.get("tags", []) if isinstance(item.get("tags"), list) else [])
        ]).lower()
        return all(part in haystack for part in query.split())

    def _kira_menu_generate_items(self):
        return [
            {
                "kind": "generate",
                "icon": "slideshow",
                "title": "Generate PPTX Deck",
                "subtitle": "Create a PowerPoint deck with slides, bullets, tables, images, and notes.",
                "prompt": "Generate a PPTX deck about ",
                "tags": ["pptx", "deck", "presentation", "generate"]
            },
            {
                "kind": "generate",
                "icon": "description",
                "title": "Generate Word DOCX",
                "subtitle": "Create a formatted Word document with headings, tables, bullets, and images.",
                "prompt": "Generate a Word DOCX report about ",
                "tags": ["docx", "word", "report", "document"]
            },
            {
                "kind": "generate",
                "icon": "picture_as_pdf",
                "title": "Generate PDF",
                "subtitle": "Create a native PDF in the KIRA agentic workspace.",
                "prompt": "Generate a PDF about ",
                "tags": ["pdf", "fpdf", "document"]
            },
            {
                "kind": "generate",
                "icon": "auto_stories",
                "title": "Convert PDF To PPTX",
                "subtitle": "Turn a downloaded PDF into an image-based PowerPoint deck.",
                "prompt": "Convert this PDF into a PPTX deck: ",
                "tags": ["pdf", "pptx", "convert"]
            },
            {
                "kind": "agentic",
                "icon": "public",
                "title": "Headless Web Search",
                "subtitle": "Search, fetch, and analyze web pages without needing the user to run a browser command.",
                "prompt": "Search the web with the headless browser for ",
                "tags": ["web", "browse", "internet", "headless"]
            },
            {
                "kind": "agentic",
                "icon": "search",
                "title": "Search Computer",
                "subtitle": "Search readable local files and folders safely.",
                "prompt": "Search my computer for ",
                "tags": ["files", "search", "computer"]
            },
            {
                "kind": "agentic",
                "icon": "memory",
                "title": "System / RAM Report",
                "subtitle": "Inspect system, disk, and memory state read-only.",
                "prompt": "Inspect my system state and RAM usage read-only.",
                "tags": ["system", "ram", "diagnostics"]
            },
            {
                "kind": "agentic",
                "icon": "security",
                "title": "AI Virus Scan",
                "subtitle": "Read-only malware signal scan, then AI risk review.",
                "prompt": "Run an AI virus scan on my Downloads folder. Do not change anything.",
                "tags": ["virus", "malware", "security"]
            },
            {
                "kind": "agentic",
                "icon": "cleaning_services",
                "title": "Optimize Mac",
                "subtitle": "Read-only cleanup scan with safe recommendations.",
                "prompt": "Run an optimisation scan on my Mac and give me a safe cleanup plan.",
                "tags": ["optimise", "optimize", "cleanup"]
            },
            {
                "kind": "utility",
                "icon": "content_paste_search",
                "title": "Clipboard Context",
                "subtitle": "Read current clipboard text when it is useful for the task.",
                "prompt": "Read my clipboard and help me with it.",
                "tags": ["clipboard", "paste", "context"]
            },
            {
                "kind": "utility",
                "icon": "difference",
                "title": "Compare Files",
                "subtitle": "Diff two readable files and explain the important changes.",
                "prompt": "Compare these two files and explain the differences: ",
                "tags": ["diff", "compare", "files"]
            },
            {
                "kind": "utility",
                "icon": "fingerprint",
                "title": "Hash File",
                "subtitle": "Compute a SHA256 checksum for a readable file.",
                "prompt": "Compute the SHA256 hash for this file: ",
                "tags": ["hash", "checksum", "sha256"]
            },
            {
                "kind": "utility",
                "icon": "inventory_2",
                "title": "Archive Preview",
                "subtitle": "Preview zip/tar contents read-only before extracting or moving anything.",
                "prompt": "Preview this archive safely: ",
                "tags": ["zip", "tar", "archive", "preview"]
            },
            {
                "kind": "utility",
                "icon": "note_stack",
                "title": "Draft Note",
                "subtitle": "Create a markdown note in the KIRA agentic workspace.",
                "prompt": "Create a note about ",
                "tags": ["note", "draft", "markdown"]
            },
            {
                "kind": "utility",
                "icon": "event_upcoming",
                "title": "Calendar Draft",
                "subtitle": "Draft an .ics calendar file in the KIRA workspace.",
                "prompt": "Create a calendar draft for ",
                "tags": ["calendar", "ics", "event"]
            },
            {
                "kind": "architect",
                "icon": "terminal",
                "title": "Codex-Style IDE Bridge",
                "subtitle": "Discover project root, CLIs, MCP targets, bridge files, and editor launch paths.",
                "prompt": "Connect to my current IDE/project context and summarize the architecture.",
                "tags": ["ide", "project", "architect"]
            },
            {
                "kind": "architect",
                "icon": "hub",
                "title": "MCP Connector Draft",
                "subtitle": "Discover MCP targets and create connector drafts safely.",
                "prompt": "Discover MCP surfaces and draft the best connector setup for this project.",
                "tags": ["mcp", "connector", "draft"]
            }
        ]

    def _kira_menu_integration_items(self):
        items = []

        items.extend([
            {
                "kind": "web",
                "icon": "travel_explore",
                "title": "Headless Browser Search",
                "subtitle": "Use Orchestrator to search, fetch, extract, and summarize web pages.",
                "prompt": "Use the headless browser to search the web for ",
                "tags": ["web", "browser", "search", "headless"]
            },
            {
                "kind": "ide",
                "icon": "terminal",
                "title": "Codex-Style IDE Bridge",
                "subtitle": "Open the current project, write bridge state, inspect Git/build/MCP surfaces.",
                "prompt": "Connect to my IDE using the Codex-style project bridge and explain the workspace state.",
                "tags": ["ide", "codex", "cursor", "windsurf", "vscode"]
            },
            {
                "kind": "mcp",
                "icon": "hub",
                "title": "MCP Discovery",
                "subtitle": "Discover Cursor, Claude Desktop, VS Code candidates, and KIRA connector drafts.",
                "prompt": "Discover MCP connection surfaces and draft the best safe connector config.",
                "tags": ["mcp", "connector"]
            }
        ])

        for key, profile in self._popular_app_profiles().items():
            app_path = self._find_app_bundle(profile["display"])
            cli_path = self._first_existing_cli(profile.get("cli", []))
            if not app_path and not cli_path and not profile.get("always_show"):
                continue

            display = profile["display"]
            items.append({
                "kind": "integration",
                "icon": profile.get("icon", "extension"),
                "title": f"{display} Integration",
                "subtitle": app_path or cli_path or profile.get("hint", "Available as an Orchestrator pathway."),
                "path": app_path or cli_path or "",
                "open_target": app_path if app_path else "",
                "prompt": profile.get("prompt", f"Inspect the {display} app integration and tell me what KIRA OS can do with it."),
                "tags": ["integration", key, display.lower()]
            })

        return items

    def _kira_menu_app_items(self, max_apps=220):
        items = []
        seen = set()
        roots = ["/Applications", "/System/Applications", os.path.join(self.home_path, "Applications")]

        for root in roots:
            if not os.path.isdir(root):
                continue

            for current_root, dirs, _files in os.walk(root):
                depth = current_root.count(os.sep) - root.count(os.sep)
                app_dirs = [dirname for dirname in dirs if dirname.endswith(".app")]

                for dirname in app_dirs:
                    app_name = dirname[:-4]
                    key = re.sub(r"[^a-z0-9]+", "", app_name.lower())
                    if not key or key in seen:
                        continue

                    app_path = os.path.join(current_root, dirname)
                    items.append({
                        "kind": "app",
                        "icon": "apps",
                        "title": app_name,
                        "subtitle": app_path,
                        "path": app_path,
                        "open_target": app_path,
                        "tags": ["app", "open"]
                    })
                    seen.add(key)

                    if len(items) >= max_apps:
                        return sorted(items, key=lambda item: item["title"].lower())

                dirs[:] = [
                    dirname for dirname in dirs
                    if not dirname.endswith(".app") and not dirname.startswith(".") and depth < 2
                ]

        return sorted(items, key=lambda item: item["title"].lower())

    def _kira_menu_artifact_items(self, max_items=260):
        items = []
        seen = set()
        artifact_exts = {
            ".pdf", ".pptx", ".ppt", ".docx", ".doc", ".xlsx", ".xls", ".csv",
            ".png", ".jpg", ".jpeg", ".webp", ".gif", ".html", ".md", ".txt"
        }
        roots = [
            self.agentic_workspace,
            self.mcp_workspace,
            os.path.join(self.agentic_workspace, "screenshots"),
            self.computer_roots.get("downloads"),
            self.computer_roots.get("desktop"),
            self.computer_roots.get("documents")
        ]

        for root in roots:
            if not root or not os.path.isdir(root) or self._is_sensitive_path(root):
                continue

            for current_root, dirs, filenames in os.walk(root):
                depth = current_root.count(os.sep) - root.count(os.sep)
                dirs[:] = [
                    dirname for dirname in dirs
                    if not dirname.startswith(".")
                    and dirname not in {"node_modules", "__pycache__", ".venv", "venv", "Library", "DerivedData"}
                    and depth < 3
                    and not self._is_sensitive_path(os.path.join(current_root, dirname))
                ]

                for filename in filenames:
                    if filename.startswith("."):
                        continue
                    ext = os.path.splitext(filename)[1].lower()
                    if ext not in artifact_exts:
                        continue
                    full = os.path.join(current_root, filename)
                    if full in seen or self._is_sensitive_path(full) or self._is_artifact_noise(full, filename):
                        continue

                    try:
                        stat = os.stat(full)
                    except Exception:
                        continue

                    items.append({
                        "kind": self._artifact_kind(ext),
                        "icon": self._artifact_icon(ext),
                        "title": filename,
                        "subtitle": f"{self._format_bytes(stat.st_size)} · {self._format_timestamp(stat.st_mtime)}",
                        "path": full,
                        "open_target": full,
                        "tags": [ext.lstrip("."), "artifact", "generated", "file"]
                    })
                    seen.add(full)

                    if len(items) >= max_items:
                        return sorted(items, key=lambda item: os.path.getmtime(item["path"]), reverse=True)

        return sorted(items, key=lambda item: os.path.getmtime(item["path"]), reverse=True)

    def _kira_menu_project_items(self, max_items=140):
        items = []
        seen = set()
        marker_names = {
            "package.json", "pyproject.toml", "requirements.txt", "setup.py", "vite.config.js",
            "next.config.js", "tsconfig.json", "Makefile", "Dockerfile", "Modelfile",
            "README.md", "mcp.json", "claude_desktop_config.json"
        }
        roots = [
            self.app_root,
            self.architect_workspace,
            self.ide_bridge_path,
            self.computer_roots.get("desktop"),
            self.computer_roots.get("documents")
        ]

        for root in roots:
            if not root or not os.path.isdir(root) or self._is_sensitive_path(root):
                continue

            for current_root, dirs, filenames in os.walk(root):
                depth = current_root.count(os.sep) - root.count(os.sep)
                dirs[:] = [
                    dirname for dirname in dirs
                    if not dirname.startswith(".")
                    and dirname not in {"node_modules", "__pycache__", ".venv", "venv", "Library", "DerivedData"}
                    and depth < 2
                    and not self._is_sensitive_path(os.path.join(current_root, dirname))
                ]

                found_markers = [name for name in filenames if name in marker_names or name.endswith((".xcodeproj", ".xcworkspace"))]
                if found_markers and current_root not in seen:
                    items.append({
                        "kind": "project",
                        "icon": "developer_board",
                        "title": os.path.basename(current_root) or current_root,
                        "subtitle": ", ".join(found_markers[:4]),
                        "path": current_root,
                        "open_target": current_root,
                        "prompt": f"Index this project and explain its build/generate surfaces: {current_root}",
                        "tags": ["project", "build", "index", "ide"]
                    })
                    seen.add(current_root)

                for filename in filenames:
                    if filename in marker_names or filename.endswith((".xcodeproj", ".xcworkspace")):
                        full = os.path.join(current_root, filename)
                        if full in seen or self._is_sensitive_path(full):
                            continue
                        items.append({
                            "kind": "build_file",
                            "icon": "construction",
                            "title": filename,
                            "subtitle": current_root,
                            "path": full,
                            "open_target": full,
                            "tags": ["build", "config", "project"]
                        })
                        seen.add(full)

                if len(items) >= max_items:
                    return items

        return items

    def _popular_app_profiles(self):
        return {
            "blender": {
                "display": "Blender",
                "cli": ["blender"],
                "icon": "deployed_code",
                "hint": "3D scene, Python script, render, and asset workflow bridge.",
                "prompt": "Inspect my Blender integration and explain how KIRA can open Blender, draft scene scripts, and prepare safe automation."
            },
            "drawthings": {
                "display": "Draw Things",
                "cli": [],
                "icon": "palette",
                "hint": "Local image generation app. KIRA can open it and draft prompts/workflows.",
                "prompt": "Inspect the Draw Things integration and prepare a local image generation workflow."
            },
            "cursor": {
                "display": "Cursor",
                "cli": ["cursor"],
                "icon": "terminal",
                "hint": "IDE bridge for project context, files, MCP, and implementation loops.",
                "prompt": "Connect to Cursor using the Codex-style IDE bridge for this project."
            },
            "windsurf": {
                "display": "Windsurf",
                "cli": ["windsurf"],
                "icon": "terminal",
                "hint": "IDE bridge for project context and implementation planning.",
                "prompt": "Connect to Windsurf using the Codex-style IDE bridge for this project."
            },
            "vscode": {
                "display": "Visual Studio Code",
                "cli": ["code"],
                "icon": "terminal",
                "hint": "IDE bridge for project context and file opening.",
                "prompt": "Connect to VS Code using the Codex-style IDE bridge for this project."
            },
            "xcode": {
                "display": "Xcode",
                "cli": ["xed"],
                "icon": "developer_mode",
                "hint": "Apple project bridge for Xcode projects and workspaces.",
                "prompt": "Inspect the Xcode integration and available Apple project surfaces."
            },
            "figma": {
                "display": "Figma",
                "cli": [],
                "icon": "design_services",
                "hint": "Design handoff/app opening workflow.",
                "prompt": "Inspect the Figma integration and suggest a design handoff workflow."
            },
            "powerpoint": {
                "display": "Microsoft PowerPoint",
                "cli": [],
                "icon": "slideshow",
                "hint": "Open generated PPTX decks.",
                "prompt": "Inspect the PowerPoint integration and open the latest generated deck if available."
            },
            "word": {
                "display": "Microsoft Word",
                "cli": [],
                "icon": "description",
                "hint": "Open generated DOCX reports.",
                "prompt": "Inspect the Word integration and open the latest generated document if available."
            },
            "keynote": {
                "display": "Keynote",
                "cli": [],
                "icon": "co_present",
                "hint": "Open and present generated decks.",
                "prompt": "Inspect the Keynote integration and explain deck-opening options."
            },
            "numbers": {
                "display": "Numbers",
                "cli": [],
                "icon": "table_chart",
                "hint": "Open generated spreadsheets.",
                "prompt": "Inspect the Numbers integration and spreadsheet workflow."
            },
            "safari": {
                "display": "Safari",
                "cli": [],
                "icon": "public",
                "hint": "Visible browsing/open pathway.",
                "prompt": "Inspect the Safari integration and visible browsing pathway."
            },
            "chrome": {
                "display": "Google Chrome",
                "cli": ["google-chrome", "chrome"],
                "icon": "public",
                "hint": "Visible and headless web browsing pathway.",
                "prompt": "Inspect the Chrome/headless browser integration."
            }
        }

    def _first_existing_cli(self, names):
        for name in names or []:
            found = shutil.which(name)
            if found:
                return found
        return ""

    def _artifact_kind(self, ext):
        if ext in {".pdf"}:
            return "pdf"
        if ext in {".ppt", ".pptx"}:
            return "presentation"
        if ext in {".doc", ".docx"}:
            return "word"
        if ext in {".xlsx", ".xls", ".csv"}:
            return "spreadsheet"
        if ext in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
            return "image"
        return "file"

    def _artifact_icon(self, ext):
        if ext == ".pdf":
            return "picture_as_pdf"
        if ext in {".ppt", ".pptx"}:
            return "slideshow"
        if ext in {".doc", ".docx"}:
            return "description"
        if ext in {".xlsx", ".xls", ".csv"}:
            return "table_chart"
        if ext in {".png", ".jpg", ".jpeg", ".webp", ".gif"}:
            return "image"
        if ext in {".html", ".md", ".txt"}:
            return "article"
        return "draft"

    def _format_bytes(self, value):
        try:
            amount = float(value or 0)
        except Exception:
            amount = 0
        units = ["B", "KB", "MB", "GB", "TB"]
        idx = 0
        while amount >= 1024 and idx < len(units) - 1:
            amount /= 1024
            idx += 1
        if idx == 0:
            return f"{int(amount)} B"
        return f"{amount:.1f} {units[idx]}"

    def _preflight_prompt(self, prompt):
        compact = re.sub(r"\s+", " ", prompt.strip().lower())

        if re.fullmatch(r"(generate|make|create)\s*:?", compact):
            return (
                "Generate what? Tell me the artifact type, the topic or source, and the output format. "
                "Example: generate a PPTX and PDF from ~/Downloads/report.pdf with images."
            )

        if re.fullmatch(r"open\s*:?", compact):
            return "Open what? Give me an app name, file path, folder path, or URL."

        if re.fullmatch(r"search\s*:?", compact):
            return "Search what, and where? Say web, this project, a folder path, or your computer."

        if re.fullmatch(r"(find out in my computer|find in computer|find on my computer)\s*:?", compact):
            return (
                "What should I find, and where should I look? "
                "Give me the issue plus a folder such as ~/Downloads, ~/Desktop, or a project path."
            )

        return None

    def _build_deterministic_agentic_blocks(self, raw_prompt, current_output="", chat_id=None):
        text = re.sub(r"\s+", " ", str(raw_prompt or "").strip())
        lowered = text.lower()
        blocks = []

        delete_match = re.search(r"`((?:~|/)[^`]+)`", text)
        if not delete_match:
            delete_match = re.search(
                r"\bdelete\b.*?((?:~|/)[^\n\r`]+?\.(?:tmp|txt|json|md|py|html|js|ts|tsx|jsx|css|pdf|pptx|docx|csv|png|jpg|jpeg|gif|zip|dmg|pkg|app))(?=\s|$|[.,;])",
                text,
                re.IGNORECASE
            )
        if not delete_match:
            delete_match = re.search(r"\bdelete\b.*?((?:~|/)[^\n\r`]+)", text, re.IGNORECASE)

        if delete_match:
            path = delete_match.group(1).strip()
            path = re.split(
                r"(?i)(?:\.\s+(?:ask|please|confirm|do|only|nothing)|,\s*(?:ask|please|confirm)|;\s*|\s+\b(?:ask|please|confirm)\b)",
                path,
                maxsplit=1
            )[0].strip().strip(" .")
            blocks.append(f"[DELETE_PATH]\nPATH: {path}\n[/DELETE_PATH]")

        if "downloads" in lowered and any(word in lowered for word in [
            "inspect", "check", "scan", "review", "unwanted", "suspicious", "files"
        ]):
            blocks.append("[LIST_DIR]\nPATH: ~/Downloads\n[/LIST_DIR]")

        if any(word in lowered for word in ["screen", "screenshot", "visible", "see what", "look at"]) and any(word in lowered for word in [
            "screen", "desktop", "window", "visible", "front", "currently", "right now"
        ]):
            blocks.append("[SCREENSHOT_CONTEXT]\n[/SCREENSHOT_CONTEXT]")

        if "desktop" in lowered and any(word in lowered for word in [
            "inspect", "check", "scan", "review", "unwanted", "suspicious", "files"
        ]):
            blocks.append("[LIST_DIR]\nPATH: ~/Desktop\n[/LIST_DIR]")

        if any(word in lowered for word in ["ram", "memory", "applications", "apps", "processes"]):
            if any(word in lowered for word in ["check", "inspect", "track", "monitor", "which", "what", "top"]):
                blocks.append("[MEMORY_REPORT]\n[/MEMORY_REPORT]")

        if any(word in lowered for word in ["web", "internet", "search"]) and "://" not in lowered:
            query = re.sub(r"(?i)\b(search|web|internet|browse|look up|find)\b", " ", text)
            query = re.sub(r"\s+", " ", query).strip(" :")
            if query:
                blocks.append(f"[WEB_SEARCH]\nQUERY: {query}\n[/WEB_SEARCH]")

        return "\n\n".join(dict.fromkeys(blocks))

    def _has_raw_marker_text(self, text):
        markers = [
            "TERMINAL EXECUTION:", "APPLESCRIPT EXECUTION:", "PYTHON EXECUTION:",
            "SYSTEM REPORT:", "MEMORY_REPORT", "APP_LIST:", "WINDOW_REPORT:",
            "WEB_HEADLESS:", "APP INTEGRATION:", "BLENDER INTEGRATION:",
            "OPTIMISATION_SCAN", "Virus scan completed", "PPTX generated",
            "DOCX generated", "PDF generated"
        ]
        value = str(text or "")
        return any(marker in value for marker in markers)

    def _ensure_requested_artifact_or_real_open(self, raw_prompt, answer, preflight_context, chat_id):
        answer_text = str(answer or "").strip()

        if self._artifact_was_really_generated(answer_text):
            return answer_text

        if not self._wants_artifact_generation(raw_prompt, chat_id):
            return answer_text

        kind = self._infer_artifact_kind(raw_prompt, chat_id)
        self.response_queue.put({
            "type": "status",
            "content": f"Orchestrator V1 is selecting the {kind.upper()} artifact pathway...",
            "chat_id": chat_id
        })

        generated = self._generate_prompt_specific_artifact_with_orchestrator(
            kind,
            raw_prompt,
            answer_text,
            preflight_context,
            chat_id
        )

        if self._artifact_was_really_generated(generated):
            try:
                self.response_queue.put({
                    "type": "ui_action",
                    "action": "open_kira_menu",
                    "content": "Opening KIRA menu with the generated artifact.",
                    "chat_id": chat_id
                })
            except Exception:
                pass
            if (
                answer_text
                and not self._looks_like_false_artifact_claim(answer_text)
                and not getattr(self, "_is_execution_guard_response", lambda _text: False)(answer_text)
            ):
                return answer_text + "\n\n" + generated
            return generated

        local_fallback = self._generate_prompt_specific_local_artifact(kind, raw_prompt, chat_id)
        if self._artifact_was_really_generated(local_fallback):
            if (
                answer_text
                and not self._looks_like_false_artifact_claim(answer_text)
                and not getattr(self, "_is_execution_guard_response", lambda _text: False)(answer_text)
            ):
                return answer_text + "\n\n" + local_fallback
            return local_fallback

        if answer_text and not self._looks_like_false_artifact_claim(answer_text):
            return (
                answer_text
                + f"\n\nI did not create a new {kind.upper()} yet because no artifact pathway returned a real file path."
            )

        return (
            f"I did not create the {kind.upper()} yet. Orchestrator V1 did not emit a valid artifact bridge block for this request, "
            "so I refused to fake completion or open an old report. Tell me the exact topic/source again and I will generate a fresh file."
        )

    def _generate_prompt_specific_local_artifact(self, kind, raw_prompt, chat_id):
        kind = str(kind or "pptx").lower()
        title = self._prompt_specific_artifact_title(raw_prompt, kind)
        request = self._report_clean(raw_prompt)
        image_sources = self._extract_image_sources_from_prompt(raw_prompt)
        if not request:
            return ""

        if kind == "docx":
            block = f"""TITLE: {title}
SUBTITLE: Draft generated from the current request
HEADING: Request
PARAGRAPH: {request}
HEADING: Draft Notes
PARAGRAPH: This document was generated from the current prompt because the model did not return a native artifact block in time.
BULLET: Review the structure and ask KIRA OS to expand any section.
BULLET: No old KIRA system report was reused.
"""
            return self._generate_native_docx(block)

        if kind == "pdf":
            content = (
                "Draft generated from the current request.\n\n"
                f"Request:\n{request}\n\n"
                "No old KIRA system report was reused. Ask KIRA OS to expand this into a richer PDF if needed."
            )
            return self._generate_native_pdf(f"[NATIVE_PDF]\nTITLE: {title}\nCONTENT: {content}\n[/NATIVE_PDF]")

        block = f"""TITLE: {title}
SUBTITLE: Fresh deck generated from the current request
THEME: dark
SLIDE: Request
BODY: {request}
{f"IMAGE: {image_sources[0]}" if image_sources else ""}
SLIDE: Working Structure
BULLET: Context and goal
BULLET: Main points to cover
BULLET: Evidence, examples, or visuals to add
BULLET: Final takeaway
{f"IMAGE: {image_sources[1]}" if len(image_sources) > 1 else ""}
SLIDE: Next Draft Step
BODY: This is a fresh prompt-specific deck. Ask KIRA OS to expand it with more detail, images, tables, or a PDF source if you want a fuller presentation.
{f"IMAGE: {image_sources[2]}" if len(image_sources) > 2 else ""}
NOTES: Generated by KIRA OS from the current prompt only. No old safe-system report was reused.
"""
        return self._generate_native_pptx(block)

    def _generate_prompt_specific_artifact_with_orchestrator(self, kind, raw_prompt, answer_text, preflight_context, chat_id):
        if getattr(self, "current_brain", None) != "orchestrator" or getattr(self, "active_model", None) is None:
            return ""

        kind = str(kind or "pptx").lower()
        if kind == "docx":
            required = "NATIVE_DOCX"
            format_instruction = "Emit exactly one [NATIVE_DOCX] block for the current user request."
        elif kind == "pdf":
            required = "NATIVE_PDF"
            format_instruction = "Emit exactly one [NATIVE_PDF] block for the current user request."
        else:
            required = "NATIVE_PPTX"
            format_instruction = "Emit exactly one [NATIVE_PPTX] block, or [PDF_TO_PPTX] only if the user provided a PDF source."

        recent_messages = self._load_chat_messages(chat_id)[-8:] if chat_id else []
        repair_instruction = (
            "ARTIFACT PATHWAY REPAIR MODE:\n"
            "- The user asked for a generated artifact, but no real file path was produced yet.\n"
            "- Choose the artifact pathway from the user's current goal, not from any canned report template.\n"
            "- Do not create or open 'KIRA OS Safe System Report' unless the user explicitly asked for that exact report.\n"
            "- Use the user's requested topic, source, style, and prior chat context.\n"
            "- If the source/content is missing, ask one short clarifying question instead of fabricating a deck.\n"
            "- Do not claim completion. Output only the needed bridge block or one short clarification.\n"
            f"- Required artifact direction: {format_instruction}\n"
        )
        messages = [{
            "role": "user",
            "content": (
                repair_instruction
                + "\nCurrent user request:\n"
                + str(raw_prompt or "")
                + "\n\nPrevious model answer, if any:\n"
                + self._truncate(str(answer_text or ""), 1500)
                + "\n\nRead-only/preflight context, if any:\n"
                + self._truncate(str(preflight_context or ""), 4000)
                + "\n\nRecent chat memory:\n"
                + json.dumps(recent_messages, ensure_ascii=False)
                + f"\n\nNow emit {required} for this exact request, or ask the missing slot question."
            )
        }]

        try:
            prompt = self._tokenizer_prompt(messages) + "<thought_process>\n"
            response = self._generate_with_watchdog(
                prompt,
                temperature=0.62,
                max_tokens=1900,
                timeout_seconds=32,
                label="artifact_pathway_repair"
            )
            if not response:
                return ""

            private, public = self._split_orchestrator_response(response)
            self._log_private_thoughts(private)
            bridge_blocks = self._extract_agentic_blocks(str(private or "") + "\n" + str(public or ""))
            if not bridge_blocks:
                return self._strip_private_reasoning(public)

            allowed = {
                "pptx": ["[NATIVE_PPTX]", "[PDF_TO_PPTX]"],
                "docx": ["[NATIVE_DOCX]"],
                "pdf": ["[NATIVE_PDF]"]
            }.get(kind, ["[NATIVE_PPTX]", "[PDF_TO_PPTX]"])
            if not any(marker.lower() in bridge_blocks.lower() for marker in allowed):
                return ""

            if hasattr(self, "_run_agentic_capabilities_with_watchdog"):
                return self._run_agentic_capabilities_with_watchdog(
                    bridge_blocks,
                    raw_prompt,
                    chat_id,
                    "artifact_repair"
                )
            return self._run_agentic_capabilities(bridge_blocks, raw_prompt, chat_id)
        except Exception as e:
            self._log_agentic_event("artifact_pathway_repair_error", {"error": str(e)})
            return ""

    def _artifact_was_really_generated(self, text):
        for path in re.findall(r"`([^`]+\.(?:pptx|docx|pdf))`", str(text or ""), re.IGNORECASE):
            if os.path.exists(self._resolve_path(path)):
                return True
        return False

    def _looks_like_false_artifact_claim(self, text):
        lowered = str(text or "").lower()
        return any(word in lowered for word in [
            "task is complete", "successfully generated", "already been successfully",
            "delivered", "opening it", "now open", "ready for review", "confirm its completion"
        ])

    def _wants_artifact_generation(self, raw_prompt, chat_id):
        current = re.sub(r"\s+", " ", str(raw_prompt or "").lower())
        recent = " ".join(
            str(message.get("content", ""))
            for message in self._load_chat_messages(chat_id)[-8:]
            if message.get("role") == "user"
        ).lower()
        combined = current + " " + recent

        explicit_format = any(word in combined for word in [
            "ppt", "pptx", "presentation", "deck", "word", "docx", "document", "pdf"
        ])
        asks_generate = any(word in current for word in [
            "generate", "genertae", "create", "make", "build", "export", "convert"
        ])
        asks_report = "report" in current or "safe optimization plan" in current or "safe optimisation plan" in current

        return explicit_format and (asks_generate or asks_report)

    def _infer_artifact_kind(self, raw_prompt, chat_id):
        current = re.sub(r"\s+", " ", str(raw_prompt or "").lower())
        recent = " ".join(
            str(message.get("content", ""))
            for message in self._load_chat_messages(chat_id)[-10:]
            if message.get("role") == "user"
        ).lower()

        if any(word in current for word in ["word", "docx", "document"]):
            return "docx"
        if "pdf" in current and not any(word in current for word in ["ppt", "pptx"]):
            return "pdf"
        if any(word in current for word in ["ppt", "pptx", "presentation", "deck"]):
            return "pptx"
        if any(word in recent for word in ["ppt", "pptx", "presentation", "deck"]):
            return "pptx"
        if any(word in recent for word in ["word", "docx", "document"]):
            return "docx"
        if "pdf" in recent:
            return "pdf"
        return "pptx"

    def _build_fallback_report_context(self, raw_prompt, preflight_context, chat_id):
        sections = []
        prompt_text = str(raw_prompt or "")
        lowered = prompt_text.lower()

        if preflight_context:
            sections.append(("Existing KIRA Inspection Context", self._truncate(preflight_context, 9000)))

        try:
            sections.append(("Live Snapshot", json.dumps(self.get_live_snapshot(), indent=2, ensure_ascii=False)))
        except Exception as e:
            sections.append(("Live Snapshot", f"Unavailable: {e}"))

        try:
            sections.append(("Memory And Running Apps", self._inspect_memory_hogs()))
        except Exception as e:
            sections.append(("Memory And Running Apps", f"Unavailable: {e}"))

        if any(word in lowered for word in ["app", "apps", "applications", "running", "process", "ram", "memory"]):
            try:
                sections.append(("Application Activity", self._application_activity_report_tool()))
            except Exception as e:
                sections.append(("Application Activity", f"Unavailable: {e}"))

        if any(word in lowered for word in ["storage", "downloads", "download", "optim", "cleanup", "clean up", "desktop", "documents"]):
            try:
                sections.append(("Optimisation And File Review", self._optimise_scan_tool()))
            except Exception as e:
                sections.append(("Optimisation And File Review", f"Unavailable: {e}"))

        if any(word in lowered for word in ["system", "mac", "storage", "disk"]):
            try:
                sections.append(("System Report", self._system_report_tool()))
            except Exception as e:
                sections.append(("System Report", f"Unavailable: {e}"))

        report = "KIRA OS Read-Only Report Context\n"
        report += "Original task: " + prompt_text + "\n"
        report += "Generated at: " + self._format_timestamp(time.time()) + "\n"
        report += "Safety: read-only inspection only; no files/apps were modified, deleted, moved, installed, or quit.\n\n"

        for title, body in sections:
            report += f"## {title}\n{self._truncate(body, 12000)}\n\n"

        self.last_report_context = self._truncate(report, 50000)
        return self.last_report_context

    def _prompt_specific_artifact_title(self, raw_prompt, kind):
        text = re.sub(r"\s+", " ", str(raw_prompt or "")).strip()
        explicit_title = re.search(
            r"(?i)\b(?:titled|title|called|named)\s+['\"]?(.+?)(?=\s+(?:about|with|for|on|from|using|slides?|slide\s*:|and\s+slides?|that|which)\b|[.?!]|$)",
            text
        )
        if explicit_title:
            title = re.sub(r"[^A-Za-z0-9 _-]+", " ", explicit_title.group(1))
            title = re.sub(r"\s+", " ", title).strip(" -_")
            if title:
                return self._truncate(title[:80].title(), 92)

        text = re.sub(
            r"(?i)\b(generate|genertae|create|make|build|export|convert|pptx?|powerpoint|presentation|deck|docx|word|document|pdf|report|open|it)\b",
            "",
            text
        )
        text = re.sub(r"[^A-Za-z0-9 _-]+", " ", text)
        text = re.sub(r"(?i)\b(a|an|the|about|on|for|of)\b", " ", text)
        text = re.sub(r"\s+", " ", text).strip(" -_")
        if not text:
            labels = {"pptx": "KIRA Deck", "docx": "KIRA Document", "pdf": "KIRA PDF"}
            return labels.get(str(kind or "").lower(), "KIRA Artifact")
        return self._truncate("KIRA - " + text[:70].title(), 92)

    def _generate_fallback_report_artifact(self, kind, raw_prompt, context, chat_id):
        title = self._prompt_specific_artifact_title(raw_prompt, kind)
        subtitle = "Generated from the current KIRA OS request"
        summary = self._fallback_summary_from_context(context)
        memory_excerpt = self._report_clean(self._section_excerpt(context, "Memory And Running Apps", 1600))
        apps_excerpt = self._report_clean(self._section_excerpt(context, "Application Activity", 1600))
        optimise_excerpt = self._report_clean(self._section_excerpt(context, "Optimisation And File Review", 1800))
        system_excerpt = self._report_clean(self._section_excerpt(context, "System Report", 1400))

        if kind == "docx":
            block = f"""TITLE: {title}
SUBTITLE: {subtitle}
HEADING: Executive Summary
PARAGRAPH: {summary}
HEADING: System Snapshot
PARAGRAPH: {system_excerpt or 'System snapshot was gathered read-only.'}
HEADING: Running Apps And RAM
PARAGRAPH: {memory_excerpt or apps_excerpt or 'Running app and memory data was gathered read-only.'}
HEADING: Storage And File Review
PARAGRAPH: {optimise_excerpt or 'No storage cleanup action was performed. Review candidates before deleting or moving anything.'}
HEADING: Safe Optimization Plan
BULLET: Review the largest memory consumers before quitting anything.
BULLET: Move/archive old downloads and installers only after confirming they are no longer needed.
BULLET: Do not delete system folders, app support folders, or unclear files without a second check.
BULLET: Ask KIRA OS to proceed only with exact named files or apps.
HEADING: Original Request
PARAGRAPH: {self._report_clean(raw_prompt)}
"""
            result = self._generate_native_docx(block)
        elif kind == "pdf":
            content = (
                f"{subtitle}\n\nExecutive Summary\n{summary}\n\n"
                f"System Snapshot\n{system_excerpt}\n\n"
                f"Running Apps And RAM\n{memory_excerpt or apps_excerpt}\n\n"
                f"Storage And File Review\n{optimise_excerpt}\n\n"
                "Safe Optimization Plan\n"
                "- Review memory consumers before quitting anything.\n"
                "- Archive old downloads/installers only after confirming.\n"
                "- Ask before moving or deleting exact named files.\n"
            )
            response = f"[NATIVE_PDF]\nTITLE: {title}\nCONTENT: {content}\n[/NATIVE_PDF]"
            result = self._generate_native_pdf(response)
        else:
            table_rows = self._fallback_top_process_table(context)
            block = f"""TITLE: {title}
SUBTITLE: {subtitle}
THEME: dark
SLIDE: Executive Summary
BODY: {summary}
BULLET: KIRA OS performed read-only inspection only.
BULLET: No files, apps, installs, or system settings were changed.
SLIDE: System Snapshot
BODY: {system_excerpt or 'System snapshot was gathered read-only.'}
SLIDE: Top Apps And RAM
BODY: {memory_excerpt or apps_excerpt or 'Memory and application data was gathered read-only.'}
TABLE:
Process | Detail
{table_rows}
SLIDE: Storage And Downloads
BODY: {optimise_excerpt or 'Storage review did not identify a confirmed deletion action. User approval is required before moving or deleting files.'}
SLIDE: Risk Review
BULLET: Treat unknown installers, archives, and old downloads as review candidates, not automatic deletions.
BULLET: System and app support folders should not be touched without explicit approval.
BULLET: High RAM usage alone is not malware; confirm app identity and current workload first.
SLIDE: Safe Optimization Plan
BULLET: Confirm the top RAM app before quitting.
BULLET: Archive large old downloads you no longer need.
BULLET: Delete only exact files you name and approve.
BULLET: Re-run KIRA OS after cleanup to verify storage and RAM improvement.
NOTES: Generated by KIRA OS from read-only local inspection context.
"""
            result = self._generate_native_pptx(block)

        artifact_path = self._extract_artifact_path_from_text(result)
        if artifact_path:
            self.response_queue.put({
                "type": "status",
                "content": f"Generated real report: {artifact_path}",
                "chat_id": chat_id
            })
            return (
                "I generated the real report file and added it to the KIRA Menu.\n\n"
                f"{result}\n\n"
                "Nothing was modified, moved, deleted, installed, or quit."
            )

        return result

    def _extract_artifact_path_from_text(self, text):
        for path in re.findall(r"`([^`]+\.(?:pptx|docx|pdf))`", str(text or ""), re.IGNORECASE):
            resolved = self._resolve_path(path)
            if os.path.exists(resolved):
                return resolved
        return ""

    def _fallback_summary_from_context(self, context):
        text = re.sub(r"\s+", " ", str(context or "")).strip()
        if not text:
            return "KIRA OS generated this report from read-only local inspection. No risky action was taken."
        return self._truncate(
            "KIRA OS gathered read-only system, app, memory, storage, and file-review signals. "
            "This report summarizes likely risk areas and a safe optimization plan. "
            "No files/apps were changed; any cleanup or app quitting still requires explicit user approval.",
            900
        )

    def _section_excerpt(self, context, title, limit=1600):
        pattern = rf"(?is)##\s*{re.escape(title)}\s*(.*?)(?:\n##\s+|\Z)"
        match = re.search(pattern, str(context or ""))
        if not match:
            return ""
        return self._truncate(match.group(1).strip(), limit)

    def _report_clean(self, text):
        clean = str(text or "")
        clean = re.sub(r"(?im)^\s*(SLIDE|BODY|TITLE|SUBTITLE|NOTES|TABLE|IMAGE):", r"\1 -", clean)
        clean = re.sub(r"`{3,}[a-zA-Z]*", "", clean)
        clean = clean.replace("```", "")
        clean = re.sub(r"\s+\n", "\n", clean)
        return self._truncate(clean.strip(), 1900)

    def _fallback_top_process_table(self, context):
        rows = []
        for line in str(context or "").splitlines():
            if not re.search(r"\bPID\b|\bMB\b|/Applications|\.app|^\s*\d+\s+", line):
                continue
            clean = re.sub(r"\s+", " ", line.strip())
            if clean and len(clean) < 90:
                rows.append(self._report_clean(clean).replace("|", "/"))
            if len(rows) >= 5:
                break
        if not rows:
            return "Read-only scan | No compact process table available"
        return "\n".join(f"{idx + 1} | {row}" for idx, row in enumerate(rows))

    def _try_agentic_preflight_context(self, prompt, chat_id):
        text = re.sub(r"\s+", " ", str(prompt or "").lower())
        recent_text = " ".join(
            str(message.get("content", ""))
            for message in self._load_chat_messages(chat_id)[-6:]
        ).lower()
        context = text + " " + recent_text
        wants_downloads = any(word in context for word in ["downloads", "download folder", "finder downloads"])
        wants_file_review = any(word in text for word in [
            "unwanted", "junk", "clutter", "suspicious", "weird", "unknown",
            "large", "big", "storage", "space", "clean", "cleanup", "check",
            "scan", "review", "files", "delete", "remove"
        ])
        wants_virus_scan = any(word in text for word in [
            "virus", "malware", "trojan", "spyware", "adware", "infected",
            "infection", "security scan", "scan for threats", "threat scan"
        ])
        wants_optimise = any(word in text for word in [
            "/optimise", "/optimize", "optimise my", "optimize my",
            "optimise computer", "optimize computer", "optimise mac", "optimize mac",
            "clean up my computer", "clean my computer", "free up space",
            "storage cleanup", "massive data control", "mass data control"
        ])
        wants_live_snapshot = (
            any(phrase in text for phrase in [
                "what is going on", "what's going on", "whats going on",
                "live view", "live status", "current computer", "right now"
            ])
            and any(word in text for word in ["computer", "mac", "system", "laptop"])
        )
        wants_application_activity = (
            any(word in context for word in ["application", "applications", "apps", "processes", "process"])
            and any(word in text for word in ["track", "monitor", "analyse", "analyze", "report", "ppt", "pptx", "presentation", "deck", "all"])
        )

        if wants_live_snapshot:
            self.response_queue.put({
                "type": "status",
                "content": "Orchestrator V1 is reading a live computer snapshot...",
                "chat_id": chat_id
            })
            snapshot = self.get_live_snapshot()
            self.last_agentic_intent = "live_snapshot"
            self.last_agentic_result = snapshot
            return (
                "READ_ONLY_LIVE_SNAPSHOT\n"
                "Context note: This is a live read-only OS snapshot. No files or apps were changed.\n\n"
                + json.dumps(snapshot, indent=2, ensure_ascii=False)
            )

        if wants_virus_scan:
            scope = self._detect_scan_scope_from_text(text)
            if scope:
                self.response_queue.put({
                    "type": "status",
                    "content": "Orchestrator V1 is scanning read-only for malware signals...",
                    "chat_id": chat_id
                })
                findings = self._virus_scan_tool(scope)
                self.last_agentic_intent = "virus_scan"
                self.last_agentic_result = findings
                return (
                "READ_ONLY_VIRUS_SCAN\n"
                f"Scope: {scope}\n"
                    "Context note: No files were changed, deleted, quarantined, or executed. "
                    "Analyze these findings naturally and give the next safe step.\n\n"
                    + findings
                )

        if wants_optimise:
            self.response_queue.put({
                "type": "status",
                "content": "Orchestrator V1 is running a read-only optimisation scan...",
                "chat_id": chat_id
            })
            findings = self._optimise_scan_tool()
            self.last_agentic_intent = "optimise_scan"
            self.last_agentic_result = findings
            return (
                "READ_ONLY_OPTIMISE_SCAN\n"
                "Context note: No files or apps were changed, moved, deleted, quarantined, or opened. "
                "Use these findings to recommend a safe cleanup plan. "
                "If the next step would move or delete data, the backend will ask for exact approval.\n\n"
                + findings
            )

        if wants_application_activity:
            self.response_queue.put({
                "type": "status",
                "content": "Orchestrator V1 is gathering application activity read-only...",
                "chat_id": chat_id
            })
            findings = self._application_activity_report_tool()
            self.last_agentic_intent = "application_activity"
            self.last_agentic_result = findings
            return (
                "READ_ONLY_APPLICATION_ACTIVITY\n"
                "Context note: This is a live read-only application/process snapshot. No files, apps, or settings were changed. "
                "Use this data to answer, analyze, or generate the requested artifact.\n\n"
                + findings
            )

        if wants_downloads and wants_file_review:
            self.response_queue.put({
                "type": "status",
                "content": "Orchestrator V1 is inspecting Downloads read-only...",
                "chat_id": chat_id
            })
            findings = self._inspect_downloads_for_unwanted()
            self.last_agentic_intent = "downloads_review"
            self.last_agentic_result = findings
            return (
                "READ_ONLY_FILE_CHECK\n"
                "Scope: Downloads\n"
                "Context note: No files were opened in a sensitive path, no files were changed, and no files were deleted.\n"
                "Use these findings to answer naturally. Keep raw tables out unless the user asks for details.\n\n"
                + findings
            )

        return ""

    def _detect_scan_scope_from_text(self, text):
        lowered = str(text or "").lower()

        if lowered.strip() in {"/virus", "/malware", "/safety-scan", "/safetyscan"}:
            return self._resolve_path("downloads")

        aliases = [
            ("downloads", "downloads"),
            ("download folder", "downloads"),
            ("finder downloads", "downloads"),
            ("desktop", "desktop"),
            ("documents", "documents"),
            ("kira project", "kira_project"),
            ("project", "kira_project"),
            ("agentic workspace", "agentic_workspace"),
            ("applications", "applications"),
            ("apps", "applications"),
        ]

        for marker, alias in aliases:
            if marker in lowered:
                return self._resolve_path(alias)

        path_match = re.search(r"(?:in|inside|at|under)\s+((?:~|/)[^\n\r]+)$", str(text or ""), re.IGNORECASE)
        if path_match:
            return self._resolve_path(path_match.group(1).strip())

        if "computer" in lowered or "mac" in lowered or "system" in lowered:
            return self._resolve_path("downloads")

        return ""

    def _try_direct_agentic_shortcut(self, prompt, chat_id):
        # No hardcoded semantic shortcuts here. Orchestrator V1 chooses the pathway.
        return None

    def _inspect_downloads_for_unwanted(self):
        downloads_path = self.computer_roots.get("downloads") or os.path.join(self.home_path, "Downloads")

        if not os.path.exists(downloads_path):
            return f"I could not find your Downloads folder at `{downloads_path}`."
        if not os.path.isdir(downloads_path):
            return f"`{downloads_path}` exists, but it is not a folder."
        if self._is_sensitive_path(downloads_path):
            return "Downloads looked sensitive under the current guard rules, so I did not inspect it."

        now = time.time()
        installers = {".dmg", ".pkg", ".zip", ".rar", ".7z", ".tar", ".gz", ".xz", ".iso"}
        media = {".mp4", ".mov", ".mkv", ".avi", ".mp3", ".wav", ".flac"}
        temp_markers = (".crdownload", ".download", ".part", ".tmp")
        entries = []
        skipped = 0

        try:
            for entry in os.scandir(downloads_path):
                try:
                    if entry.name.startswith("."):
                        skipped += 1
                        continue

                    full = entry.path
                    if self._is_sensitive_path(full):
                        skipped += 1
                        continue

                    stat = entry.stat()
                    ext = os.path.splitext(entry.name)[1].lower()
                    age_days = max(0, int((now - stat.st_mtime) / 86400))
                    size = stat.st_size if entry.is_file(follow_symlinks=False) else 0
                    kind = "folder" if entry.is_dir(follow_symlinks=False) else "file"
                    reasons = []

                    if ext in installers:
                        reasons.append("installer/archive")
                    if ext in media and size >= 300 * 1024 * 1024:
                        reasons.append("large media")
                    if size >= 500 * 1024 * 1024:
                        reasons.append("large file")
                    if age_days >= 60:
                        reasons.append("old")
                    if entry.name.lower().endswith(temp_markers):
                        reasons.append("partial/temp download")
                    if re.search(r"\(\d+\)| copy\b| duplicate\b", entry.name, re.IGNORECASE):
                        reasons.append("possible duplicate")

                    entries.append({
                        "name": entry.name,
                        "path": full,
                        "kind": kind,
                        "size": size,
                        "age_days": age_days,
                        "reasons": reasons
                    })
                except Exception:
                    skipped += 1
        except Exception as e:
            return f"Downloads inspection failed: {e}"

        total_size = sum(item["size"] for item in entries)
        flagged = [item for item in entries if item["reasons"]]
        largest = sorted(entries, key=lambda item: item["size"], reverse=True)[:10]
        old_items = sorted(
            [item for item in entries if item["age_days"] >= 30],
            key=lambda item: item["age_days"],
            reverse=True
        )[:10]

        def size_label(value):
            units = ["B", "KB", "MB", "GB", "TB"]
            amount = float(value)
            unit = 0
            while amount >= 1024 and unit < len(units) - 1:
                amount /= 1024
                unit += 1
            return f"{amount:.1f}{units[unit]}" if unit else f"{int(amount)}B"

        def rows(items, include_reason=True):
            if not items:
                return "(none)"

            lines = []
            for item in items:
                reason = ", ".join(item["reasons"]) if item["reasons"] else "review if needed"
                if include_reason:
                    lines.append(f"{size_label(item['size']):>9}  {item['age_days']:>4}d  {reason:<24}  {item['name']}")
                else:
                    lines.append(f"{size_label(item['size']):>9}  {item['age_days']:>4}d  {item['name']}")
            return "\n".join(lines)

        return (
            "I inspected your Downloads folder read-only. I did not delete or change anything.\n\n"
            f"Folder: `{downloads_path}`\n"
            f"Visible items checked: `{len(entries)}`\n"
            f"Skipped hidden/sensitive/unreadable items: `{skipped}`\n"
            f"Approx visible file size: `{size_label(total_size)}`\n\n"
            "Most likely cleanup candidates:\n"
            "```text\n"
            "     size   age   reason                    name\n"
            + rows(sorted(flagged, key=lambda item: (len(item['reasons']), item["size"], item["age_days"]), reverse=True)[:15])
            + "\n```\n\n"
            "Largest visible items:\n"
            "```text\n"
            "     size   age   name\n"
            + rows(largest, include_reason=False)
            + "\n```\n\n"
            "Old visible items:\n"
            "```text\n"
            "     size   age   name\n"
            + rows(old_items, include_reason=False)
            + "\n```\n\n"
            "Nothing was removed. If you want cleanup, tell me which files to delete or ask me to prepare a delete list first."
        )

    def _split_orchestrator_response(self, response):
        text = unescape(str(response or "")).strip()
        text = re.sub(
            r"(?is)<\s*/?\s*thought[_ -]?process\s*>",
            lambda match: "</thought_process>" if "/" in match.group(0) else "<thought_process>",
            text
        )
        text = re.sub(
            r"(?is)\[\s*/?\s*thought[_ -]?process\s*\]",
            lambda match: "</thought_process>" if "/" in match.group(0) else "<thought_process>",
            text
        )

        full_match = re.search(r"(?is)<thought_process>(.*?)</thought_process>(.*)$", text)
        if full_match:
            return full_match.group(1).strip(), full_match.group(2).strip()

        if "</thought_process>" in text:
            thoughts, final = text.split("</thought_process>", 1)
            thoughts = thoughts.replace("<thought_process>", "").strip()
            return thoughts, final.strip()

        if "<thought_process>" in text:
            thoughts = text.split("<thought_process>", 1)[1].strip()
            return thoughts, ""

        native_match = re.search(r"(?is)<\|channel\>\s*(?:thought|analysis|reasoning)?\s*(.*?)<channel\|>(.*)$", text)
        if native_match:
            return native_match.group(1).strip(), native_match.group(2).strip()

        if "<|channel>" in text:
            thoughts = text.split("<|channel>", 1)[1].strip()
            thoughts = re.sub(r"(?is)^(?:thought|analysis|reasoning)\s*", "", thoughts).strip()
            return thoughts, ""

        if self._looks_like_private_reasoning(text) and self._extract_agentic_blocks(text):
            return text, ""

        return "", text

    def _looks_like_private_reasoning(self, text):
        value = str(text or "").strip()
        if not value:
            return False
        head = "\n".join(value.splitlines()[:18]).lower()
        private_markers = [
            "thought process", "orchestrator logic", "tree-of-thought", "tree of thought",
            "tot reasoning", "private reasoning", "intent:", "slots:", "clarify:",
            "plan:", "inspect:", "permission:", "execute:", "verify:", "report:",
            "workflow state", "safety check", "branch a", "branch b"
        ]
        return sum(1 for marker in private_markers if marker in head) >= 2

    def _strip_private_reasoning(self, text):
        cleaned = unescape(str(text or ""))
        cleaned = re.sub(r"(?is)<\s*thought[_ -]?process\s*>.*?<\s*/\s*thought[_ -]?process\s*>", "", cleaned)
        cleaned = re.sub(r"(?is)<\s*thought[_ -]?process\s*>.*$", "", cleaned)
        cleaned = re.sub(r"(?is)^.*?<\s*/\s*thought[_ -]?process\s*>", "", cleaned)
        cleaned = re.sub(r"(?is)<(?:analysis|reasoning|chain_of_thought|private_reasoning|scratchpad)>.*?</(?:analysis|reasoning|chain_of_thought|private_reasoning|scratchpad)>", "", cleaned)
        cleaned = re.sub(r"(?is)<(?:analysis|reasoning|chain_of_thought|private_reasoning|scratchpad)>.*$", "", cleaned)
        cleaned = re.sub(r"(?is)\[\s*(?:THOUGHT_PROCESS|PRIVATE_REASONING|CHAIN_OF_THOUGHT|TOT_REASONING|SCRATCHPAD)\s*\].*?\[\s*/\s*(?:THOUGHT_PROCESS|PRIVATE_REASONING|CHAIN_OF_THOUGHT|TOT_REASONING|SCRATCHPAD)\s*\]", "", cleaned)
        cleaned = re.sub(r"(?is)\[\s*(?:THOUGHT_PROCESS|PRIVATE_REASONING|CHAIN_OF_THOUGHT|TOT_REASONING|SCRATCHPAD)\s*\].*$", "", cleaned)
        cleaned = re.sub(r"(?is)<\|channel\>\s*(?:thought|analysis|reasoning)?\s*.*?<channel\|>", "", cleaned)
        cleaned = re.sub(r"(?is)<\|channel\>\s*(?:thought|analysis|reasoning)?\s*.*$", "", cleaned)
        cleaned = re.sub(r"(?is)<\|tool_call\|>.*?(?:<tool_call\|>|$)", "", cleaned)
        cleaned = re.sub(r"(?is)<\|/?(?:tool_call|tool_response|channel|turn|think|end)\|>", "", cleaned)
        cleaned = re.sub(r"(?is)<(?:tool_call|tool_response|channel|turn)\|>", "", cleaned)
        cleaned = re.sub(r"(?is)</?\s*start_of_turn\s*>", "", cleaned)
        cleaned = re.sub(r"(?is)</?\s*end_of_turn\s*>", "", cleaned)
        cleaned = re.sub(r"(?is)<\s*(?:bos|eos|pad|unk)\s*>", "", cleaned)
        cleaned = self._strip_private_reasoning_lines(cleaned)
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
        return cleaned.strip()

    def _strip_private_reasoning_lines(self, text):
        lines = str(text or "").splitlines()
        kept = []
        suppress_until_blank = False
        private_heading = re.compile(
            r"^\s*(?:#+\s*)?(?:orchestrator\s+logic|thought\s*process|private\s*reasoning|chain\s*of\s*thought|tree\s*of\s*thought|tot\s*reasoning|scratchpad|internal\s*(?:plan|logic|reasoning))\s*:?\s*",
            re.IGNORECASE
        )
        private_label = re.compile(
            r"^\s*(?:[-*]\s*)?(?:\d+[.)]\s*)?(INTENT|SLOTS|CLARIFY|PLAN|INSPECT|PERMISSION|EXECUTE|VERIFY|REPORT|WORKFLOW STATE|SAFETY CHECK|BRANCH [A-Z0-9_-]+|THOUGHT|THOUGHTS|RATIONALE)\s*:",
            re.IGNORECASE
        )
        tool_start = re.compile(
            r"^\s*(?:\[\s*(?:OS_MAP|SYSTEM_REPORT|MEMORY_REPORT|APP_LIST|WINDOW_REPORT|VIRUS_SCAN|OPTIMISE_SCAN|READ_FILE|LIST_DIR|SEARCH_FILES|FIND_IN_COMPUTER|NATIVE_PDF|NATIVE_PPTX|NATIVE_DOCX|OPEN|CLOSE|WEB_SEARCH|WEB_OPEN|WEB_FETCH|WEB_BROWSE|WEB_HEADLESS|IDE_CONTEXT|IDE_PASTE_RUN|PROJECT_INDEX|MCP_DISCOVER|MCP_BOOTSTRAP|MCP_DRAFT|APP_INTEGRATION|BLENDER_CONTEXT|SCHEDULE_TASK|SHELL|COMMAND|TERMINAL|APPLESCRIPT)\s*\]|```(?:bash|sh|zsh|shell|terminal))",
            re.IGNORECASE
        )

        for line in lines:
            stripped = line.strip()

            if tool_start.match(line):
                suppress_until_blank = False
                kept.append(line)
                continue

            if private_heading.match(line) or private_label.match(line):
                suppress_until_blank = True
                continue

            if suppress_until_blank:
                if not stripped:
                    suppress_until_blank = False
                continue

            kept.append(line)

        return "\n".join(kept)

    def _extract_agentic_blocks(self, text):
        blocks = []
        if not text:
            return ""

        tags = [
            "HYBRID_ACTIONS",
            "OS_MAP", "SYSTEM_REPORT", "MEMORY_REPORT", "VIRUS_SCAN", "OPTIMISE_SCAN",
            "APP_LIST", "WINDOW_REPORT", "SCREENSHOT_CONTEXT", "NETWORK_REPORT",
            "IDE_CONTEXT", "IDE_PASTE_RUN", "PROJECT_INDEX", "MCP_DISCOVER", "MCP_BOOTSTRAP", "MCP_DRAFT",
            "APP_INTEGRATION", "BLENDER_CONTEXT",
            "READ_FILE", "LIST_DIR", "SEARCH_FILES", "FIND_IN_COMPUTER",
            "CLIPBOARD_READ", "CLIPBOARD_WRITE", "HASH_FILE", "FILE_COMPARE",
            "ARCHIVE_PREVIEW", "ZIP_CREATE", "NOTE_DRAFT", "CALENDAR_DRAFT", "REMINDER_DRAFT",
            "NATIVE_PDF", "NATIVE_PPTX", "NATIVE_DOCX", "PDF_TO_PPTX", "WRITE_FILE",
            "APPEND_FILE", "DELETE_PATH", "MOVE_PATH", "OPEN", "CLOSE",
            "WEB_SEARCH", "WEB_OPEN", "WEB_FETCH", "WEB_BROWSE", "WEB_HEADLESS",
            "MCP_SETUP", "MCP_APPLY", "IDE_OPEN", "PROJECT_COMMAND", "SCHEDULE_TASK",
            "PYTHON", "APPLESCRIPT", "SHELL", "COMMAND", "TERMINAL"
        ]

        for tag in tags:
            for block in self._extract_blocks(text, tag):
                blocks.append(f"[{tag}]{block}[/{tag}]")

        for block in re.findall(r"```(?:bash|sh|zsh|shell|terminal)\s*(.*?)```", str(text), re.DOTALL | re.IGNORECASE):
            blocks.append("```bash\n" + block.strip() + "\n```")

        for command in self._extract_inline_tool_commands(text, {"COMMAND", "SHELL", "TERMINAL"}):
            blocks.append("[SHELL]\n" + command.strip() + "\n[/SHELL]")

        for command in self._extract_inline_tool_commands(text, {"APPLESCRIPT"}):
            blocks.append("[APPLESCRIPT]\n" + command.strip() + "\n[/APPLESCRIPT]")

        bracket_command = self._extract_bracket_command(text)
        if bracket_command:
            blocks.append("```bash\n" + bracket_command + "\n```")

        return "\n\n".join(blocks)

    def _strip_agentic_blocks(self, text):
        cleaned = str(text or "")
        tags = [
            "HYBRID_ACTIONS",
            "OS_MAP", "SYSTEM_REPORT", "MEMORY_REPORT", "VIRUS_SCAN", "OPTIMISE_SCAN",
            "APP_LIST", "WINDOW_REPORT", "SCREENSHOT_CONTEXT", "NETWORK_REPORT",
            "IDE_CONTEXT", "IDE_PASTE_RUN", "PROJECT_INDEX", "MCP_DISCOVER", "MCP_BOOTSTRAP", "MCP_DRAFT",
            "APP_INTEGRATION", "BLENDER_CONTEXT",
            "READ_FILE", "LIST_DIR", "SEARCH_FILES", "FIND_IN_COMPUTER",
            "CLIPBOARD_READ", "CLIPBOARD_WRITE", "HASH_FILE", "FILE_COMPARE",
            "ARCHIVE_PREVIEW", "ZIP_CREATE", "NOTE_DRAFT", "CALENDAR_DRAFT", "REMINDER_DRAFT",
            "NATIVE_PDF", "NATIVE_PPTX", "NATIVE_DOCX", "PDF_TO_PPTX", "WRITE_FILE",
            "APPEND_FILE", "DELETE_PATH", "MOVE_PATH", "OPEN", "CLOSE",
            "WEB_SEARCH", "WEB_OPEN", "WEB_FETCH", "WEB_BROWSE", "WEB_HEADLESS",
            "MCP_SETUP", "MCP_APPLY", "IDE_OPEN", "PROJECT_COMMAND", "SCHEDULE_TASK",
            "PYTHON", "APPLESCRIPT", "SHELL", "COMMAND", "TERMINAL"
        ]

        for tag in tags:
            cleaned = re.sub(rf"(?is)\[\s*{tag}\s*\].*?\[\s*/\s*{tag}\s*\]", "", cleaned)

        cleaned = re.sub(r"(?is)```(?:bash|sh|zsh|shell|terminal)\s*.*?```", "", cleaned)
        cleaned = re.sub(r"(?im)^\s*(?:\[\s*)?(?:COMMAND|SHELL|TERMINAL|APPLESCRIPT)(?:\s*\])?\s*:\s*.+$", "", cleaned)
        cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)
        return cleaned.strip()

    def _extract_bracket_command(self, text):
        matches = re.findall(r"(?m)^\s*\[([A-Za-z0-9_./ -][^\]\n]{2,220})\]\s*$", str(text or ""))
        for candidate in matches:
            candidate = candidate.strip()
            first = candidate.split()[0] if candidate.split() else ""
            if first in self.safe_shell_commands or first == "git":
                return candidate
        return ""

    def _run_agentic_capabilities(self, response_text, raw_prompt, chat_id):
        previous_permission_context = getattr(self, "_active_permission_context", None)
        self._active_permission_context = {
            "raw_prompt": str(raw_prompt or ""),
            "model_output": self._truncate(str(response_text or ""), 6000),
            "ledger_id": getattr(self, "active_execution_ledger_id", "")
        }

        try:
            response_text = self._run_agentic_capabilities_inner(response_text, raw_prompt, chat_id)
        finally:
            self._active_permission_context = previous_permission_context

        return response_text

    def _run_agentic_capabilities_inner(self, response_text, raw_prompt, chat_id):
        response_text = self._unwrap_hybrid_actions(response_text)
        response_text = self._run_os_surface_tools(response_text, chat_id)
        response_text = self._run_read_tools(response_text, chat_id)
        response_text = self._run_find_in_computer_blocks(response_text, chat_id)
        response_text = self._run_utility_tools(response_text, chat_id)
        response_text = self._run_web_search_tools(response_text)
        response_text = self._generate_native_pdf(response_text)
        response_text = self._generate_native_pptx_blocks(response_text)
        response_text = self._generate_native_docx_blocks(response_text)
        response_text = self._queue_pdf_to_pptx_blocks(response_text, chat_id)
        response_text = self._run_open_tools(response_text)
        response_text = self._run_scheduler_tools(response_text, raw_prompt, chat_id)
        response_text = self._run_permissioned_blocks(response_text, chat_id)
        response_text = self._execute_agentic_code(response_text, chat_id)

        bracket_command = self._extract_bracket_command(response_text)
        if bracket_command:
            response_text += "\n\n" + self._execute_or_request_command(bracket_command, chat_id)

        return response_text

    def _unwrap_hybrid_actions(self, response_text):
        return re.sub(
            r"(?is)\[\s*HYBRID_ACTIONS\s*\](.*?)\[\s*/\s*HYBRID_ACTIONS\s*\]",
            lambda match: match.group(1).strip(),
            str(response_text or "")
        )

    def _run_os_surface_tools(self, response_text, chat_id):
        for block in self._extract_blocks(response_text, "OS_MAP"):
            result = self._os_map_tool()
            response_text = self._replace_block_once(response_text, "OS_MAP", block, result)

        for block in self._extract_blocks(response_text, "SYSTEM_REPORT"):
            result = self._system_report_tool()
            response_text = self._replace_block_once(response_text, "SYSTEM_REPORT", block, result)

        for block in self._extract_blocks(response_text, "APP_LIST"):
            result = self._app_list_tool()
            self.last_agentic_intent = "app_list"
            self.last_agentic_result = result
            response_text = self._replace_block_once(response_text, "APP_LIST", block, result)

        for block in self._extract_blocks(response_text, "WINDOW_REPORT"):
            result = self._window_report_tool()
            self.last_agentic_intent = "window_report"
            self.last_agentic_result = result
            response_text = self._replace_block_once(response_text, "WINDOW_REPORT", block, result)

        for block in self._extract_blocks(response_text, "SCREENSHOT_CONTEXT"):
            result = self._screenshot_context_tool()
            self.last_agentic_intent = "screenshot_context"
            self.last_agentic_result = result
            response_text = self._replace_block_once(response_text, "SCREENSHOT_CONTEXT", block, result)

        for block in self._extract_blocks(response_text, "NETWORK_REPORT"):
            result = self._network_report_tool()
            self.last_agentic_intent = "network_report"
            self.last_agentic_result = result
            response_text = self._replace_block_once(response_text, "NETWORK_REPORT", block, result)

        for block in self._extract_blocks(response_text, "MEMORY_REPORT"):
            result = self._inspect_memory_hogs()
            self.last_agentic_intent = "memory_report"
            self.last_agentic_result = result
            response_text = self._replace_block_once(response_text, "MEMORY_REPORT", block, result)

        for block in self._extract_blocks(response_text, "VIRUS_SCAN"):
            fields = self._parse_fields(block)
            path = self._resolve_path(fields.get("path", fields.get("scope", "downloads")))
            if self._is_read_allowed(path):
                result = self._virus_scan_tool(path)
                self.last_agentic_intent = "virus_scan"
                self.last_agentic_result = result
            else:
                result = self._queue_permission(
                    "virus_scan",
                    {"path": path},
                    self._read_permission_preview(path),
                    chat_id
                )
            response_text = self._replace_block_once(response_text, "VIRUS_SCAN", block, result)

        for block in self._extract_blocks(response_text, "OPTIMISE_SCAN"):
            result = self._optimise_scan_tool()
            self.last_agentic_intent = "optimise_scan"
            self.last_agentic_result = result
            response_text = self._replace_block_once(response_text, "OPTIMISE_SCAN", block, result)

        for block in self._extract_blocks(response_text, "IDE_CONTEXT"):
            fields = self._parse_fields(block)
            path = self._resolve_path(fields.get("path", self.app_root))
            result = self._ide_context_tool(path)
            response_text = self._replace_block_once(response_text, "IDE_CONTEXT", block, result)

        for block in self._extract_blocks(response_text, "PROJECT_INDEX"):
            fields = self._parse_fields(block)
            path = self._resolve_path(fields.get("path", self.app_root))
            max_files = fields.get("max_files", "600")
            if self._is_read_allowed(path):
                result = self._project_index_tool(path, max_files)
            else:
                result = self._queue_permission(
                    "project_index",
                    {"path": path, "max_files": max_files},
                    self._read_permission_preview(path),
                    chat_id
                )
            response_text = self._replace_block_once(response_text, "PROJECT_INDEX", block, result)

        for block in self._extract_blocks(response_text, "MCP_DISCOVER"):
            result = self._mcp_discover_tool()
            response_text = self._replace_block_once(response_text, "MCP_DISCOVER", block, result)

        for block in self._extract_blocks(response_text, "MCP_BOOTSTRAP"):
            fields = self._parse_fields(block)
            result = self._mcp_bootstrap_tool(fields.get("target", "cursor_project"))
            response_text = self._replace_block_once(response_text, "MCP_BOOTSTRAP", block, result)

        for block in self._extract_blocks(response_text, "MCP_DRAFT"):
            fields = self._parse_fields(block)
            payload = {
                "name": fields.get("name", "kira_connector"),
                "command": fields.get("command", ""),
                "args_json": fields.get("args_json", "[]"),
                "env_json": fields.get("env_json", "{}"),
                "config_json": fields.get("config_json", "")
            }
            result = self._create_mcp_config_draft(payload)
            response_text = self._replace_block_once(response_text, "MCP_DRAFT", block, result)

        for block in self._extract_blocks(response_text, "APP_INTEGRATION"):
            fields = self._parse_fields(block)
            app_name = fields.get("app") or fields.get("name") or fields.get("target") or block.strip()
            action = fields.get("action", "context")
            result = self._app_integration_tool(app_name, action=action)
            response_text = self._replace_block_once(response_text, "APP_INTEGRATION", block, result)

        for block in self._extract_blocks(response_text, "BLENDER_CONTEXT"):
            result = self._blender_context_tool()
            response_text = self._replace_block_once(response_text, "BLENDER_CONTEXT", block, result)

        return response_text

    def _os_map_tool(self):
        rows = []

        for label, path in self.computer_roots.items():
            exists = os.path.exists(path)
            if exists and os.path.isdir(path):
                try:
                    count = len(os.listdir(path))
                except Exception:
                    count = "locked"
            else:
                count = "-"
            rows.append(f"{label:<20} {str(exists):<5} {str(count):>8}  {path}")

        return (
            "KIRA OS readable computer map:\n"
            "```\n"
            "alias                exists    entries  path\n"
            + "\n".join(rows)
            + "\n```\n"
            f"Manifest: `{os.path.join(self.agentic_workspace, 'kira_os_accessible_map.json')}`\n"
            "Read-only exploration is allowed in these roots unless a path looks sensitive. "
            "Writes, app opening, installs, Python, AppleScript, and risky shell still require permission."
        )

    def _system_report_tool(self):
        sections = []

        for label, command in [
            ("User", "whoami"),
            ("Date", "date"),
            ("macOS Kernel", "uname -a"),
            ("Disk Usage", "df -h"),
            ("Memory Pressure", "vm_stat")
        ]:
            try:
                res = self._run_seatbelt_subprocess(
                    command,
                    shell=True,
                    mode="read_only",
                    timeout=6
                )
                output = res.stdout if res.returncode == 0 else res.stderr
                sections.append(f"{label}:\n{self._truncate(output.strip() or '(no output)', 3000)}")
            except Exception as e:
                sections.append(f"{label}:\nERROR: {e}")

        return "SYSTEM REPORT:\n```\n" + "\n\n".join(sections) + "\n```"

    def _app_list_tool(self):
        app_roots = [
            "/Applications",
            "/System/Applications",
            os.path.join(self.home_path, "Applications")
        ]
        apps = []
        deadline = time.time() + 8

        for root in app_roots:
            if not os.path.isdir(root):
                continue
            try:
                for current_root, dirs, _files in os.walk(root):
                    if time.time() > deadline or len(apps) >= 220:
                        dirs[:] = []
                        break
                    for dirname in dirs:
                        if dirname.endswith(".app"):
                            apps.append(os.path.join(current_root, dirname))
                            if len(apps) >= 220:
                                break
                    dirs[:] = [
                        d for d in dirs
                        if not d.endswith(".app") and current_root.count(os.sep) - root.count(os.sep) < 2
                    ]
            except Exception:
                continue

        running = []
        try:
            res = self._run_seatbelt_subprocess(
                "ps axco command | sort | uniq | head -120",
                shell=True,
                mode="read_only",
                timeout=15
            )
            running = [line.strip() for line in res.stdout.splitlines() if line.strip()]
        except Exception:
            running = []

        apps = sorted(set(apps), key=lambda item: os.path.basename(item).lower())
        app_lines = [os.path.basename(path)[:-4] + "  |  " + path for path in apps[:180]]

        return (
            "APP_LIST:\n"
            "Installed apps sampled:\n"
            "```\n" + ("\n".join(app_lines) or "(none found)") + "\n```\n\n"
            "Running process names sampled:\n"
            "```\n" + ("\n".join(running[:120]) or "(none found)") + "\n```"
        )

    def _window_report_tool(self):
        scripts = [
            (
                "Frontmost app",
                'tell application "System Events" to get name of first application process whose frontmost is true'
            ),
            (
                "Visible apps",
                'tell application "System Events" to get name of every application process whose background only is false'
            ),
            (
                "Window counts",
                'tell application "System Events" to get name of every application process whose background only is false'
            )
        ]

        sections = []
        for label, script in scripts:
            try:
                res = subprocess.run(
                    ["osascript", "-e", script],
                    capture_output=True,
                    text=True,
                    timeout=15
                )
                output = res.stdout if res.returncode == 0 else res.stderr
                sections.append(label + ":\n" + self._truncate(output.strip() or "(no output)", 5000))
            except Exception as e:
                sections.append(f"{label}:\nERROR: {e}")

        return "WINDOW_REPORT:\n```\n" + "\n\n".join(sections) + "\n```"

    def _screenshot_context_tool(self):
        filename = f"kira_screen_{int(time.time())}.png"
        path = os.path.join(self.agentic_workspace, filename)

        try:
            try:
                import vision
                captured = vision.capture_screen()
                if captured and os.path.exists(captured):
                    shutil.copy2(captured, path)
            except Exception:
                pass

            if not os.path.exists(path):
                res = subprocess.run(
                    ["screencapture", "-x", path],
                    capture_output=True,
                    text=True,
                    timeout=20
                )
                if res.returncode != 0:
                    return "SCREENSHOT_CONTEXT failed:\n```\n" + self._truncate((res.stderr or res.stdout).strip() or "(no output)", 4000) + "\n```"

            self._log_agentic_event("screenshot_context", {"path": path})
            return (
                "SCREENSHOT_CONTEXT:\n"
                f"Captured current screen to `{path}`.\n"
                "This is visual context only; no files or apps were changed except saving the screenshot in the KIRA agentic workspace."
            )
        except Exception as e:
            return f"SCREENSHOT_CONTEXT error: {e}"

    def _network_report_tool(self):
        sections = []
        for label, command in [
            ("Network interfaces", "ifconfig | head -120"),
            ("Routes", "netstat -rn | head -80"),
            ("Open network sockets", "netstat -an | head -120"),
            ("DNS", "scutil --dns | head -120")
        ]:
            try:
                res = self._run_seatbelt_subprocess(
                    command,
                    shell=True,
                    mode="read_only",
                    timeout=20
                )
                output = res.stdout if res.returncode == 0 else res.stderr
                sections.append(label + ":\n" + self._truncate(output.strip() or "(no output)", 5000))
            except Exception as e:
                sections.append(f"{label}:\nERROR: {e}")

        return "NETWORK_REPORT:\n```\n" + "\n\n".join(sections) + "\n```"

    def _ide_context_tool(self, path):
        path = self._resolve_path(path or self.app_root)
        cli_rows = []

        for name in ["cursor", "windsurf", "code", "xed", "open", "git", "rg", "python3", "node", "npm", "uv", "pip"]:
            found = shutil.which(name)
            cli_rows.append(f"{name:<10} {found or 'not found'}")

        running = []
        try:
            res = subprocess.run(
                "ps axco command | grep -Ei 'Cursor|Windsurf|Visual Studio Code|Code|Xcode|Python' | head -20",
                shell=True,
                capture_output=True,
                text=True,
                timeout=10
            )
            running = [line.strip() for line in res.stdout.splitlines() if line.strip()]
        except Exception:
            running = []

        markers = []
        for marker in [
            "pyproject.toml", "requirements.txt", "setup.py", "package.json",
            "pnpm-lock.yaml", "vite.config.js", "tsconfig.json", "Cargo.toml",
            "Package.swift", "*.xcodeproj", "*.xcworkspace", "Dockerfile",
            ".cursor", ".vscode", ".git"
        ]:
            if "*" in marker:
                try:
                    matches = [name for name in os.listdir(path) if re.fullmatch(marker.replace("*", ".*"), name)]
                    markers.extend(matches)
                except Exception:
                    pass
            else:
                if os.path.exists(os.path.join(path, marker)):
                    markers.append(marker)

        git_status = "(not a git repo or git unavailable)"
        if os.path.exists(os.path.join(path, ".git")) and shutil.which("git"):
            try:
                res = subprocess.run(
                    ["git", "-C", path, "status", "--short", "--branch"],
                    capture_output=True,
                    text=True,
                    timeout=15
                )
                git_status = self._truncate((res.stdout or res.stderr).strip() or "(clean)", 4000)
            except Exception as e:
                git_status = f"git status failed: {e}"

        context = {
            "project_path": path,
            "ide_bridge": self.ide_bridge_path,
            "mcp_workspace": self.mcp_workspace,
            "detected_markers": markers,
            "running_ide_processes": running,
            "mcp_targets": self.mcp_config_targets
        }

        context_path = os.path.join(self.ide_bridge_path, "last_ide_context.json")
        codex_bridge_path = os.path.join(self.ide_bridge_path, "codex_style_agentic_bridge.json")
        task_queue_path = os.path.join(self.ide_bridge_path, "ide_task_queue.jsonl")
        patch_plan_path = os.path.join(self.ide_bridge_path, "patch_plan.md")
        try:
            with open(context_path, "w", encoding="utf-8") as f:
                json.dump(context, f, indent=2, ensure_ascii=False)
            with open(codex_bridge_path, "w", encoding="utf-8") as f:
                json.dump({
                    "name": "KIRA OS Codex-style IDE bridge",
                    "project_path": path,
                    "context_file": context_path,
                    "task_queue_file": task_queue_path,
                    "patch_plan_file": patch_plan_path,
                    "mcp_workspace": self.mcp_workspace,
                    "mcp_targets": self.mcp_config_targets,
                    "operation_loop": [
                        "discover project/root/markers",
                        "read relevant files before editing",
                        "plan minimal change",
                        "request permission for writes, project commands, installs, or automation",
                        "verify with targeted commands when approved",
                        "report changed files and residual risks"
                    ],
                    "safe_direct_actions": [
                        "read/list/search readable files",
                        "inspect git status/diff/log",
                        "open project/file in IDE",
                        "draft MCP configs in KIRA workspace"
                    ],
                    "permission_required": [
                        "write/edit/delete/move files",
                        "run tests/builds/scripts/servers",
                        "install dependencies",
                        "apply MCP configs to IDE/global app settings",
                        "AppleScript or GUI automation"
                    ]
                }, f, indent=2, ensure_ascii=False)
            if not os.path.exists(task_queue_path):
                with open(task_queue_path, "w", encoding="utf-8") as f:
                    f.write("")
            if not os.path.exists(patch_plan_path):
                with open(patch_plan_path, "w", encoding="utf-8") as f:
                    f.write("# KIRA OS Patch Plan\n\nUse this file for proposed implementation steps before approved edits.\n")
        except Exception:
            pass

        return (
            "IDE CONTEXT:\n"
            f"Project: `{path}`\n"
            f"Bridge file: `{context_path}`\n\n"
            "Codex-style bridge:\n"
            f"`{codex_bridge_path}`\n"
            f"Task queue: `{task_queue_path}`\n"
            f"Patch plan: `{patch_plan_path}`\n\n"
            "Detected project markers:\n"
            "```\n" + ("\n".join(markers) or "(none)") + "\n```\n"
            "Available CLIs:\n"
            "```\n" + "\n".join(cli_rows) + "\n```\n"
            "Running IDE/app processes:\n"
            "```\n" + ("\n".join(running) or "(none detected)") + "\n```\n"
            "Git status:\n"
            "```\n" + git_status + "\n```"
        )

    def _connect_ide_tool(self, ide_name, project_path):
        ide_name = str(ide_name or "auto").strip().lower()
        project_path = self._resolve_path(project_path or self.app_root)
        normalized_ide = self._normalize_ide_name(ide_name)

        connection = {
            "ide": normalized_ide,
            "requested_ide": ide_name,
            "project_path": project_path,
            "connected_at": time.time(),
            "connected_label": self._format_timestamp(time.time()),
            "bridge_path": self.ide_bridge_path,
            "mcp_targets": self.mcp_config_targets
        }

        state_path = os.path.join(self.ide_bridge_path, "active_ide_connection.json")
        with open(state_path, "w", encoding="utf-8") as f:
            json.dump(connection, f, indent=2, ensure_ascii=False)

        context = self._ide_context_tool(project_path)
        open_result = self._open_in_ide({
            "path": project_path,
            "line": "",
            "app": normalized_ide
        })

        return (
            f"IDE pathway connected for **{normalized_ide}**.\n"
            f"Connection state: `{state_path}`\n\n"
            f"{open_result}\n\n"
            f"{context}\n\n"
            f"{self._mcp_discover_tool()}"
        )

    def _normalize_ide_name(self, ide_name):
        name = re.sub(r"[^a-z0-9]+", "", str(ide_name or "").lower())

        if name in {"windsurf", "codeiumwindsurf"}:
            return "windsurf"
        if name in {"cursor"}:
            return "cursor"
        if name in {"vscode", "visualstudiocode", "code"}:
            return "code"
        if name in {"xcode", "xed"}:
            return "xcode"
        if name in {"finder"}:
            return "finder"
        if name in {"default", "auto", ""}:
            return "auto"

        return ide_name or "auto"

    def _project_index_tool(self, path, max_files="600"):
        path = self._resolve_path(path or self.app_root)

        try:
            max_files_int = max(50, min(int(max_files or 600), 3000))
        except Exception:
            max_files_int = 600

        skip_dirs = {
            ".git", "__pycache__", "node_modules", ".venv", "venv", "env",
            "dist", "build", ".next", ".cache", "DerivedData", ".pytest_cache"
        }
        files = []
        ext_counts = {}
        key_files = []

        for root, dirs, filenames in os.walk(path):
            dirs[:] = [d for d in dirs if d not in skip_dirs and not d.startswith(".Trash")]

            for filename in filenames:
                full = os.path.join(root, filename)
                rel = os.path.relpath(full, path)

                if self._is_sensitive_path(full):
                    continue

                files.append(rel)
                ext = os.path.splitext(filename)[1].lower() or "(none)"
                ext_counts[ext] = ext_counts.get(ext, 0) + 1

                if filename in {
                    "pyproject.toml", "requirements.txt", "package.json",
                    "tsconfig.json", "vite.config.js", "Dockerfile", "README.md",
                    "Makefile", "Cargo.toml", "Package.swift", "setup.py"
                }:
                    key_files.append(rel)

                if len(files) >= max_files_int:
                    break

            if len(files) >= max_files_int:
                break

        top_ext = sorted(ext_counts.items(), key=lambda item: item[1], reverse=True)[:15]
        index = {
            "path": path,
            "indexed_file_count": len(files),
            "key_files": key_files[:80],
            "top_extensions": top_ext,
            "sample_files": files[:200]
        }

        index_path = os.path.join(self.ide_bridge_path, "last_project_index.json")
        try:
            with open(index_path, "w", encoding="utf-8") as f:
                json.dump(index, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

        return (
            "PROJECT INDEX:\n"
            f"Path: `{path}`\n"
            f"Index file: `{index_path}`\n"
            f"Indexed files: `{len(files)}`\n\n"
            "Key files:\n"
            "```\n" + ("\n".join(key_files[:80]) or "(none)") + "\n```\n"
            "Top extensions:\n"
            "```\n" + ("\n".join(f"{ext:<12} {count}" for ext, count in top_ext) or "(none)") + "\n```\n"
            "Sample files:\n"
            "```\n" + ("\n".join(files[:120]) or "(none)") + "\n```"
        )

    def _mcp_discover_tool(self):
        rows = []

        for name, path in self.mcp_config_targets.items():
            rows.append(f"{name:<26} {str(os.path.exists(path)):<5} {path}")

        drafts = []
        try:
            drafts = [
                os.path.join(self.mcp_workspace, name)
                for name in sorted(os.listdir(self.mcp_workspace))
                if name.endswith(".json")
            ][:50]
        except Exception:
            drafts = []

        return (
            "MCP DISCOVERY:\n"
            "Config targets:\n"
            "```\n"
            "target                     exists path\n"
            + "\n".join(rows)
            + "\n```\n"
            "Drafts:\n"
            "```\n"
            + ("\n".join(drafts) or "(no drafts yet)")
            + "\n```\n"
            "Use MCP_BOOTSTRAP or MCP_DRAFT to create a draft. Use MCP_APPLY to request permission to apply one."
        )

    def _mcp_bootstrap_tool(self, target="cursor_project"):
        roots = [
            self.app_root,
            self.agentic_workspace,
            os.path.join(self.home_path, "Desktop"),
            os.path.join(self.home_path, "Downloads"),
            os.path.join(self.home_path, "Documents")
        ]
        roots = [root for root in roots if os.path.exists(root)]

        config = {
            "mcpServers": {
                "kira-filesystem": {
                    "command": "npx",
                    "args": ["-y", "@modelcontextprotocol/server-filesystem"] + roots,
                    "env": {}
                }
            }
        }

        draft_path = self._unique_path(os.path.join(self.mcp_workspace, "kira_filesystem_bridge.mcp.json"))
        with open(draft_path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

        target = str(target or "cursor_project").strip()
        target_path = self.mcp_config_targets.get(target, self.mcp_config_targets.get("cursor_project"))

        return (
            f"MCP bootstrap draft created: `{draft_path}`\n"
            f"Suggested target: `{target}` -> `{target_path}`\n\n"
            "This draft gives an MCP host read access to KIRA's project/workspace roots. "
            "It does not install or apply anything yet.\n\n"
            "To apply it, Orchestrator should request:\n"
            "[MCP_APPLY]\n"
            f"DRAFT: {draft_path}\n"
            f"TARGET: {target}\n"
            "[/MCP_APPLY]"
        )

    def _generate_native_pdf(self, response_text):
        pattern = r"\[NATIVE_PDF\]\s*TITLE:\s*(.*?)\s*CONTENT:\s*(.*?)\[/NATIVE_PDF\]"
        matches = list(re.finditer(pattern, response_text, re.DOTALL | re.IGNORECASE))

        for match in matches:
            try:
                title = match.group(1).strip()
                content = match.group(2).strip()

                from fpdf import FPDF

                safe_title = self._safe_filename(title, "kira_document")
                filename = self._unique_path(os.path.join(self.agentic_workspace, f"{safe_title}.pdf"))

                pdf = FPDF()
                pdf.add_page()
                pdf.set_font("Arial", "B", 16)
                pdf.cell(0, 10, title.encode("latin-1", "replace").decode("latin-1"), ln=True, align="C")
                pdf.ln(10)
                pdf.set_font("Arial", "", 12)
                pdf.multi_cell(0, 7, content.encode("latin-1", "replace").decode("latin-1"))
                pdf.output(filename)

                replacement = f"PDF generated: `{filename}`"
                response_text = response_text.replace(match.group(0), replacement)
                self._record_artifact(filename, "pdf", title)
                self._log_agentic_event("native_pdf", {"filename": filename})
            except Exception as e:
                response_text = response_text.replace(match.group(0), f"PDF Error: {e}")

        return response_text

    def _generate_native_pptx_blocks(self, response_text):
        for block in self._extract_blocks(response_text, "NATIVE_PPTX"):
            result = self._generate_native_pptx(block)
            response_text = self._replace_block_once(response_text, "NATIVE_PPTX", block, result)
        return response_text

    def _extract_image_sources_from_prompt(self, text):
        value = str(text or "")
        sources = []
        for url in re.findall(r"https?://[^\s`'\"<>]+", value, re.IGNORECASE):
            cleaned = url.rstrip(").,;]")
            if re.search(r"\.(?:png|jpe?g|gif|webp)(?:\?|#|$)", cleaned, re.IGNORECASE):
                sources.append(cleaned)
        path_pattern = r"(?:~|/)[^\n\r`'\"<>]+?\.(?:png|jpe?g|gif|webp)"
        for path in re.findall(path_pattern, value, re.IGNORECASE):
            sources.append(path.rstrip(").,;]"))
        deduped = []
        for source in sources:
            if source and source not in deduped:
                deduped.append(source)
        return deduped

    def _materialize_pptx_image(self, source, title="kira_slide_image"):
        raw_source = str(source or "").strip()
        if not raw_source:
            return "", "Image skipped: missing source."

        if self._looks_like_url(raw_source):
            try:
                parsed = urlparse(raw_source)
                ext = os.path.splitext(parsed.path)[1].lower()
                if ext not in {".png", ".jpg", ".jpeg", ".gif", ".webp"}:
                    ext = ".png"
                image_dir = os.path.join(self.agentic_workspace, "pptx_images")
                os.makedirs(image_dir, exist_ok=True)
                safe_title = self._safe_filename(title, "slide_image")
                image_path = self._unique_path(os.path.join(image_dir, f"{safe_title}{ext}"))
                request = Request(
                    raw_source,
                    headers={
                        "User-Agent": "Mozilla/5.0 KIRA-OS-Agentic-Browser/1.0",
                        "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8"
                    }
                )
                with urlopen(request, timeout=20) as response:
                    content_type = response.headers.get("Content-Type", "")
                    data = response.read(8_000_000)
                if not data:
                    return "", f"Image fetch returned no bytes: {raw_source}"
                if "image" not in content_type.lower() and not re.search(r"\.(?:png|jpe?g|gif|webp)(?:\?|#|$)", raw_source, re.IGNORECASE):
                    return "", f"Image fetch did not return an image content type: {raw_source}"
                with open(image_path, "wb") as f:
                    f.write(data)
                self._log_agentic_event("pptx_image_fetched", {
                    "source": raw_source,
                    "path": image_path,
                    "content_type": content_type,
                    "bytes": len(data)
                })
                return image_path, ""
            except Exception as e:
                return "", f"Image fetch failed for {raw_source}: {e}"

        image_path = self._resolve_path(raw_source)
        if os.path.exists(image_path) and os.path.isfile(image_path):
            return image_path, ""
        return "", f"Image source not found: {image_path}"

    def _generate_native_pptx(self, block):
        try:
            from pptx import Presentation
            from pptx.util import Inches, Pt
            from pptx.dml.color import RGBColor
        except Exception:
            return "PPTX generation needs `python-pptx` installed locally."

        try:
            fields = self._parse_fields(block)
            title = fields.get("title", "KIRA Deck") or "KIRA Deck"
            subtitle = fields.get("subtitle", "").strip()
            theme = fields.get("theme", "dark").strip().lower()

            safe_title = self._safe_filename(title, "kira_deck")
            pptx_path = self._unique_path(os.path.join(self.agentic_workspace, f"{safe_title}.pptx"))

            prs = Presentation()
            prs.slide_width = Inches(13.333)
            prs.slide_height = Inches(7.5)

            dark = theme not in {"light", "white", "simple"}
            bg = RGBColor(13, 15, 18) if dark else RGBColor(248, 250, 252)
            fg = RGBColor(238, 242, 247) if dark else RGBColor(24, 28, 35)
            muted = RGBColor(165, 179, 199) if dark else RGBColor(86, 99, 117)
            accent = RGBColor(164, 199, 250)

            def set_background(slide):
                fill = slide.background.fill
                fill.solid()
                fill.fore_color.rgb = bg

            def add_textbox(slide, x, y, w, h, text, size=20, bold=False, color=None):
                box = slide.shapes.add_textbox(x, y, w, h)
                tf = box.text_frame
                tf.word_wrap = True
                tf.clear()
                p = tf.paragraphs[0]
                p.text = str(text or "")
                p.font.size = Pt(size)
                p.font.bold = bold
                p.font.color.rgb = color or fg
                return box

            def add_body_text(slide, text):
                box = slide.shapes.add_textbox(Inches(0.75), Inches(1.45), Inches(7.15), Inches(5.3))
                tf = box.text_frame
                tf.word_wrap = True
                tf.clear()
                lines = [line.strip() for line in str(text or "").splitlines() if line.strip()]
                if not lines:
                    lines = [""]
                for idx, line in enumerate(lines):
                    p = tf.paragraphs[0] if idx == 0 else tf.add_paragraph()
                    clean = re.sub(r"^\s*(?:[-*•]|\d+[.)])\s*", "", line)
                    p.text = clean
                    p.font.size = Pt(20)
                    p.font.color.rgb = fg
                    if line != clean:
                        p.level = 0
                return box

            def add_table(slide, table_text):
                rows = []
                for line in str(table_text or "").splitlines():
                    if "|" not in line:
                        continue
                    row = [cell.strip() for cell in line.strip().strip("|").split("|")]
                    if any(row):
                        rows.append(row)
                if not rows:
                    return
                col_count = max(len(row) for row in rows)
                rows = [row + [""] * (col_count - len(row)) for row in rows[:8]]
                table_shape = slide.shapes.add_table(
                    len(rows),
                    col_count,
                    Inches(0.75),
                    Inches(4.75),
                    Inches(11.8),
                    Inches(1.8)
                )
                table = table_shape.table
                for r_idx, row in enumerate(rows):
                    for c_idx, value in enumerate(row):
                        cell = table.cell(r_idx, c_idx)
                        cell.text = value
                        for paragraph in cell.text_frame.paragraphs:
                            paragraph.font.size = Pt(11)
                            paragraph.font.color.rgb = fg
                            paragraph.font.bold = r_idx == 0

            def simple_sections_from_content(content_text):
                raw = str(content_text or "").strip()
                if not raw:
                    return []

                chunks = re.split(r"(?im)^\s*(?:#{1,3}\s+|SLIDE\s*:\s*)", raw)
                titled = re.findall(
                    r"(?ims)^\s*(?:#{1,3}\s+|SLIDE\s*:\s*)(.+?)(?:\n)(.*?)(?=^\s*(?:#{1,3}\s+|SLIDE\s*:)|\Z)",
                    raw
                )
                if titled:
                    return [(title.strip()[:80] or "Slide", body.strip()) for title, body in titled[:12]]

                paragraphs = [part.strip() for part in re.split(r"\n\s*\n", raw) if part.strip()]
                if not paragraphs:
                    paragraphs = [raw]

                sections = []
                current_title = "Overview"
                current_body = []
                for paragraph in paragraphs:
                    first_line = paragraph.splitlines()[0].strip()
                    if len(first_line) <= 70 and len(paragraph.splitlines()) == 1 and not first_line.startswith(("-", "*")):
                        if current_body:
                            sections.append((current_title, "\n".join(current_body).strip()))
                        current_title = first_line
                        current_body = []
                    else:
                        current_body.append(paragraph)
                    if len(sections) >= 11:
                        break

                if current_body:
                    sections.append((current_title, "\n".join(current_body).strip()))

                if not sections:
                    sections = [("Overview", raw)]
                return sections[:12]

            slide_chunks = re.split(r"(?im)^SLIDE:\s*", block)
            created = 0
            embedded_images = 0
            image_notes = []

            title_slide = prs.slides.add_slide(prs.slide_layouts[6])
            set_background(title_slide)
            add_textbox(title_slide, Inches(0.75), Inches(2.35), Inches(11.8), Inches(0.95), title, 38, True, accent)
            if subtitle:
                add_textbox(title_slide, Inches(0.78), Inches(3.35), Inches(11.5), Inches(0.75), subtitle, 20, False, muted)
            created += 1

            if len(slide_chunks) <= 1:
                fallback_content = (
                    fields.get("content", "").strip()
                    or fields.get("body", "").strip()
                    or re.sub(r"(?im)^(TITLE|SUBTITLE|THEME)\s*:.*$", "", block).strip()
                )
                for slide_title, body in simple_sections_from_content(fallback_content):
                    slide = prs.slides.add_slide(prs.slide_layouts[6])
                    set_background(slide)
                    add_textbox(slide, Inches(0.6), Inches(0.45), Inches(12.1), Inches(0.7), slide_title, 28, True, accent)
                    add_body_text(slide, body)
                    created += 1

            for chunk in slide_chunks[1:]:
                lines = chunk.splitlines()
                slide_title = lines[0].strip() if lines else "Slide"
                body = ""

                body_match = re.search(r"(?is)BODY:\s*(.*?)(?:\n(?:IMAGE|TABLE|NOTES|LAYOUT):|\Z)", chunk)
                if body_match:
                    body = body_match.group(1).strip()

                bullets = re.findall(r"(?im)^BULLET:\s*(.*)$", chunk)
                if bullets:
                    body = (body + "\n" if body else "") + "\n".join(f"- {item.strip()}" for item in bullets if item.strip())

                image_match = re.search(r"(?im)^IMAGE:\s*(.*)$", chunk)
                image_path = ""
                if image_match:
                    image_source = image_match.group(1).strip()
                    image_path, image_note = self._materialize_pptx_image(image_source, slide_title)
                    if image_note:
                        image_notes.append(image_note)
                table_match = re.search(r"(?is)TABLE:\s*(.*?)(?:\n(?:IMAGE|NOTES|BODY|SLIDE):|\Z)", chunk)
                table_text = table_match.group(1).strip() if table_match else ""
                notes_match = re.search(r"(?is)NOTES:\s*(.*?)(?:\n(?:IMAGE|TABLE|BODY|SLIDE):|\Z)", chunk)
                notes = notes_match.group(1).strip() if notes_match else ""

                slide = prs.slides.add_slide(prs.slide_layouts[6])
                set_background(slide)
                add_textbox(slide, Inches(0.6), Inches(0.45), Inches(12.1), Inches(0.7), slide_title, 28, True, accent)
                add_body_text(slide, body)
                add_table(slide, table_text)

                if image_path and os.path.exists(image_path):
                    try:
                        slide.shapes.add_picture(image_path, Inches(8.25), Inches(1.55), width=Inches(4.25))
                        embedded_images += 1
                    except Exception as e:
                        image_notes.append(f"Image embed failed for {image_path}: {e}")

                if notes:
                    try:
                        notes_tf = slide.notes_slide.notes_text_frame
                        notes_tf.text = notes
                    except Exception:
                        pass

                created += 1

            if created == 0:
                slide = prs.slides.add_slide(prs.slide_layouts[6])
                set_background(slide)
                add_textbox(slide, Inches(0.8), Inches(0.8), Inches(11.8), Inches(5.8), title, 30, True, accent)

            prs.save(pptx_path)
            self._record_artifact(pptx_path, "presentation", title)
            self._log_agentic_event("native_pptx", {"filename": pptx_path})
            image_note_text = ""
            if embedded_images:
                image_note_text += f"\nImages embedded: {embedded_images}"
            if image_notes:
                image_note_text += "\nImage notes:\n" + "\n".join(f"- {note}" for note in image_notes[:6])
            return f"PPTX generated: `{pptx_path}`{image_note_text}"
        except Exception as e:
            return f"PPTX Error: {e}"

    def _generate_native_docx_blocks(self, response_text):
        for block in self._extract_blocks(response_text, "NATIVE_DOCX"):
            result = self._generate_native_docx(block)
            response_text = self._replace_block_once(response_text, "NATIVE_DOCX", block, result)
        return response_text

    def _generate_native_docx(self, block):
        try:
            from docx import Document
            from docx.shared import Inches, Pt
        except Exception:
            return "DOCX generation needs `python-docx` installed locally."

        try:
            fields = self._parse_fields(block)
            title = fields.get("title", "KIRA Document") or "KIRA Document"
            subtitle = fields.get("subtitle", "").strip()
            content = fields.get("content", "").strip()

            safe_title = self._safe_filename(title, "kira_document")
            docx_path = self._unique_path(os.path.join(self.agentic_workspace, f"{safe_title}.docx"))

            doc = Document()
            section = doc.sections[0]
            section.top_margin = Inches(0.7)
            section.bottom_margin = Inches(0.7)
            section.left_margin = Inches(0.75)
            section.right_margin = Inches(0.75)

            styles = doc.styles
            styles["Normal"].font.name = "Arial"
            styles["Normal"].font.size = Pt(11)

            doc.add_heading(title, level=0)
            if subtitle:
                p = doc.add_paragraph(subtitle)
                p.runs[0].italic = True

            body_without_title = re.sub(r"(?im)^(TITLE|SUBTITLE):.*$", "", block).strip()
            consumed_structured = False

            for line in body_without_title.splitlines():
                clean = line.strip()
                if not clean:
                    continue
                heading = re.match(r"(?i)^HEADING\s*:\s*(.+)$", clean)
                paragraph = re.match(r"(?i)^PARAGRAPH\s*:\s*(.+)$", clean)
                bullet = re.match(r"(?i)^BULLET\s*:\s*(.+)$", clean)
                number = re.match(r"(?i)^NUMBER\s*:\s*(.+)$", clean)
                image = re.match(r"(?i)^IMAGE\s*:\s*(.+)$", clean)
                if heading:
                    doc.add_heading(heading.group(1).strip(), level=1)
                    consumed_structured = True
                elif paragraph:
                    doc.add_paragraph(paragraph.group(1).strip())
                    consumed_structured = True
                elif bullet:
                    doc.add_paragraph(bullet.group(1).strip(), style="List Bullet")
                    consumed_structured = True
                elif number:
                    doc.add_paragraph(number.group(1).strip(), style="List Number")
                    consumed_structured = True
                elif image:
                    image_path = self._resolve_path(image.group(1).strip())
                    if os.path.exists(image_path):
                        try:
                            doc.add_picture(image_path, width=Inches(5.8))
                            consumed_structured = True
                        except Exception:
                            pass

            table_match = re.search(r"(?is)^TABLE:\s*(.*?)(?:\n[A-Z_]+:|\Z)", body_without_title, re.MULTILINE)
            if table_match:
                rows = []
                for line in table_match.group(1).splitlines():
                    if "|" not in line:
                        continue
                    row = [cell.strip() for cell in line.strip().strip("|").split("|")]
                    if any(row):
                        rows.append(row)
                if rows:
                    col_count = max(len(row) for row in rows)
                    rows = [row + [""] * (col_count - len(row)) for row in rows]
                    table = doc.add_table(rows=len(rows), cols=col_count)
                    table.style = "Table Grid"
                    for r_idx, row in enumerate(rows):
                        for c_idx, value in enumerate(row):
                            table.cell(r_idx, c_idx).text = value
                    consumed_structured = True

            if content and not consumed_structured:
                for paragraph in content.split("\n\n"):
                    if paragraph.strip():
                        doc.add_paragraph(paragraph.strip())

            doc.save(docx_path)
            self._record_artifact(docx_path, "word", title)
            self._log_agentic_event("native_docx", {"filename": docx_path})
            return f"DOCX generated: `{docx_path}`"
        except Exception as e:
            return f"DOCX Error: {e}"

    def _queue_pdf_to_pptx_blocks(self, response_text, chat_id):
        for block in self._extract_blocks(response_text, "PDF_TO_PPTX"):
            fields = self._parse_fields(block)
            source = self._resolve_path(fields.get("source", ""))
            title = fields.get("title", "PDF Deck")
            max_pages = fields.get("max_pages", "80")
            result = self._queue_permission(
                "pdf_to_pptx",
                {"source": source, "title": title, "max_pages": max_pages},
                f"Convert PDF to image-based PPTX: {source}",
                chat_id
            )
            response_text = self._replace_block_once(response_text, "PDF_TO_PPTX", block, result)
        return response_text

    def _run_read_tools(self, response_text, chat_id):
        logs = []

        for block in self._extract_blocks(response_text, "READ_FILE"):
            fields = self._parse_fields(block)
            path = self._resolve_path(fields.get("path", ""))
            if self._is_read_allowed(path):
                logs.append(self._read_file_tool(path))
            else:
                logs.append(self._queue_permission(
                    "read_file",
                    {"path": path},
                    self._read_permission_preview(path),
                    chat_id
                ))

        for block in self._extract_blocks(response_text, "LIST_DIR"):
            fields = self._parse_fields(block)
            path = self._resolve_path(fields.get("path", "."))
            if self._is_read_allowed(path):
                logs.append(self._list_dir_tool(path))
            else:
                logs.append(self._queue_permission(
                    "list_dir",
                    {"path": path},
                    self._read_permission_preview(path),
                    chat_id
                ))

        for block in self._extract_blocks(response_text, "SEARCH_FILES"):
            fields = self._parse_fields(block)
            path = self._resolve_path(fields.get("path", "."))
            pattern = fields.get("pattern", "").strip()
            if pattern:
                if self._is_read_allowed(path):
                    logs.append(self._search_files_tool(path, pattern))
                else:
                    logs.append(self._queue_permission(
                        "search_files",
                        {"path": path, "pattern": pattern},
                        self._read_permission_preview(path) + f"\nPattern: {pattern}",
                        chat_id
                    ))
            else:
                logs.append("SEARCH_FILES skipped: missing PATTERN.")

        if logs:
            response_text += "\n\n" + "\n\n".join(logs)

        return response_text

    def _run_find_in_computer_blocks(self, response_text, chat_id):
        logs = []

        for block in self._extract_blocks(response_text, "FIND_IN_COMPUTER"):
            fields = self._parse_fields(block)
            scope = self._resolve_path(fields.get("scope", ""))
            issue = fields.get("issue", "").strip()
            pattern = fields.get("pattern", "").strip()

            if not scope or not issue:
                logs.append("FIND_IN_COMPUTER needs both SCOPE and ISSUE.")
                continue

            if self._is_read_allowed(scope):
                logs.append(self._find_in_computer_tool(scope, issue, pattern))
            else:
                logs.append(self._queue_permission(
                    "find_in_computer",
                    {"scope": scope, "issue": issue, "pattern": pattern},
                    f"Read-only investigation outside readable roots:\n{scope}\nIssue: {issue}",
                    chat_id
                ))

        if logs:
            response_text += "\n\n" + "\n\n".join(logs)

        return response_text

    def _run_open_tools(self, response_text):
        logs = []

        for block in self._extract_blocks(response_text, "OPEN"):
            fields = self._parse_fields(block)
            target = fields.get("target") or fields.get("path") or fields.get("url") or block.strip()
            logs.append(self._open_target_tool(target))

        for block in self._extract_blocks(response_text, "CLOSE"):
            fields = self._parse_fields(block)
            target = fields.get("target") or fields.get("app") or fields.get("name") or block.strip()
            logs.append(self._close_target_tool(target))

        for block in self._extract_blocks(response_text, "IDE_OPEN"):
            fields = self._parse_fields(block)
            payload = {
                "path": self._resolve_path(fields.get("path", self.app_root)),
                "line": fields.get("line", "").strip(),
                "app": fields.get("app", "cursor").strip().lower() or "cursor"
            }
            logs.append(self._open_in_ide(payload))

        if logs:
            response_text += "\n\n" + "\n\n".join(logs)

        return response_text

    def _run_web_search_tools(self, response_text):
        logs = []

        for block in self._extract_blocks(response_text, "WEB_SEARCH"):
            fields = self._parse_fields(block)
            query = fields.get("query") or block.strip()
            logs.append(self._web_search_tool(query))

        for block in self._extract_blocks(response_text, "WEB_OPEN"):
            fields = self._parse_fields(block)
            target = fields.get("url") or fields.get("query") or fields.get("target") or block.strip()
            logs.append(self._web_open_tool(target))

        for block in self._extract_blocks(response_text, "WEB_FETCH"):
            fields = self._parse_fields(block)
            target = fields.get("url") or fields.get("query") or fields.get("target") or block.strip()
            max_chars = fields.get("max_chars", "12000")
            logs.append(self._web_fetch_tool(target, max_chars=max_chars))

        for block in self._extract_blocks(response_text, "WEB_BROWSE"):
            fields = self._parse_fields(block)
            target = fields.get("url") or fields.get("query") or fields.get("target") or block.strip()
            open_page = fields.get("open", "true").strip().lower() not in {"false", "no", "0"}
            fetch_page = fields.get("fetch", "true").strip().lower() not in {"false", "no", "0"}
            if open_page:
                logs.append(self._web_open_tool(target))
            if fetch_page:
                logs.append(self._web_fetch_tool(target, max_chars=fields.get("max_chars", "12000")))

        for block in self._extract_blocks(response_text, "WEB_HEADLESS"):
            fields = self._parse_fields(block)
            target = fields.get("url") or fields.get("query") or fields.get("target") or block.strip()
            max_chars = fields.get("max_chars", "12000")
            logs.append(self._web_fetch_tool(target, max_chars=max_chars, force_headless=True))

        if logs:
            response_text += "\n\n" + "\n\n".join(logs)

        return response_text


    def _run_utility_tools(self, response_text, chat_id):
        logs = []

        for block in self._extract_blocks(response_text, "CLIPBOARD_READ"):
            logs.append(self._clipboard_read_tool())

        for block in self._extract_blocks(response_text, "HASH_FILE"):
            fields = self._parse_fields(block)
            path = self._resolve_path(fields.get("path", block.strip()))
            if self._is_read_allowed(path):
                logs.append(self._hash_file_tool(path))
            else:
                logs.append(self._queue_permission(
                    "hash_file",
                    {"path": path},
                    self._read_permission_preview(path),
                    chat_id
                ))

        for block in self._extract_blocks(response_text, "FILE_COMPARE"):
            fields = self._parse_fields(block)
            left = self._resolve_path(fields.get("left") or fields.get("a") or fields.get("path_a") or fields.get("source") or "")
            right = self._resolve_path(fields.get("right") or fields.get("b") or fields.get("path_b") or fields.get("destination") or "")
            if self._is_read_allowed(left) and self._is_read_allowed(right):
                logs.append(self._file_compare_tool(left, right))
            else:
                logs.append(self._queue_permission(
                    "file_compare",
                    {"left": left, "right": right},
                    f"Read-only compare requested:\n{left}\n{right}",
                    chat_id
                ))

        for block in self._extract_blocks(response_text, "ARCHIVE_PREVIEW"):
            fields = self._parse_fields(block)
            path = self._resolve_path(fields.get("path") or fields.get("source") or block.strip())
            limit = fields.get("limit", "80")
            if self._is_read_allowed(path):
                logs.append(self._archive_preview_tool(path, limit=limit))
            else:
                logs.append(self._queue_permission(
                    "archive_preview",
                    {"path": path, "limit": limit},
                    self._read_permission_preview(path),
                    chat_id
                ))

        for block in self._extract_blocks(response_text, "NOTE_DRAFT"):
            logs.append(self._note_draft_tool(self._parse_fields(block), block))

        for block in self._extract_blocks(response_text, "CALENDAR_DRAFT"):
            logs.append(self._calendar_draft_tool(self._parse_fields(block), block))

        for block in self._extract_blocks(response_text, "REMINDER_DRAFT"):
            logs.append(self._reminder_draft_tool(self._parse_fields(block), block))

        if logs:
            response_text += "\n\n" + "\n\n".join(logs)

        return response_text

    def _clipboard_read_tool(self):
        try:
            res = subprocess.run(["pbpaste"], capture_output=True, text=True, timeout=5)
            output = res.stdout if res.returncode == 0 else res.stderr
            output = self._truncate(output.strip() or "(clipboard is empty)", 8000)
            self._log_agentic_event("clipboard_read", {"returncode": res.returncode, "chars": len(output)})
            return "CLIPBOARD_READ:\n```\n" + output + "\n```"
        except Exception as e:
            return f"CLIPBOARD_READ ERROR: {e}"

    def _clipboard_write_tool(self, text):
        try:
            res = subprocess.run(["pbcopy"], input=str(text or ""), text=True, capture_output=True, timeout=5)
            output = res.stdout if res.returncode == 0 else res.stderr
            self._log_agentic_event("clipboard_write", {"returncode": res.returncode, "chars": len(str(text or ""))})
            if res.returncode != 0:
                return "CLIPBOARD_WRITE FAILED:\n```\n" + self._truncate(output or "(no output)", 4000) + "\n```"
            return f"CLIPBOARD_WRITE: Copied `{len(str(text or ''))}` characters to the clipboard."
        except Exception as e:
            return f"CLIPBOARD_WRITE ERROR: {e}"

    def _hash_file_tool(self, path):
        target = self._resolve_path(path)
        if not os.path.exists(target):
            return f"HASH_FILE SKIPPED: Path does not exist: `{target}`"
        if os.path.isdir(target):
            return f"HASH_FILE SKIPPED: Path is a folder, not a file: `{target}`"
        try:
            digest = hashlib.sha256()
            size = 0
            with open(target, "rb") as f:
                for chunk in iter(lambda: f.read(1024 * 1024), b""):
                    size += len(chunk)
                    digest.update(chunk)
            result = f"HASH_FILE:\nPath: `{target}`\nSize: {size} bytes\nSHA256: `{digest.hexdigest()}`"
            self._log_agentic_event("hash_file", {"path": target, "size": size, "sha256": digest.hexdigest()})
            return result
        except Exception as e:
            return f"HASH_FILE ERROR: `{target}`\n{e}"

    def _file_compare_tool(self, left, right):
        left_path = self._resolve_path(left)
        right_path = self._resolve_path(right)
        if not os.path.exists(left_path) or not os.path.exists(right_path):
            return f"FILE_COMPARE SKIPPED: Missing path.\nLeft: `{left_path}`\nRight: `{right_path}`"
        if os.path.isdir(left_path) or os.path.isdir(right_path):
            return "FILE_COMPARE SKIPPED: Folder comparison is not supported by this lightweight pathway yet."
        try:
            res = self._run_seatbelt_subprocess(
                ["diff", "-u", left_path, right_path],
                mode="read_only",
                read_paths=[left_path, right_path],
                timeout=20
            )
            output = res.stdout if res.returncode in {0, 1} else res.stderr
            output = self._truncate(output.strip() or "Files are identical.", 12000)
            self._log_agentic_event("file_compare", {"left": left_path, "right": right_path, "returncode": res.returncode})
            return "FILE_COMPARE:\n```diff\n" + output + "\n```"
        except Exception as e:
            return f"FILE_COMPARE ERROR: {e}"

    def _archive_preview_tool(self, path, limit="80"):
        target = self._resolve_path(path)
        try:
            max_items = max(1, min(int(str(limit).strip() or "80"), 300))
        except ValueError:
            max_items = 80
        if not os.path.exists(target):
            return f"ARCHIVE_PREVIEW SKIPPED: Path does not exist: `{target}`"
        try:
            rows = []
            if zipfile.is_zipfile(target):
                with zipfile.ZipFile(target) as zf:
                    infos = zf.infolist()
                    for info in infos[:max_items]:
                        rows.append(f"{info.file_size:>10}  {info.filename}")
                    remaining = max(0, len(infos) - len(rows))
                    heading = f"ZIP archive with {len(infos)} item(s)."
            elif tarfile.is_tarfile(target):
                with tarfile.open(target) as tf:
                    members = tf.getmembers()
                    for member in members[:max_items]:
                        rows.append(f"{member.size:>10}  {member.name}")
                    remaining = max(0, len(members) - len(rows))
                    heading = f"TAR archive with {len(members)} item(s)."
            else:
                return f"ARCHIVE_PREVIEW SKIPPED: Not a supported zip/tar archive: `{target}`"
            if remaining:
                rows.append(f"... {remaining} more item(s) ...")
            result = "ARCHIVE_PREVIEW:\n" + heading + "\n```\n" + "\n".join(rows) + "\n```"
            self._log_agentic_event("archive_preview", {"path": target, "items_shown": len(rows)})
            return result
        except Exception as e:
            return f"ARCHIVE_PREVIEW ERROR: `{target}`\n{e}"

    def _write_workspace_artifact_text(self, folder, title, ext, content, kind):
        safe_title = self._safe_filename(title, kind)
        directory = os.path.join(self.agentic_workspace, folder)
        os.makedirs(directory, exist_ok=True)
        path = self._unique_path(os.path.join(directory, f"{safe_title}.{ext.lstrip('.')}"))
        with open(path, "w", encoding="utf-8") as f:
            f.write(str(content or ""))
        if hasattr(self, "_record_artifact"):
            self._record_artifact(path, kind=kind, title=title)
        return path

    def _note_draft_tool(self, fields, raw_block):
        title = fields.get("title") or fields.get("name") or "KIRA Note"
        content = fields.get("content") or fields.get("body") or raw_block.strip() or title
        path = self._write_workspace_artifact_text("notes", title, "md", f"# {title}\n\n{content.strip()}\n", "note")
        self._log_agentic_event("note_draft", {"path": path, "title": title})
        return f"NOTE_DRAFT: Created note `{path}`"

    def _parse_calendar_time(self, value, default_dt):
        raw = str(value or "").strip()
        if not raw:
            return default_dt
        for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M", "%Y/%m/%d %H:%M", "%d %b %Y %H:%M", "%B %d, %Y %H:%M"):
            try:
                return datetime.strptime(raw, fmt)
            except ValueError:
                pass
        return default_dt

    def _ics_datetime(self, value, default_dt):
        return self._parse_calendar_time(value, default_dt).strftime("%Y%m%dT%H%M%S")

    def _calendar_draft_tool(self, fields, raw_block):
        title = fields.get("title") or fields.get("summary") or "KIRA Event"
        now = datetime.now().replace(second=0, microsecond=0)
        start = self._ics_datetime(fields.get("start") or fields.get("when"), now + timedelta(hours=1))
        end = self._ics_datetime(fields.get("end"), now + timedelta(hours=2))
        description = (fields.get("description") or fields.get("content") or raw_block.strip() or title).replace("\n", "\\n")
        location = (fields.get("location") or "").replace("\n", " ")
        uid = f"kira-{int(time.time())}@kira-os.local"
        ics = "\n".join([
            "BEGIN:VCALENDAR",
            "VERSION:2.0",
            "PRODID:-//KIRA OS//Calendar Draft//EN",
            "BEGIN:VEVENT",
            f"UID:{uid}",
            f"DTSTAMP:{datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')}",
            f"DTSTART:{start}",
            f"DTEND:{end}",
            f"SUMMARY:{title}",
            f"DESCRIPTION:{description}",
            f"LOCATION:{location}",
            "END:VEVENT",
            "END:VCALENDAR",
            ""
        ])
        path = self._write_workspace_artifact_text("calendar", title, "ics", ics, "calendar")
        self._log_agentic_event("calendar_draft", {"path": path, "title": title})
        return f"CALENDAR_DRAFT: Created calendar draft `{path}`"

    def _reminder_draft_tool(self, fields, raw_block):
        title = fields.get("title") or fields.get("task") or "KIRA Reminder"
        when = fields.get("when") or fields.get("time") or "unscheduled"
        content = fields.get("content") or fields.get("notes") or raw_block.strip() or title
        md = f"# {title}\n\nWhen: {when}\n\n{content.strip()}\n"
        path = self._write_workspace_artifact_text("reminders", title, "md", md, "reminder")
        self._log_agentic_event("reminder_draft", {"path": path, "title": title, "when": when})
        return f"REMINDER_DRAFT: Created reminder draft `{path}`"

    def _zip_create_tool(self, payload):
        source = self._resolve_path(payload.get("source", ""))
        destination = self._resolve_path(payload.get("destination", "")) if payload.get("destination") else ""
        if not os.path.exists(source):
            return f"ZIP_CREATE SKIPPED: Source does not exist: `{source}`"
        if self._is_sensitive_path(source):
            return f"ZIP_CREATE BLOCKED SAFELY: Source looks sensitive: `{source}`"
        if not destination:
            base = self._safe_filename(os.path.basename(os.path.normpath(source)) or "kira_archive", "kira_archive")
            archive_dir = os.path.join(self.agentic_workspace, "archives")
            os.makedirs(archive_dir, exist_ok=True)
            destination = self._unique_path(os.path.join(archive_dir, f"{base}.zip"))
        destination = self._resolve_path(destination)
        os.makedirs(os.path.dirname(destination) or self.agentic_workspace, exist_ok=True)
        try:
            count = 0
            with zipfile.ZipFile(destination, "w", compression=zipfile.ZIP_DEFLATED) as zf:
                if os.path.isdir(source):
                    root = os.path.dirname(source)
                    for current_root, dirs, files in os.walk(source):
                        dirs[:] = [d for d in dirs if not d.startswith(".")]
                        for name in files:
                            if name.startswith("."):
                                continue
                            full = os.path.join(current_root, name)
                            if self._is_sensitive_path(full):
                                continue
                            zf.write(full, os.path.relpath(full, root))
                            count += 1
                else:
                    zf.write(source, os.path.basename(source))
                    count = 1
            self._record_artifact(destination, kind="archive", title=os.path.basename(destination))
            self._log_agentic_event("zip_create", {"source": source, "destination": destination, "count": count})
            return f"ZIP_CREATE: Created archive `{destination}` with {count} item(s)."
        except Exception as e:
            return f"ZIP_CREATE FAILED SAFELY: `{source}` -> `{destination}`\n{e}"

    def _run_scheduler_tools(self, response_text, raw_prompt, chat_id):
        logs = []

        for block in self._extract_blocks(response_text, "SCHEDULE_TASK"):
            fields = self._parse_fields(block)
            task_prompt = (
                fields.get("task")
                or fields.get("prompt")
                or fields.get("content")
                or raw_prompt
            )
            delay = fields.get("delay") or fields.get("when") or fields.get("time") or fields.get("run_after") or "60 seconds"
            title = fields.get("title") or task_prompt

            if hasattr(self, "schedule_agentic_task"):
                logs.append(self.schedule_agentic_task(
                    task_prompt,
                    delay_text=delay,
                    mode="agentic",
                    selected_model="orchestrator",
                    chat_id=chat_id,
                    title=title
                ))
            else:
                logs.append("SCHEDULE_TASK failed: scheduler is not available in this backend.")

        if logs:
            response_text += "\n\n" + "\n\n".join(logs)

        return response_text

    def _run_permissioned_blocks(self, response_text, chat_id):
        logs = []

        for tag, action in [
            ("WRITE_FILE", "write_file"),
            ("APPEND_FILE", "append_file"),
            ("DELETE_PATH", "delete_path"),
            ("MOVE_PATH", "move_path"),
            ("MCP_SETUP", "mcp_setup"),
            ("MCP_APPLY", "mcp_apply"),
            ("PROJECT_COMMAND", "project_command"),
            ("IDE_PASTE_RUN", "ide_paste_run"),
            ("CLIPBOARD_WRITE", "clipboard_write"),
            ("ZIP_CREATE", "zip_create"),
            ("PYTHON", "python"),
            ("APPLESCRIPT", "applescript")
        ]:
            for block in self._extract_blocks(response_text, tag):
                fields = self._parse_fields(block)

                if action == "python":
                    payload = {"code": block.strip()}
                    preview = block.strip()[:700]
                elif action == "applescript":
                    payload = {"code": block.strip()}
                    preview = block.strip()[:700]
                    if self._is_safe_read_only_applescript(payload["code"]):
                        logs.append(self._run_applescript(payload["code"]))
                        continue
                elif action == "mcp_apply":
                    target = fields.get("target", "cursor_project").strip() or "cursor_project"
                    payload = {
                        "draft": self._resolve_path(fields.get("draft", "")),
                        "target": target,
                        "path": self._resolve_path(fields.get("path", "")) if fields.get("path") else ""
                    }
                    preview = f"Apply MCP draft {payload['draft']} to {target}"
                elif action == "project_command":
                    payload = {
                        "cwd": self._resolve_path(fields.get("cwd", self.app_root)),
                        "command": fields.get("command", block.strip()).strip()
                    }
                    preview = f"Run in {payload['cwd']}:\n{payload['command']}"
                elif action == "ide_paste_run":
                    payload = {
                        "app": fields.get("app", "cursor").strip() or "cursor",
                        "project_path": self._resolve_path(fields.get("project_path", fields.get("cwd", self.app_root))),
                        "code": fields.get("code") or fields.get("content") or block.strip(),
                        "run_method": fields.get("run_method", "paste_then_enter").strip() or "paste_then_enter",
                        "verify_command": fields.get("verify_command", "").strip()
                    }
                    preview = (
                        f"Open/activate {payload['app']} at {payload['project_path']}, paste code "
                        f"({len(payload['code'])} chars), run method `{payload['run_method']}`"
                    )
                    if payload["verify_command"]:
                        preview += f", then verify with:\n{payload['verify_command']}"
                elif action == "move_path":
                    payload = {
                        "source": self._resolve_path(fields.get("source", "")),
                        "destination": self._resolve_path(fields.get("destination", ""))
                    }
                    if self._is_move_protected_path(payload["source"], payload["destination"]):
                        logs.append(self._protected_move_message(payload["source"], payload["destination"]))
                        continue
                    preview = payload["source"] + " -> " + payload["destination"]
                elif action == "web_search":
                    query = fields.get("query") or block.strip()
                    payload = {"query": query.strip()}
                    preview = payload["query"]
                elif action == "mcp_setup":
                    payload = {
                        "name": fields.get("name", "kira_connector"),
                        "command": fields.get("command", ""),
                        "args_json": fields.get("args_json", "[]"),
                        "env_json": fields.get("env_json", "{}"),
                        "config_json": fields.get("config_json", "")
                    }
                    preview = payload["name"] + ": " + payload["command"]
                elif action == "delete_path":
                    path = self._resolve_path(fields.get("path", ""))
                    if self._is_delete_protected_path(path):
                        logs.append(self._protected_delete_message(path))
                        continue
                    payload = {"path": path}
                    preview = path
                else:
                    payload = {
                        "path": self._resolve_path(fields.get("path", "")),
                        "content": fields.get("content", "")
                    }
                    preview = payload["path"]

                logs.append(self._queue_permission(action, payload, preview, chat_id))

        if logs:
            response_text += "\n\n" + "\n\n".join(logs)

        return response_text

    def _execute_agentic_code(self, response_text, chat_id):
        logs = []

        for code in re.findall(r"```(?:bash|sh|zsh|shell|terminal)\s*(.*?)```", response_text, re.DOTALL | re.IGNORECASE):
            logs.append(self._execute_or_request_command(code.strip(), chat_id))

        for code in self._extract_blocks(response_text, "COMMAND"):
            logs.append(self._execute_or_request_command(code.strip(), chat_id))

        for code in self._extract_blocks(response_text, "SHELL"):
            logs.append(self._execute_or_request_command(code.strip(), chat_id))

        for code in self._extract_blocks(response_text, "TERMINAL"):
            logs.append(self._execute_or_request_command(code.strip(), chat_id))

        for code in self._extract_inline_tool_commands(response_text, {"COMMAND", "SHELL", "TERMINAL"}):
            logs.append(self._execute_or_request_command(code.strip(), chat_id))

        for code in self._extract_inline_tool_commands(response_text, {"APPLESCRIPT"}):
            logs.append(self._execute_or_request_applescript(code.strip(), chat_id))

        if logs:
            response_text += "\n\n" + "\n\n".join(logs)

        return response_text

    def _execute_or_request_command(self, code, chat_id):
        if not code:
            return "TERMINAL EXECUTION: Empty command skipped."

        if self._is_safe_read_only_shell(code):
            return self._run_shell_command(code)

        if self._is_safe_navigation_open_shell(code):
            return self._run_navigation_open_command(code)

        return self._queue_permission("command", {"code": code}, code[:700], chat_id)

    def _execute_or_request_applescript(self, code, chat_id):
        if not code:
            return "APPLESCRIPT EXECUTION: Empty script skipped."
        if self._is_safe_read_only_applescript(code):
            return self._run_applescript(code)
        return self._queue_permission("applescript", {"code": code}, code[:700], chat_id)

    def _extract_inline_tool_commands(self, response_text, labels):
        commands = []
        label_pattern = "|".join(re.escape(label) for label in labels)

        for line in str(response_text or "").splitlines():
            match = re.match(rf"^\s*(?:\[\s*)?({label_pattern})(?:\s*\])?\s*:\s*(.+?)\s*$", line, re.IGNORECASE)
            if not match:
                continue
            command = match.group(2).strip()
            if command and not command.startswith("["):
                commands.append(command)

        return commands

    def _is_safe_read_only_shell(self, code):
        risky_patterns = [
            r"\brm\b", r"\bmv\b", r"\bcp\b", r"\bmkdir\b", r"\btouch\b",
            r"\bchmod\b", r"\bchown\b", r"\bsudo\b", r"\bkill\b",
            r"\bpkill\b", r"\bkillall\b", r"\bopen\b", r"\bosascript\b",
            r"\bpython\b", r"\bpython3\b", r"\bpip\b", r"\bnpm\b",
            r"\byarn\b", r"\bcurl\b", r"\bwget\b", r"\btee\b",
            r">", r">>", r"<<", r"\bdd\b"
        ]

        for pattern in risky_patterns:
            if re.search(pattern, code):
                return False

        if any(control in code for control in [";", "&&", "||", "$(", "`"]):
            return False

        lines = [line.strip() for line in code.splitlines() if line.strip() and not line.strip().startswith("#")]

        for line in lines:
            segments = [segment.strip() for segment in line.split("|")]

            for segment in segments:
                try:
                    tokens = shlex.split(segment)
                except ValueError:
                    return False

                if not tokens:
                    continue

                command = os.path.basename(tokens[0])

                if command == "git":
                    if len(tokens) < 2 or tokens[1] not in self.safe_git_commands:
                        return False
                    continue

                if command not in self.safe_shell_commands:
                    return False

        return True

    def _is_safe_navigation_open_shell(self, code):
        lines = [line.strip() for line in str(code or "").splitlines() if line.strip() and not line.strip().startswith("#")]
        if len(lines) != 1:
            return False

        line = lines[0]
        if any(control in line for control in [";", "&&", "||", "|", "$(", "`", ">", "<"]):
            return False

        try:
            tokens = shlex.split(line)
        except ValueError:
            return False

        if not tokens or os.path.basename(tokens[0]) != "open":
            return False

        blocked_flags = {"-e", "-f", "-W", "--wait-apps", "--stdin"}
        return not any(token in blocked_flags for token in tokens[1:])

    def _run_navigation_open_command(self, code):
        try:
            tokens = shlex.split(str(code or "").strip())
            res = subprocess.run(tokens, capture_output=True, text=True, timeout=20)
            output = (res.stdout if res.returncode == 0 else res.stderr).strip()
            self._log_agentic_event("navigation_open", {
                "command": code,
                "returncode": res.returncode,
                "output": self._truncate(output, 4000)
            })
            if res.returncode == 0:
                target = " ".join(tokens[1:]).strip() or "target"
                return f"OPEN: Opened `{target}`"
            if len(tokens) >= 3 and tokens[1] == "-a":
                fallback_target = " ".join(tokens[2:]).strip()
                if fallback_target:
                    return self._open_target_tool(fallback_target)
            return "OPEN ERROR:\n```\n" + self._truncate(output or "(no output)", 4000) + "\n```"
        except Exception as e:
            return f"OPEN ERROR: {e}"

    def _run_shell_command(self, code):
        try:
            res = self._run_seatbelt_subprocess(
                code,
                shell=True,
                mode="read_only",
                timeout=14
            )

            output = res.stdout if res.returncode == 0 else res.stderr
            output = self._truncate(output.strip() or "(no output)", 12000)

            self._log_agentic_event("shell", {
                "code": code,
                "seatbelt": getattr(res, "kira_seatbelt_mode", "unknown"),
                "returncode": res.returncode,
                "output": output
            })

            return (
                f"TERMINAL EXECUTION [Seatbelt: {getattr(res, 'kira_seatbelt_mode', 'unknown')}]:\n"
                "```\n" + output + "\n```"
            )

        except subprocess.TimeoutExpired:
            return "TERMINAL EXECUTION: Command timed out after 14 seconds."
        except Exception as e:
            return f"TERMINAL EXECUTION ERROR: {e}"

    def _is_safe_read_only_applescript(self, code):
        script = re.sub(r"\s+", " ", str(code or "").strip().lower())
        if not script:
            return False

        risky_words = [
            " do shell script ", " keystroke ", " key code ", " click ",
            " set ", " delete ", " duplicate ", " move ", " make new ",
            " open ", " launch ", " activate ", " quit ", " close ",
            " display dialog ", " choose file ", " choose folder ",
            " input ", " paste ", " clipboard "
        ]

        padded = " " + script + " "
        if any(word in padded for word in risky_words):
            return False

        allowed_starts = (
            "tell application \"system events\" to get ",
            "tell application \"finder\" to get ",
            "tell application \"terminal\" to get ",
            "tell application \"system events\"",
            "tell application \"finder\"",
            "get ",
        )
        return script.startswith(allowed_starts)

    def _run_applescript(self, code):
        try:
            res = subprocess.run(
                ["osascript", "-e", str(code or "")],
                capture_output=True,
                text=True,
                timeout=45
            )
            output = res.stdout if res.returncode == 0 else res.stderr
            output = self._truncate(output.strip() or "(no output)", 12000)
            self._log_agentic_event("applescript", {
                "code": code,
                "returncode": res.returncode,
                "output": output
            })
            return "APPLESCRIPT EXECUTION:\n```\n" + output + "\n```"
        except subprocess.TimeoutExpired:
            return "APPLESCRIPT EXECUTION: Script timed out after 45 seconds."
        except Exception as e:
            return f"APPLESCRIPT EXECUTION ERROR: {e}"

    def _compile_agentic_result(self, raw_prompt, answer, chat_id):
        # Final interpretation belongs to Orchestrator V1, not fixed keyword routing.
        return answer

    def _inspect_memory_hogs(self):
        code = "ps -axo pid=,rss=,%mem=,command= | sort -nrk 2 | head -15"

        try:
            res = subprocess.run(
                code,
                shell=True,
                capture_output=True,
                text=True,
                timeout=15
            )

            raw_output = res.stdout if res.returncode == 0 else res.stderr
            raw_output = raw_output.strip()

            self._log_agentic_event("direct_memory_inspection", {
                "code": code,
                "returncode": res.returncode,
                "output": self._truncate(raw_output, 12000)
            })

            if res.returncode != 0:
                return "I tried to inspect live memory usage, but macOS returned an error:\n```\n" + self._truncate(raw_output or "(no output)", 4000) + "\n```"

            processes = self._parse_memory_processes(raw_output)

            if not processes:
                return "I inspected live memory usage, but I could not parse the process list."

            return self._format_memory_process_answer(processes)

        except subprocess.TimeoutExpired:
            return "I tried to inspect live memory usage, but the command timed out."
        except Exception as e:
            return f"I tried to inspect live memory usage, but hit an error: {e}"

    def _application_activity_report_tool(self):
        process_command = "ps -axo pid=,rss=,%mem=,%cpu=,etime=,command= | sort -nrk 2 | head -40"
        front_app_script = 'tell application "System Events" to get name of first application process whose frontmost is true'
        visible_apps_script = 'tell application "System Events" to get name of every application process whose background only is false'

        sections = []

        try:
            res = subprocess.run(
                process_command,
                shell=True,
                capture_output=True,
                text=True,
                timeout=20
            )
            output = res.stdout if res.returncode == 0 else res.stderr
            sections.append("Top processes by memory:\n" + self._truncate(output.strip() or "(no output)", 8000))
        except Exception as e:
            sections.append(f"Top processes by memory:\nERROR: {e}")

        for title, script in [
            ("Frontmost app", front_app_script),
            ("Visible application processes", visible_apps_script)
        ]:
            try:
                res = subprocess.run(
                    ["osascript", "-e", script],
                    capture_output=True,
                    text=True,
                    timeout=15
                )
                output = res.stdout if res.returncode == 0 else res.stderr
                sections.append(title + ":\n" + self._truncate(output.strip() or "(no output)", 5000))
            except Exception as e:
                sections.append(f"{title}:\nERROR: {e}")

        snapshot = "\n\n".join(sections)
        self._log_agentic_event("application_activity_report", {
            "process_command": process_command,
            "output": self._truncate(snapshot, 14000)
        })

        return "APPLICATION ACTIVITY SNAPSHOT:\n```\n" + snapshot + "\n```"

    def _parse_memory_processes(self, text):
        processes = []

        for line in str(text or "").splitlines():
            clean_line = line.strip()
            if not clean_line or clean_line.startswith("```"):
                continue

            parts = clean_line.split(None, 3)
            if len(parts) >= 4 and re.fullmatch(r"\d+", parts[0]):
                pid = parts[0]
                rss_text = parts[1]
                mem_percent = parts[2].replace("%", "")
                command = parts[3]
            else:
                legacy_parts = clean_line.split()
                if len(legacy_parts) < 4:
                    continue
                if not re.fullmatch(r"\d+", legacy_parts[0]):
                    continue
                pid = legacy_parts[0]
                mem_percent = legacy_parts[-1].replace("%", "")
                rss_text = legacy_parts[-2]
                command = " ".join(legacy_parts[1:-2])

            if not re.fullmatch(r"\d+", pid):
                continue

            try:
                rss_kb = int(float(rss_text))
                float(mem_percent)
            except Exception:
                continue

            processes.append({
                "pid": pid,
                "app": self._friendly_process_name(command),
                "command": command,
                "rss_kb": rss_kb,
                "rss_mb": rss_kb / 1024.0,
                "mem_percent": mem_percent
            })

        processes.sort(key=lambda item: item["rss_kb"], reverse=True)
        return processes

    def _format_memory_process_answer(self, processes):
        top = processes[0]
        rows = []

        for process in processes[:8]:
            rows.append(
                f"{process['app']:<28} PID {process['pid']:<7} "
                f"{process['rss_mb']:>8.1f} MB   {process['mem_percent']:>5}%"
            )

        return (
            f"The app/process using the most RAM right now is **{top['app']}** "
            f"(PID `{top['pid']}`), at about **{top['rss_mb']:.1f} MB RAM** "
            f"and **{top['mem_percent']}% MEM**.\n\n"
            "Top memory consumers:\n"
            "```\n"
            + "\n".join(rows)
            + "\n```"
        )

    def _friendly_process_name(self, command):
        command = str(command or "").strip()

        app_match = re.search(r"/([^/]+)\.app(?:/|$)", command)
        if app_match:
            return app_match.group(1)

        name = os.path.basename(command)
        return name or command or "Unknown"

    def approve_pending_tool(self, request_id):
        with self.permission_lock:
            request = self.pending_permissions.pop(request_id, None)

        if not request:
            return {"status": "missing", "message": f"No pending request found for {request_id}"}

        self.response_queue.put({
            "type": "status",
            "content": "Running approved action...",
            "chat_id": request.get("chat_id")
        })
        threading.Thread(target=self._approve_pending_worker, args=(request,), daemon=True).start()
        return {"status": "approved", "message": f"Approved {request_id}. Running now."}

    def _approve_pending_worker(self, request):
        previous_ledger_id = getattr(self, "active_execution_ledger_id", "")
        context = request.get("agentic_context") or {}
        ledger_id = context.get("ledger_id", "")
        if ledger_id:
            self.active_execution_ledger_id = ledger_id
        try:
            result = self._execute_permissioned_action(request)
            self._record_text_execution_evidence(result, chat_id=request.get("chat_id"))
            chat_id = request.get("chat_id")
            final_result = self._continue_after_approved_permission(request, result)
            self._append_chat_message(chat_id, "assistant", final_result, "Orchestrator V1")
            self.response_queue.put({
                "type": "message",
                "content": final_result,
                "model_used": "Orchestrator V1",
                "chat_id": chat_id
            })
        except Exception as e:
            error = f"Permissioned action failed: {e}"
            self._record_execution_evidence(
                request.get("action", "permissioned_action"),
                "failed",
                error,
                {"request_id": request.get("id")},
                chat_id=request.get("chat_id")
            )
            self.response_queue.put({
                "type": "error",
                "content": error,
                "chat_id": request.get("chat_id")
            })
        finally:
            if ledger_id:
                self._finish_execution_ledger(ledger_id, locals().get("final_result", locals().get("result", "")))
                self.active_execution_ledger_id = previous_ledger_id

    def reject_pending_tool(self, request_id):
        with self.permission_lock:
            request = self.pending_permissions.pop(request_id, None)

        if not request:
            return {"status": "missing", "message": f"No pending request found for {request_id}"}

        message = f"Permission rejected: {request_id}. No action was taken."
        self.response_queue.put({
            "type": "status",
            "content": message,
            "chat_id": request.get("chat_id")
        })
        return {"status": "rejected", "message": message}

    def get_pending_permissions(self):
        with self.permission_lock:
            return list(self.pending_permissions.values())

    def _queue_permission(self, action, payload, preview, chat_id=None):
        with self.permission_lock:
            self.permission_counter += 1
            request_id = f"perm_{int(time.time())}_{self.permission_counter}"
            request = {
                "id": request_id,
                "action": action,
                "payload": payload,
                "preview": self._truncate(str(preview), 1200),
                "created_at": time.time(),
                "chat_id": chat_id,
                "agentic_context": {
                    **dict(getattr(self, "_active_permission_context", {}) or {}),
                    "ledger_id": getattr(self, "active_execution_ledger_id", "")
                }
            }
            self.pending_permissions[request_id] = request

        self.response_queue.put({
            "type": "permission_request",
            "id": request_id,
            "action": action,
            "preview": request["preview"],
            "chat_id": chat_id
        })

        if hasattr(self, "_record_execution_evidence"):
            self._record_execution_evidence(
                action,
                "pending",
                f"Permission required: `{request_id}`",
                {"request_id": request_id, "preview": request["preview"]},
                chat_id=chat_id,
                ledger_id=request["agentic_context"].get("ledger_id", "")
            )

        return (
            f"Permission required: `{request_id}`\n"
            f"Action: `{action}`\n"
            f"Preview:\n```\n{request['preview']}\n```"
        )

    def _handle_permission_shortcut(self, prompt, chat_id):
        compact = prompt.strip().lower()

        approve_words = {
            "execute it", "run it", "approve", "approved", "yes", "do it",
            "allow", "continue", "proceed"
        }

        reject_words = {
            "no", "reject", "deny", "stop", "cancel", "dont", "don't"
        }

        if compact not in approve_words and compact not in reject_words:
            return False

        with self.permission_lock:
            pending = list(self.pending_permissions.values())

        if not pending:
            return False

        request = pending[-1]

        if compact in approve_words:
            self.approve_pending_tool(request["id"])
        else:
            self.reject_pending_tool(request["id"])

        return True

    def _execute_permissioned_action(self, request):
        action = request["action"]
        payload = request["payload"]

        if action == "command":
            return self._run_shell_command(payload["code"])

        if action == "read_file":
            return self._read_file_tool(payload["path"])

        if action == "list_dir":
            return self._list_dir_tool(payload["path"])

        if action == "search_files":
            return self._search_files_tool(payload["path"], payload["pattern"])

        if action == "find_in_computer":
            return self._find_in_computer_tool(payload["scope"], payload["issue"], payload.get("pattern", ""))

        if action == "hash_file":
            return self._hash_file_tool(payload["path"])

        if action == "file_compare":
            return self._file_compare_tool(payload["left"], payload["right"])

        if action == "archive_preview":
            return self._archive_preview_tool(payload["path"], payload.get("limit", "80"))

        if action == "virus_scan":
            return self._virus_scan_tool(payload["path"])

        if action == "project_index":
            return self._project_index_tool(payload["path"], payload.get("max_files", "600"))

        if action == "pdf_to_pptx":
            return self._pdf_to_pptx(payload["source"], payload["title"], payload.get("max_pages", "80"))

        if action == "write_file":
            path = payload["path"]
            return self._write_file_with_seatbelt(path, payload.get("content", ""), append=False)

        if action == "append_file":
            path = payload["path"]
            return self._write_file_with_seatbelt(path, payload.get("content", ""), append=True)

        if action == "delete_path":
            path = payload["path"]
            return self._delete_path_safely(path)

        if action == "move_path":
            source = payload["source"]
            destination = payload["destination"]
            return self._move_path_safely(source, destination)

        if action == "web_search":
            query = payload["query"]
            return self._web_search_tool(query)

        if action == "mcp_setup":
            return self._create_mcp_config_draft(payload)

        if action == "mcp_apply":
            return self._apply_mcp_config(payload)

        if action == "project_command":
            return self._run_project_command(payload)

        if action == "ide_paste_run":
            return self._ide_paste_run_tool(payload)

        if action == "clipboard_write":
            return self._clipboard_write_tool(payload.get("text", ""))

        if action == "zip_create":
            return self._zip_create_tool(payload)

        if action == "python":
            res = self._run_seatbelt_subprocess(
                [sys.executable, "-c", payload["code"]],
                mode="artifact",
                cwd=self.agentic_workspace,
                timeout=45
            )
            output = res.stdout if res.returncode == 0 else res.stderr
            output = self._truncate(output.strip() or "(no output)", 12000)
            return "PYTHON EXECUTION:\n```\n" + output + "\n```"

        if action == "applescript":
            return self._run_applescript(payload["code"])

        return f"Unknown permissioned action: {action}"

    def _is_delete_protected_path(self, path):
        real = self._real_path(path)
        home = self._real_path(self.home_path)
        protected_roots = [
            os.path.join(home, "Library", "Containers"),
            os.path.join(home, "Library", "Group Containers"),
            os.path.join(home, "Library", "Application Support"),
            os.path.join(home, "Library", "Keychains"),
            os.path.join(home, "Library", "Messages"),
            os.path.join(home, "Library", "Mail"),
            "/Applications",
            "/System",
            "/Library",
            "/private/var/db",
            "/usr",
            "/bin",
            "/sbin"
        ]

        if self._is_sensitive_path(real):
            return True

        return any(self._path_under(real, root) or real == self._real_path(root) for root in protected_roots)

    def _protected_delete_message(self, path):
        return (
            "DELETE BLOCKED SAFELY:\n"
            f"`{path}`\n\n"
            "KIRA did not delete this because it is inside a protected macOS/app container or another sensitive system area. "
            "Deleting these paths can break apps or trigger macOS privacy protection, even after you approve inside KIRA. "
            "The safer route is to uninstall/remove the parent app or extension from macOS, then let macOS clean its container. "
            "If you still want to inspect it, ask KIRA to open the folder or list it read-only."
        )

    def _is_move_protected_path(self, source, destination):
        source_real = self._real_path(source)
        destination_real = self._real_path(destination)
        return self._is_delete_protected_path(source_real) or self._is_sensitive_path(destination_real)

    def _protected_move_message(self, source, destination):
        return (
            "MOVE BLOCKED SAFELY:\n"
            f"`{source}` -> `{destination}`\n\n"
            "KIRA did not move this because either the source or destination is inside a protected/sensitive macOS area. "
            "Use Finder or the app's own settings/uninstaller for container or system data."
        )

    def _unique_trash_destination(self, source):
        trash_dir = os.path.join(self.home_path, ".Trash")
        os.makedirs(trash_dir, exist_ok=True)

        base = os.path.basename(os.path.normpath(source)) or "kira_deleted_item"
        destination = os.path.join(trash_dir, base)
        if not os.path.exists(destination):
            return destination

        stem, ext = os.path.splitext(base)
        for idx in range(1, 1000):
            candidate = os.path.join(trash_dir, f"{stem} {idx}{ext}")
            if not os.path.exists(candidate):
                return candidate

        return os.path.join(trash_dir, f"{stem} {int(time.time())}{ext}")

    def _unique_quarantine_destination(self, source):
        quarantine_dir = os.path.join(self.agentic_workspace, ".kira_trash")
        os.makedirs(quarantine_dir, exist_ok=True)

        base = os.path.basename(os.path.normpath(source)) or "kira_deleted_item"
        destination = os.path.join(quarantine_dir, base)
        if not os.path.exists(destination):
            return destination

        stem, ext = os.path.splitext(base)
        for idx in range(1, 1000):
            candidate = os.path.join(quarantine_dir, f"{stem} {idx}{ext}")
            if not os.path.exists(candidate):
                return candidate

        return os.path.join(quarantine_dir, f"{stem} {int(time.time())}{ext}")

    def _move_to_kira_quarantine(self, target, original_error):
        try:
            if not os.path.exists(target):
                return ""
            quarantine_target = self._unique_quarantine_destination(target)
            res = self._move_path_with_seatbelt(target, quarantine_target)
            if res.returncode != 0:
                raise OSError((res.stderr or res.stdout or "sandboxed move failed").strip())
            self._log_agentic_event("delete_path_quarantined", {
                "source": target,
                "quarantine_target": quarantine_target,
                "original_error": str(original_error)
            })
            return (
                "macOS Trash was unavailable, so KIRA moved the path to its local quarantine instead:\n"
                f"`{target}` -> `{quarantine_target}`\n\n"
                "Nothing was permanently deleted."
            )
        except Exception as fallback_error:
            return (
                "DELETE FAILED SAFELY:\n"
                f"`{target}`\n\n"
                f"macOS Trash error: {original_error}\n"
                f"KIRA quarantine fallback also failed: {fallback_error}\n\n"
                "Nothing was deleted."
            )

    def _write_file_with_seatbelt(self, path, content, append=False):
        target = self._resolve_path(path)
        parent = os.path.dirname(target) or self.app_root
        script = (
            "import os, sys\n"
            "path = sys.argv[1]\n"
            "mode = sys.argv[2]\n"
            "os.makedirs(os.path.dirname(path) or '.', exist_ok=True)\n"
            "with open(path, mode, encoding='utf-8') as f:\n"
            "    f.write(sys.stdin.read())\n"
        )
        mode = "a" if append else "w"
        res = self._run_seatbelt_subprocess(
            [sys.executable, "-c", script, target, mode],
            mode="mutation",
            input_text=str(content or ""),
            write_paths=[target, parent],
            timeout=30
        )
        output = (res.stdout if res.returncode == 0 else res.stderr).strip()
        self._log_agentic_event("write_file", {
            "path": target,
            "append": append,
            "seatbelt": getattr(res, "kira_seatbelt_mode", "unknown"),
            "returncode": res.returncode,
            "output": self._truncate(output, 2000)
        })
        if res.returncode != 0:
            return (
                "WRITE FAILED SAFELY:\n"
                f"`{target}`\n\n"
                f"{self._truncate(output or '(no output)', 4000)}"
            )
        action = "appended" if append else "written"
        return f"File {action} through Seatbelt `{getattr(res, 'kira_seatbelt_mode', 'unknown')}`: `{target}`"

    def _move_path_with_seatbelt(self, source, destination):
        source_path = self._resolve_path(source)
        destination_path = self._resolve_path(destination)
        script = (
            "import os, shutil, sys\n"
            "source = sys.argv[1]\n"
            "destination = sys.argv[2]\n"
            "os.makedirs(os.path.dirname(destination) or '.', exist_ok=True)\n"
            "shutil.move(source, destination)\n"
        )
        return self._run_seatbelt_subprocess(
            [sys.executable, "-c", script, source_path, destination_path],
            mode="mutation",
            write_paths=[
                source_path,
                os.path.dirname(source_path),
                destination_path,
                os.path.dirname(destination_path)
            ],
            timeout=45
        )

    def _delete_path_safely(self, path):
        target = self._resolve_path(path)

        if not os.path.exists(target):
            return f"DELETE SKIPPED: Path does not exist: `{target}`"

        if self._is_delete_protected_path(target):
            return self._protected_delete_message(target)

        try:
            trash_target = self._unique_trash_destination(target)
            res = self._move_path_with_seatbelt(target, trash_target)
            if res.returncode != 0:
                raise OSError((res.stderr or res.stdout or "sandboxed move to Trash failed").strip())
            self._log_agentic_event("delete_path_trashed", {
                "source": target,
                "trash_target": trash_target,
                "seatbelt": getattr(res, "kira_seatbelt_mode", "unknown")
            })
            return (
                f"Path moved to Trash through Seatbelt `{getattr(res, 'kira_seatbelt_mode', 'unknown')}`, not permanently deleted:\n"
                f"`{target}` -> `{trash_target}`"
            )
        except PermissionError as e:
            return self._move_to_kira_quarantine(target, e)
        except OSError as e:
            return self._move_to_kira_quarantine(target, e)

    def _move_path_safely(self, source, destination):
        source_path = self._resolve_path(source)
        destination_path = self._resolve_path(destination)

        if not os.path.exists(source_path):
            return f"MOVE SKIPPED: Source does not exist: `{source_path}`"

        if self._is_move_protected_path(source_path, destination_path):
            return self._protected_move_message(source_path, destination_path)

        try:
            res = self._move_path_with_seatbelt(source_path, destination_path)
            if res.returncode != 0:
                raise OSError((res.stderr or res.stdout or "sandboxed move failed").strip())
            self._log_agentic_event("move_path", {
                "source": source_path,
                "destination": destination_path,
                "seatbelt": getattr(res, "kira_seatbelt_mode", "unknown")
            })
            return f"Path moved through Seatbelt `{getattr(res, 'kira_seatbelt_mode', 'unknown')}`: `{source_path}` -> `{destination_path}`"
        except PermissionError as e:
            return (
                "MOVE FAILED SAFELY:\n"
                f"`{source_path}` -> `{destination_path}`\n\n"
                f"macOS denied access: {e}\n\n"
                "Nothing was moved."
            )
        except OSError as e:
            return (
                "MOVE FAILED SAFELY:\n"
                f"`{source_path}` -> `{destination_path}`\n\n"
                f"{e}\n\n"
                "Nothing was moved."
            )

    def _continue_after_approved_permission(self, request, result):
        chat_id = request.get("chat_id")
        context = request.get("agentic_context") or {}
        raw_prompt = context.get("raw_prompt") or self._latest_user_prompt(chat_id) or "Continue after the approved action."
        result_text = str(result or "").strip()
        action = request.get("action", "")

        if action == "delete_path" and result_text.startswith(("DELETE BLOCKED", "DELETE FAILED", "DELETE SKIPPED")):
            return result_text

        immediate_result_actions = {
            "write_file", "append_file", "delete_path", "move_path",
            "mcp_apply", "clipboard_write", "zip_create"
        }
        if action in immediate_result_actions:
            return result_text

        if not hasattr(self, "_build_system_instruction") or not hasattr(self, "_synthesize_raw_agentic_result_if_needed"):
            return result_text or "Approved action completed."

        # Approval must never make the UI feel stuck. If Orchestrator is not
        # already warm, return the real tool result immediately instead of
        # loading a large model just to summarize a completed action.
        warm_orchestrator_ready = (
            getattr(self, "current_brain", None) == "orchestrator"
            and getattr(self, "active_model", None) is not None
            and getattr(self, "active_tokenizer", None) is not None
        )
        if not warm_orchestrator_ready:
            return result_text or "Approved action completed."

        try:
            self.response_queue.put({
                "type": "status",
                "content": "Orchestrator V1 is continuing after approval...",
                "chat_id": chat_id
            })
            system_instruction = self._build_system_instruction("orchestrator")
            personalization_context = (
                "\n\nOrchestrator-only personalization RAG. Use only if relevant to the current task; ignore otherwise:\n"
                + json.dumps(self._load_personalization_rag(), ensure_ascii=False)
                if hasattr(self, "_load_personalization_rag")
                else ""
            )
            evidence = (
                "TERMINAL EXECUTION:\nApproved action completed.\n"
                f"Original user task:\n{raw_prompt}\n\n"
                f"Approved action: {request.get('action')}\n"
                f"Tool result:\n{result_text}"
            )
            final_result = self._synthesize_raw_agentic_result_if_needed(
                raw_prompt,
                evidence,
                system_instruction,
                personalization_context,
                chat_id
            )
            final_result = str(final_result or "").strip()
            if hasattr(self, "_enforce_execution_truth"):
                final_result = self._enforce_execution_truth(raw_prompt, final_result, context.get("ledger_id", ""), chat_id)
            return final_result or result_text or "Approved action completed."
        except Exception as e:
            self._log_agentic_event("approval_continuation_error", {"error": str(e), "request": request})
            return result_text or f"Approved action completed, but continuation failed: {e}"

    def _latest_user_prompt(self, chat_id):
        try:
            messages = self._load_chat_messages(chat_id)
            for message in reversed(messages):
                if message.get("role") == "user":
                    return str(message.get("content", "")).strip()
        except Exception:
            pass
        return ""

    def _apply_mcp_config(self, payload):
        draft_path = self._resolve_path(payload.get("draft", ""))
        target = str(payload.get("target", "cursor_project") or "cursor_project").strip()
        custom_path = str(payload.get("path", "") or "").strip()

        if not draft_path or not os.path.exists(draft_path):
            return f"MCP apply failed: draft not found: `{draft_path}`"

        if target == "custom":
            if not custom_path:
                return "MCP apply failed: TARGET custom requires PATH."
            target_path = self._resolve_path(custom_path)
        else:
            target_path = self.mcp_config_targets.get(target)

        if not target_path:
            return f"MCP apply failed: unknown target `{target}`."

        with open(draft_path, "r", encoding="utf-8") as f:
            draft_config = json.load(f)

        if not isinstance(draft_config, dict):
            return "MCP apply failed: draft JSON must be an object."

        if os.path.exists(target_path):
            with open(target_path, "r", encoding="utf-8") as f:
                try:
                    target_config = json.load(f)
                except Exception:
                    target_config = {}
            backup_path = target_path + f".bak_{int(time.time())}"
            shutil.copy2(target_path, backup_path)
        else:
            target_config = {}
            backup_path = None

        if not isinstance(target_config, dict):
            target_config = {}

        target_config.setdefault("mcpServers", {})
        draft_servers = draft_config.get("mcpServers", {})
        if not isinstance(draft_servers, dict):
            return "MCP apply failed: draft needs an `mcpServers` object."

        target_config["mcpServers"].update(draft_servers)
        os.makedirs(os.path.dirname(target_path), exist_ok=True)

        with open(target_path, "w", encoding="utf-8") as f:
            json.dump(target_config, f, indent=2, ensure_ascii=False)

        self._log_agentic_event("mcp_apply", {
            "draft": draft_path,
            "target": target,
            "target_path": target_path,
            "backup": backup_path
        })

        message = f"MCP config applied to `{target_path}`."
        if backup_path:
            message += f"\nBackup created: `{backup_path}`"
        message += "\nRestart or reload the target IDE/app so it picks up the MCP connection."
        return message

    def _open_target_tool(self, target):
        target = str(target or "").strip()

        if not target:
            return "OPEN failed: missing target."

        commands = []

        if re.match(r"^[a-zA-Z][a-zA-Z0-9+.-]*://", target):
            commands.append(["open", target])
        else:
            resolved = self._resolve_path(target)
            if os.path.exists(resolved):
                commands.append(["open", resolved])
            else:
                app_bundle = self._find_app_bundle(target)
                if app_bundle:
                    commands.append(["open", app_bundle])
                commands.append(["open", "-a", target])
                commands.append(["open", target])

        failures = []

        for cmd in commands:
            try:
                res = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
                output = (res.stdout if res.returncode == 0 else res.stderr).strip()

                self._log_agentic_event("open_target", {
                    "target": target,
                    "cmd": cmd,
                    "returncode": res.returncode,
                    "output": output
                })

                if res.returncode == 0:
                    return f"Opened: `{target}`"

                if output:
                    failures.append(output)
            except Exception as e:
                failures.append(str(e))

        return (
            f"OPEN failed for `{target}`.\n"
            "Tried macOS app/path opening. Last error:\n"
            "```\n"
            + self._truncate("\n".join(failures) or "(no error output)", 4000)
            + "\n```"
        )

    def _close_target_tool(self, target):
        target = str(target or "").strip()

        if not target:
            return "CLOSE failed: missing app name."

        if re.search(r"(?i)\b(kira\s*os|this app|the app|this window)\b", target):
            self.response_queue.put({
                "type": "ui_action",
                "action": "quit_kira_os",
                "content": "Closing KIRA OS."
            })
            return "CLOSE: Closing KIRA OS."

        normalized = self._normalize_app_name_for_script(target)
        script = f'tell application "{normalized}" to quit'

        try:
            res = subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                text=True,
                timeout=20
            )
            output = (res.stdout if res.returncode == 0 else res.stderr).strip()

            self._log_agentic_event("close_target", {
                "target": target,
                "script": script,
                "returncode": res.returncode,
                "output": output
            })

            if res.returncode == 0:
                return f"CLOSE: Closed `{normalized}`"

            fallback = self._close_process_fallback(target)
            if fallback:
                return fallback

            return (
                f"CLOSE failed for `{target}`.\n"
                "```\n"
                + self._truncate(output or "(no error output)", 4000)
                + "\n```"
            )
        except Exception as e:
            fallback = self._close_process_fallback(target)
            if fallback:
                return fallback
            return f"CLOSE ERROR for `{target}`: {e}"

    def _close_process_fallback(self, target):
        target_text = str(target or "").strip()
        if not target_text:
            return ""

        try:
            app_bundle = self._find_app_bundle(target_text)
            candidates = [target_text]
            if app_bundle:
                candidates.append(os.path.basename(app_bundle)[:-4])
            candidates = [item for item in dict.fromkeys(candidates) if item]

            for name in candidates:
                res = subprocess.run(
                    ["pkill", "-x", name],
                    capture_output=True,
                    text=True,
                    timeout=10
                )
                if res.returncode == 0:
                    return f"CLOSE: Closed `{name}`"

            return ""
        except Exception:
            return ""

    def _normalize_app_name_for_script(self, app_name):
        app_name = str(app_name or "").strip()
        bundle = self._find_app_bundle(app_name)
        if bundle:
            return os.path.basename(bundle)[:-4]
        return app_name

    def _find_app_bundle(self, app_name):
        wanted = re.sub(r"[^a-z0-9]+", "", str(app_name or "").lower())

        if not wanted:
            return ""

        roots = [
            "/Applications",
            "/System/Applications",
            "/System/Library/CoreServices",
            os.path.join(self.home_path, "Applications"),
        ]

        for root in roots:
            if not os.path.isdir(root):
                continue

            for current_root, dirs, _files in os.walk(root):
                for dirname in dirs:
                    if not dirname.endswith(".app"):
                        continue

                    app_display = dirname[:-4]
                    normalized = re.sub(r"[^a-z0-9]+", "", app_display.lower())

                    if normalized == wanted or wanted in normalized or normalized in wanted:
                        return os.path.join(current_root, dirname)

                dirs[:] = [
                    d for d in dirs
                    if not d.endswith(".app") and current_root.count(os.sep) - root.count(os.sep) < 2
                ]

        return ""

    def _open_in_ide(self, payload):
        path = self._resolve_path(payload.get("path", self.app_root))
        line = str(payload.get("line", "") or "").strip()
        app = str(payload.get("app", "cursor") or "cursor").strip().lower()
        app = self._normalize_ide_name(app)

        if app in {"cursor", "auto"} and shutil.which("cursor"):
            target = f"{path}:{line}" if line else path
            cmd = ["cursor", "-g", target] if line else ["cursor", path]
        elif app == "windsurf" and shutil.which("windsurf"):
            target = f"{path}:{line}" if line else path
            cmd = ["windsurf", "-g", target] if line else ["windsurf", path]
        elif app == "windsurf":
            app_bundle = self._find_app_bundle("Windsurf")
            if app_bundle:
                cmd = ["open", "-a", "Windsurf", path]
            else:
                cmd = ["open", "-a", "Windsurf", path]
        elif app in {"code", "vscode"} and shutil.which("code"):
            target = f"{path}:{line}" if line else path
            cmd = ["code", "-g", target] if line else ["code", path]
        elif app in {"xcode", "xed"} and shutil.which("xed"):
            cmd = ["xed", path]
        elif app == "finder":
            cmd = ["open", "-R", path] if os.path.isfile(path) else ["open", path]
        else:
            cmd = ["open", path]

        res = subprocess.run(cmd, capture_output=True, text=True, timeout=20)
        output = res.stdout if res.returncode == 0 else res.stderr
        output = output.strip()

        self._log_agentic_event("ide_open", {"cmd": cmd, "returncode": res.returncode, "output": output})

        if res.returncode == 0:
            return f"Opened in IDE/app: `{path}`"
        return f"IDE open failed:\n```\n{self._truncate(output or '(no output)', 4000)}\n```"

    def _ide_automation_app_name(self, app):
        normalized = self._normalize_ide_name(app)
        return {
            "cursor": "Cursor",
            "windsurf": "Windsurf",
            "code": "Visual Studio Code",
            "vscode": "Visual Studio Code",
            "xcode": "Xcode"
        }.get(normalized, str(app or "Cursor").strip() or "Cursor")

    def _ide_paste_run_tool(self, payload):
        app = str(payload.get("app", "cursor") or "cursor").strip()
        project_path = self._resolve_path(payload.get("project_path", self.app_root))
        code = str(payload.get("code", "") or "")
        run_method = str(payload.get("run_method", "paste_then_enter") or "paste_then_enter").strip().lower()
        verify_command = str(payload.get("verify_command", "") or "").strip()

        if not code.strip():
            return "IDE PASTE/RUN FAILED SAFELY: no code was provided to paste."

        open_result = self._open_in_ide({
            "path": project_path,
            "app": app
        })
        app_name = self._ide_automation_app_name(app)

        try:
            pb = subprocess.run(
                ["pbcopy"],
                input=code,
                capture_output=True,
                text=True,
                timeout=10
            )
            if pb.returncode != 0:
                return "IDE PASTE/RUN FAILED SAFELY: clipboard write failed:\n```\n" + self._truncate((pb.stderr or pb.stdout).strip(), 2000) + "\n```"

            run_script = ""
            if run_method in {"paste_then_enter", "enter", "return", "terminal_enter"}:
                run_script = 'keystroke return\n'
            elif run_method in {"paste_then_cmd_enter", "cmd_enter", "command_enter"}:
                run_script = 'keystroke return using {command down}\n'
            elif run_method in {"paste_then_ctrl_enter", "ctrl_enter", "control_enter"}:
                run_script = 'keystroke return using {control down}\n'
            elif run_method in {"paste_only", "none", "no_run"}:
                run_script = ""
            else:
                run_script = 'keystroke return\n'

            script = (
                f'tell application "{app_name}" to activate\n'
                "delay 0.8\n"
                'tell application "System Events"\n'
                '    keystroke "v" using {command down}\n'
                "    delay 0.2\n"
                + ("    " + run_script if run_script else "")
                + "end tell\n"
            )
            osa = subprocess.run(
                ["osascript", "-e", script],
                capture_output=True,
                text=True,
                timeout=20
            )

            automation_output = (osa.stdout if osa.returncode == 0 else osa.stderr).strip()
            verified = ""
            if verify_command:
                verified = "\n\nVerification command result:\n" + self._run_project_command({
                    "cwd": project_path,
                    "command": verify_command
                })

            self._log_agentic_event("ide_paste_run", {
                "app": app_name,
                "project_path": project_path,
                "run_method": run_method,
                "returncode": osa.returncode,
                "verify_command": verify_command,
                "output": self._truncate(automation_output, 3000)
            })

            if osa.returncode != 0:
                return (
                    "IDE PASTE/RUN FAILED SAFELY:\n"
                    f"Opened target result: {open_result}\n\n"
                    "macOS automation did not complete:\n"
                    "```\n" + self._truncate(automation_output or "(no output)", 3000) + "\n```"
                )

            status = "pasted and run keystroke triggered" if run_script else "pasted only"
            caution = (
                "\n\nNo verification command was provided, so KIRA triggered the IDE action but did not claim the code's runtime output."
                if not verify_command
                else ""
            )
            return (
                "IDE PASTE/RUN RESULT:\n"
                f"- App: `{app_name}`\n"
                f"- Project/path: `{project_path}`\n"
                f"- Status: {status}\n"
                f"- Code pasted: `{len(code)}` characters\n"
                f"- Open result: {open_result}"
                + caution
                + verified
            )
        except subprocess.TimeoutExpired:
            return "IDE PASTE/RUN FAILED SAFELY: macOS automation timed out. No completion was claimed."
        except Exception as e:
            return f"IDE PASTE/RUN FAILED SAFELY: {e}"

    def _app_integration_tool(self, app_name, action="context"):
        requested = re.sub(r"\s+", " ", str(app_name or "").strip())
        normalized = re.sub(r"[^a-z0-9]+", "", requested.lower())
        profiles = self._popular_app_profiles()
        key = ""
        for candidate, profile in profiles.items():
            names = {
                candidate,
                re.sub(r"[^a-z0-9]+", "", profile["display"].lower())
            }
            if normalized in names or any(normalized and normalized in name for name in names):
                key = candidate
                break
        if not key and normalized:
            key = normalized

        if key == "blender" or normalized == "blender":
            return self._blender_context_tool()

        profile = profiles.get(key, {"display": requested or "Unknown App", "cli": [], "hint": ""})
        display = profile.get("display", requested or key)
        app_path = self._find_app_bundle(display)
        cli_path = self._first_existing_cli(profile.get("cli", []))
        action = str(action or "context").strip().lower()

        docs = []
        for root in [self.computer_roots.get("documents"), self.computer_roots.get("desktop"), self.computer_roots.get("downloads")]:
            if not root or not os.path.isdir(root):
                continue
            try:
                for current_root, dirs, filenames in os.walk(root):
                    depth = current_root.count(os.sep) - root.count(os.sep)
                    dirs[:] = [d for d in dirs if not d.startswith(".") and depth < 1]
                    for filename in filenames[:80]:
                        if display.lower().split()[0] in filename.lower():
                            docs.append(os.path.join(current_root, filename))
                    if len(docs) >= 20:
                        break
            except Exception:
                continue

        payload = {
            "requested": requested,
            "display": display,
            "action": action,
            "app_path": app_path,
            "cli_path": cli_path,
            "hint": profile.get("hint", ""),
            "related_files_sample": docs[:20],
            "bridge_policy": {
                "open_app_or_file": "direct navigation",
                "read_context": "direct if inside readable roots",
                "automation_or_modification": "requires permission",
                "drafts": "allowed inside KIRA workspaces"
            }
        }

        integration_dir = os.path.join(self.architect_workspace, "app_integrations")
        os.makedirs(integration_dir, exist_ok=True)
        state_path = os.path.join(integration_dir, f"{self._safe_filename(display, 'app')}.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(payload, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

        if action in {"open", "launch"} and app_path:
            return self._open_target_tool(app_path)

        return (
            "APP INTEGRATION:\n"
            f"App: `{display}`\n"
            f"Bundle: `{app_path or 'not found'}`\n"
            f"CLI: `{cli_path or 'not found'}`\n"
            f"Bridge state: `{state_path}`\n"
            f"Capability: {profile.get('hint', 'General app open/context bridge.')}\n\n"
            "Related files sampled:\n"
            "```text\n" + ("\n".join(docs[:20]) or "(none found)") + "\n```\n"
            "KIRA can open the app/file directly. GUI automation, installs, and modifications still require permission."
        )

    def _blender_context_tool(self):
        app_path = self._find_app_bundle("Blender")
        cli_path = shutil.which("blender")
        support_roots = [
            os.path.join(self.home_path, "Library", "Application Support", "Blender"),
            os.path.join(self.home_path, "Documents"),
            os.path.join(self.home_path, "Downloads"),
            os.path.join(self.home_path, "Desktop")
        ]
        blend_files = []
        addon_paths = []

        for root in support_roots:
            if not root or not os.path.exists(root) or self._is_sensitive_path(root):
                continue
            try:
                for current_root, dirs, filenames in os.walk(root):
                    depth = current_root.count(os.sep) - root.count(os.sep)
                    dirs[:] = [d for d in dirs if not d.startswith(".") and depth < 3]
                    for filename in filenames:
                        full = os.path.join(current_root, filename)
                        if filename.endswith(".blend") and len(blend_files) < 40:
                            blend_files.append(full)
                        elif filename.endswith(".py") and "addon" in current_root.lower() and len(addon_paths) < 40:
                            addon_paths.append(full)
                    if len(blend_files) >= 40 and len(addon_paths) >= 40:
                        break
            except Exception:
                continue

        script_dir = os.path.join(self.architect_workspace, "blender")
        os.makedirs(script_dir, exist_ok=True)
        script_path = os.path.join(script_dir, "kira_blender_scene_template.py")
        if not os.path.exists(script_path):
            try:
                with open(script_path, "w", encoding="utf-8") as f:
                    f.write(
                        "import bpy\n\n"
                        "# KIRA OS Blender draft script. Review before running in Blender.\n"
                        "bpy.ops.object.select_all(action='SELECT')\n"
                        "bpy.ops.object.delete()\n"
                        "bpy.ops.mesh.primitive_cube_add(size=2, location=(0, 0, 1))\n"
                        "cube = bpy.context.object\n"
                        "cube.name = 'KIRA_Draft_Cube'\n"
                        "bpy.ops.object.light_add(type='AREA', location=(0, -3, 5))\n"
                        "bpy.context.object.data.energy = 450\n"
                        "bpy.ops.object.camera_add(location=(4, -6, 4), rotation=(1.1, 0, 0.58))\n"
                        "bpy.context.scene.camera = bpy.context.object\n"
                    )
            except Exception:
                pass

        state = {
            "app_path": app_path,
            "cli_path": cli_path,
            "script_template": script_path,
            "blend_files": blend_files[:40],
            "addon_files": addon_paths[:40],
            "policy": {
                "open_blender": "direct navigation",
                "draft_script": "direct inside KIRA workspace",
                "run_blender_script": "requires permission because it changes a scene/file"
            }
        }
        state_path = os.path.join(script_dir, "blender_integration_state.json")
        try:
            with open(state_path, "w", encoding="utf-8") as f:
                json.dump(state, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

        return (
            "BLENDER INTEGRATION:\n"
            f"Bundle: `{app_path or 'not found'}`\n"
            f"CLI: `{cli_path or 'not found'}`\n"
            f"Bridge state: `{state_path}`\n"
            f"Draft script template: `{script_path}`\n\n"
            "Recent/sample .blend files:\n"
            "```text\n" + ("\n".join(blend_files[:25]) or "(none found)") + "\n```\n\n"
            "Add-on/script files sampled:\n"
            "```text\n" + ("\n".join(addon_paths[:25]) or "(none found)") + "\n```\n"
            "KIRA can open Blender directly, draft scene scripts in the workspace, and request permission before running scripts or modifying files."
        )

    def _headless_browser_binary(self):
        names = ["google-chrome", "chrome", "chromium", "chromium-browser", "msedge", "microsoft-edge", "brave-browser"]
        for name in names:
            found = shutil.which(name)
            if found:
                return found

        candidates = [
            "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            "/Applications/Chromium.app/Contents/MacOS/Chromium",
            "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
            "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser",
            os.path.join(self.home_path, "Applications", "Google Chrome.app", "Contents", "MacOS", "Google Chrome"),
            os.path.join(self.home_path, "Applications", "Chromium.app", "Contents", "MacOS", "Chromium")
        ]
        for path in candidates:
            if os.path.exists(path):
                return path
        return ""

    def _headless_browser_dump_dom(self, url, timeout=25):
        browser = self._headless_browser_binary()
        if not browser:
            return "", "no_headless_browser"

        profile_dir = os.path.join(self.agentic_workspace, "headless_browser_profile")
        os.makedirs(profile_dir, exist_ok=True)
        command = [
            browser,
            "--headless=new",
            "--disable-gpu",
            "--no-first-run",
            "--disable-background-networking",
            f"--user-data-dir={profile_dir}",
            "--dump-dom",
            url
        ]

        try:
            res = self._run_seatbelt_subprocess(
                command,
                mode="web",
                write_paths=[profile_dir],
                network=True,
                timeout=timeout
            )
            if res.returncode == 0 and (res.stdout or "").strip():
                return res.stdout, os.path.basename(browser) + f" via Seatbelt {getattr(res, 'kira_seatbelt_mode', 'unknown')}"
        except Exception:
            pass

        fallback = list(command)
        fallback[1] = "--headless"
        try:
            res = self._run_seatbelt_subprocess(
                fallback,
                mode="web",
                write_paths=[profile_dir],
                network=True,
                timeout=timeout
            )
            if res.returncode == 0 and (res.stdout or "").strip():
                return res.stdout, os.path.basename(browser) + f" via Seatbelt {getattr(res, 'kira_seatbelt_mode', 'unknown')}"
            return "", (res.stderr or res.stdout or "headless browser returned no DOM").strip()
        except Exception as e:
            return "", str(e)

    def _web_search_tool(self, query):
        query = re.sub(r"\s+", " ", str(query or "").strip())
        if not query:
            return "WEB_SEARCH skipped: missing query."

        url = "https://duckduckgo.com/html/?q=" + quote_plus(query)
        try:
            fetched = self._web_fetch_tool(url, max_chars=10000, force_headless=True)
            self._log_agentic_event("web_search", {"query": query, "url": url, "mode": "headless"})
            return (
                "WEB_SEARCH:\n"
                f"Query: `{query}`\n"
                f"Search URL: `{url}`\n\n"
                + fetched
            )
        except Exception as e:
            return f"WEB_SEARCH ERROR for `{query}`: {e}"

    def _web_open_tool(self, target):
        target = re.sub(r"\s+", " ", str(target or "").strip())
        if not target:
            return "WEB_OPEN skipped: missing URL or query."

        url = target if self._looks_like_url(target) else "https://www.google.com/search?q=" + quote_plus(target)
        try:
            res = subprocess.run(["open", url], check=False, capture_output=True, text=True, timeout=10)
            output = (res.stdout if res.returncode == 0 else res.stderr).strip()
            self._log_agentic_event("web_open", {"target": target, "url": url, "returncode": res.returncode, "output": output})
            if res.returncode != 0:
                return "WEB_OPEN ERROR:\n```\n" + self._truncate(output or "(no output)", 4000) + "\n```"
            return f"WEB_OPEN: Opened `{url}`"
        except Exception as e:
            return f"WEB_OPEN ERROR for `{target}`: {e}"

    def _web_fetch_tool(self, target, max_chars="12000", force_headless=False):
        target = re.sub(r"\s+", " ", str(target or "").strip())
        if not target:
            return "WEB_FETCH skipped: missing URL."

        try:
            max_chars_int = max(1200, min(int(max_chars or 12000), 50000))
        except Exception:
            max_chars_int = 12000

        original_target = target
        if not self._looks_like_url(target):
            target = "https://duckduckgo.com/html/?q=" + quote_plus(target)

        try:
            source = "urllib"
            content_type = "text/html"
            html_text = ""

            if force_headless or self._headless_browser_binary():
                html_text, source = self._headless_browser_dump_dom(target)

            if not html_text:
                request = Request(
                    target,
                    headers={
                        "User-Agent": "Mozilla/5.0 KIRA-OS-Agentic-Browser/1.0",
                        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,text/plain;q=0.8,*/*;q=0.5"
                    }
                )
                with urlopen(request, timeout=20) as response:
                    content_type = response.headers.get("Content-Type", "")
                    raw = response.read(2_000_000)

                encoding = "utf-8"
                charset_match = re.search(r"charset=([A-Za-z0-9_-]+)", content_type, re.IGNORECASE)
                if charset_match:
                    encoding = charset_match.group(1)
                html_text = raw.decode(encoding, errors="replace")
                source = "urllib"

            title_match = re.search(r"(?is)<title[^>]*>(.*?)</title>", html_text)
            title = self._clean_web_text(title_match.group(1)) if title_match else target
            readable = self._html_to_readable_text(html_text)
            readable = self._truncate(readable, max_chars_int)

            self._log_agentic_event("web_fetch", {
                "url": target,
                "original_target": original_target,
                "content_type": content_type,
                "title": title,
                "chars": len(readable),
                "source": source
            })

            return (
                "WEB_FETCH:\n"
                f"Target: `{original_target}`\n"
                f"URL: `{target}`\n"
                f"Browser: `{source}`\n"
                f"Title: {title}\n"
                f"Content-Type: `{content_type or 'unknown'}`\n"
                "Readable text:\n"
                "```text\n"
                + readable
                + "\n```"
            )
        except Exception as e:
            return f"WEB_FETCH ERROR for `{target}`: {e}"

    def _looks_like_url(self, value):
        parsed = urlparse(str(value or ""))
        return parsed.scheme in {"http", "https"} and bool(parsed.netloc)

    def _html_to_readable_text(self, html_text):
        text = re.sub(r"(?is)<script[^>]*>.*?</script>", " ", str(html_text or ""))
        text = re.sub(r"(?is)<style[^>]*>.*?</style>", " ", text)
        text = re.sub(r"(?is)<noscript[^>]*>.*?</noscript>", " ", text)
        text = re.sub(r"(?i)<br\s*/?>", "\n", text)
        text = re.sub(r"(?i)</(?:p|div|section|article|header|footer|li|h[1-6]|tr)>", "\n", text)
        text = re.sub(r"(?is)<[^>]+>", " ", text)
        return self._clean_web_text(text)

    def _clean_web_text(self, text):
        text = unescape(str(text or ""))
        text = re.sub(r"[ \t\r\f\v]+", " ", text)
        text = re.sub(r"\n\s+", "\n", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()

    def _run_project_command(self, payload):
        cwd = self._resolve_path(payload.get("cwd", self.app_root))
        command = str(payload.get("command", "") or "").strip()

        if not command:
            return "PROJECT_COMMAND failed: missing COMMAND."
        if not os.path.isdir(cwd):
            return f"PROJECT_COMMAND failed: CWD is not a folder: `{cwd}`"

        res = self._run_seatbelt_subprocess(
            command,
            cwd=cwd,
            shell=True,
            mode="project",
            write_paths=[cwd],
            timeout=120
        )
        output = res.stdout if res.returncode == 0 else res.stderr
        output = self._truncate(output.strip() or "(no output)", 12000)

        self._log_agentic_event("project_command", {
            "cwd": cwd,
            "command": command,
            "seatbelt": getattr(res, "kira_seatbelt_mode", "unknown"),
            "returncode": res.returncode,
            "output": output
        })

        return (
            f"PROJECT COMMAND `{command}` in `{cwd}` exited with code `{res.returncode}` "
            f"[Seatbelt: {getattr(res, 'kira_seatbelt_mode', 'unknown')}]:\n"
            "```\n" + output + "\n```"
        )

    def _create_mcp_config_draft(self, payload):
        name = self._safe_filename(payload.get("name", "kira_connector"), "kira_connector")
        command = str(payload.get("command", "")).strip()

        if not command:
            return "MCP setup needs a COMMAND field."

        try:
            args = json.loads(payload.get("args_json") or "[]")
            if not isinstance(args, list):
                args = []
        except Exception:
            args = []

        try:
            env = json.loads(payload.get("env_json") or "{}")
            if not isinstance(env, dict):
                env = {}
        except Exception:
            env = {}

        raw_config = str(payload.get("config_json", "")).strip()

        if raw_config:
            try:
                config = json.loads(raw_config)
            except Exception:
                config = {
                    "mcpServers": {
                        name: {"command": command, "args": args, "env": env}
                    },
                    "note": "CONFIG_JSON could not be parsed, generated fallback config."
                }
        else:
            config = {
                "mcpServers": {
                    name: {"command": command, "args": args, "env": env}
                }
            }

        draft_path = self._unique_path(os.path.join(self.mcp_workspace, f"{name}.mcp.json"))

        with open(draft_path, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)

        return (
            f"MCP connector draft created: `{draft_path}`\n"
            "I did not install packages or modify global MCP settings."
        )

    def _virus_scan_tool(self, path, max_files=900):
        scan_path = self._resolve_path(path or "downloads")

        if not os.path.exists(scan_path):
            return f"Virus scan could not start because the path was not found: `{scan_path}`"
        if self._is_sensitive_path(scan_path):
            return "Virus scan skipped because that path matches KIRA OS sensitive-path guard rules."
        if not self._is_read_allowed(scan_path):
            return f"Virus scan needs read permission for `{scan_path}` before it can inspect that location."

        started = time.time()
        deadline = started + 14
        clamscan_path = shutil.which("clamscan")
        scanned = 0
        skipped = 0
        flagged = []
        clamscan_output = ""
        clamscan_note = "ClamAV not found locally, so KIRA used a read-only heuristic malware scan."

        risky_extensions = {
            ".app", ".dmg", ".pkg", ".mpkg", ".command", ".sh", ".bash", ".zsh",
            ".py", ".pl", ".rb", ".jar", ".class", ".js", ".vbs", ".scr",
            ".exe", ".msi", ".iso", ".zip", ".rar", ".7z", ".tar", ".gz"
        }
        suspicious_names = [
            "crack", "keygen", "patcher", "activator", "trojan", "malware",
            "virus", "stealer", "miner", "injector", "payload", "dropper"
        ]
        partial_suffixes = (".download", ".crdownload", ".part", ".tmp")

        if os.path.isfile(scan_path):
            candidates = [scan_path]
        else:
            candidates = []
            for root, dirs, files in os.walk(scan_path):
                if time.time() > deadline:
                    skipped += len(files)
                    dirs[:] = []
                    break
                dirs[:] = [
                    dirname for dirname in dirs
                    if not dirname.startswith(".") and not self._is_sensitive_path(os.path.join(root, dirname))
                ]

                if self._is_sensitive_path(root):
                    skipped += len(files)
                    continue

                for filename in files:
                    full = os.path.join(root, filename)
                    if filename.startswith(".") or self._is_sensitive_path(full):
                        skipped += 1
                        continue
                    candidates.append(full)
                    if len(candidates) >= int(max_files):
                        break
                if len(candidates) >= int(max_files):
                    break

        for full in candidates:
            if time.time() > deadline:
                skipped += max(0, len(candidates) - scanned)
                break
            try:
                scanned += 1
                name = os.path.basename(full)
                lowered = name.lower()
                ext = os.path.splitext(name)[1].lower()
                stat = os.stat(full)
                reasons = []

                if ext in risky_extensions:
                    reasons.append("risky file type")
                if os.access(full, os.X_OK) and ext not in {".jpg", ".jpeg", ".png", ".gif", ".pdf", ".txt", ".md"}:
                    reasons.append("executable permission")
                if any(marker in lowered for marker in suspicious_names):
                    reasons.append("suspicious filename")
                if lowered.endswith(partial_suffixes):
                    reasons.append("partial/temp download")
                if stat.st_size > 700 * 1024 * 1024 and ext in {".dmg", ".pkg", ".zip", ".rar", ".7z", ".iso"}:
                    reasons.append("very large installer/archive")
                if self._read_quarantine_flag(full):
                    reasons.append("macOS quarantine flag")

                if reasons:
                    flagged.append({
                        "path": full,
                        "name": name,
                        "size": stat.st_size,
                        "reasons": reasons[:5]
                    })
            except Exception:
                skipped += 1

        if clamscan_path:
            try:
                res = self._run_seatbelt_subprocess(
                    [clamscan_path, "-r", "--infected", "--no-summary", scan_path],
                    mode="read_only",
                    timeout=18
                )
                raw = (res.stdout or res.stderr or "").strip()
                clamscan_output = self._truncate(raw or "(no infected files reported)", 6000)
                clamscan_note = f"ClamAV scan ran read-only through Seatbelt `{getattr(res, 'kira_seatbelt_mode', 'unknown')}`. KIRA did not quarantine, delete, or change files."
            except subprocess.TimeoutExpired:
                clamscan_note = "ClamAV is installed, but the read-only scan timed out after 18 seconds."
            except Exception as e:
                clamscan_note = f"ClamAV is installed, but KIRA could not run it: {e}"

        def size_label(value):
            units = ["B", "KB", "MB", "GB", "TB"]
            amount = float(value or 0)
            unit = 0
            while amount >= 1024 and unit < len(units) - 1:
                amount /= 1024
                unit += 1
            return f"{amount:.1f}{units[unit]}" if unit else f"{int(amount)}B"

        top_flagged = sorted(flagged, key=lambda item: (len(item["reasons"]), item["size"]), reverse=True)[:25]
        if top_flagged:
            rows = [
                f"{size_label(item['size']):>9}  {', '.join(item['reasons']):<58}  {item['name']}"
                for item in top_flagged
            ]
            flagged_text = "\n".join(rows)
        else:
            flagged_text = "(none)"

        duration = round(time.time() - started, 1)
        report = (
            "Virus scan completed as a read-only safety check. No files were changed, deleted, quarantined, or executed.\n\n"
            f"Scope: `{scan_path}`\n"
            f"Files inspected by KIRA heuristics: `{scanned}`\n"
            f"Skipped hidden/sensitive/unreadable files: `{skipped}`\n"
            f"Potentially risky items: `{len(flagged)}`\n"
            f"Duration: `{duration}s`\n"
            f"Antivirus engine: {clamscan_note}\n\n"
            "Potential risk signals:\n"
            "```text\n"
            "     size  reason                                                    name\n"
            f"{flagged_text}\n"
            "```\n"
        )

        if clamscan_output:
            report += "\nClamAV infected-file output:\n```text\n" + clamscan_output + "\n```\n"

        report += (
            "\nThis is not a replacement for a full security product, but it gives Orchestrator V1 a safe local threat signal. "
            "If anything looks suspicious, ask me to inspect it deeper before deleting anything."
        )
        return report

    def _read_quarantine_flag(self, path):
        xattr_path = shutil.which("xattr")
        if not xattr_path:
            return ""

        try:
            res = subprocess.run(
                [xattr_path, "-p", "com.apple.quarantine", path],
                capture_output=True,
                text=True,
                timeout=2
            )
            if res.returncode == 0 and (res.stdout or "").strip():
                return res.stdout.strip()
        except Exception:
            return ""

        return ""

    def _optimise_scan_tool(self):
        started = time.time()
        deadline = started + 14
        disk = shutil.disk_usage(self.home_path)
        specs = self._system_specs_summary()
        roots = [
            ("Downloads", self.computer_roots.get("downloads")),
            ("Desktop", self.computer_roots.get("desktop")),
            ("Documents", self.computer_roots.get("documents")),
        ]

        file_candidates = []
        duplicate_name_groups = {}
        skipped = 0
        now = time.time()
        max_per_root = 550

        for label, root in roots:
            if not root or not os.path.isdir(root) or not self._is_read_allowed(root):
                continue

            scanned_in_root = 0
            for current_root, dirs, files in os.walk(root):
                if time.time() > deadline:
                    skipped += len(files)
                    dirs[:] = []
                    break
                dirs[:] = [
                    dirname for dirname in dirs
                    if not dirname.startswith(".") and not self._is_sensitive_path(os.path.join(current_root, dirname))
                ]

                if self._is_sensitive_path(current_root):
                    skipped += len(files)
                    continue

                for filename in files:
                    full = os.path.join(current_root, filename)
                    if filename.startswith(".") or self._is_sensitive_path(full):
                        skipped += 1
                        continue

                    try:
                        stat = os.stat(full)
                    except Exception:
                        skipped += 1
                        continue

                    scanned_in_root += 1
                    ext = os.path.splitext(filename)[1].lower()
                    age_days = max(0, int((now - stat.st_mtime) / 86400))
                    reasons = []

                    if stat.st_size >= 250 * 1024 * 1024:
                        reasons.append("large")
                    if label == "Downloads" and ext in {".dmg", ".pkg", ".zip", ".rar", ".7z", ".iso", ".tar", ".gz"}:
                        reasons.append("downloaded installer/archive")
                    if age_days >= 90:
                        reasons.append("old")
                    if filename.lower().endswith((".download", ".crdownload", ".part", ".tmp")):
                        reasons.append("partial/temp")
                    if re.search(r"\(\d+\)| copy\b| duplicate\b", filename, re.IGNORECASE):
                        reasons.append("possible duplicate")

                    key = filename.lower()
                    duplicate_name_groups.setdefault(key, []).append(full)

                    if reasons:
                        file_candidates.append({
                            "name": filename,
                            "path": full,
                            "root": label,
                            "size": stat.st_size,
                            "age_days": age_days,
                            "reasons": reasons[:5]
                        })

                    if scanned_in_root >= max_per_root:
                        break

                if scanned_in_root >= max_per_root:
                    break

            if time.time() > deadline:
                break

        for paths in duplicate_name_groups.values():
            if len(paths) <= 1:
                continue
            for full in paths[:4]:
                try:
                    stat = os.stat(full)
                    file_candidates.append({
                        "name": os.path.basename(full),
                        "path": full,
                        "root": self._root_label_for_path(full),
                        "size": stat.st_size,
                        "age_days": max(0, int((now - stat.st_mtime) / 86400)),
                        "reasons": ["same filename duplicate group"]
                    })
                except Exception:
                    skipped += 1

        app_candidates = self._application_optimise_candidates(deadline=deadline)
        file_candidates = sorted(
            file_candidates,
            key=lambda item: (item["size"], item["age_days"], len(item["reasons"])),
            reverse=True
        )[:50]

        def size_label(value):
            units = ["B", "KB", "MB", "GB", "TB"]
            amount = float(value or 0)
            unit = 0
            while amount >= 1024 and unit < len(units) - 1:
                amount /= 1024
                unit += 1
            return f"{amount:.1f}{units[unit]}" if unit else f"{int(amount)}B"

        if file_candidates:
            file_rows = [
                f"{size_label(item['size']):>9}  {item['age_days']:>4}d  {', '.join(item['reasons']):<34}  {item['path']}"
                for item in file_candidates[:30]
            ]
            file_text = "\n".join(file_rows)
        else:
            file_text = "(no strong file cleanup candidates found)"

        if app_candidates:
            app_rows = [
                f"{size_label(item['size']):>9}  {item['age_days']:>4}d  {item['name']}  {item['path']}"
                for item in app_candidates[:20]
            ]
            app_text = "\n".join(app_rows)
        else:
            app_text = "(no app candidates found from the readable app map)"

        duration = round(time.time() - started, 1)
        return (
            "Optimisation scan completed read-only. No files or apps were changed, moved, deleted, or opened.\n\n"
            f"System specs:\n{specs}\n\n"
            f"Home disk: `{size_label(disk.free)}` free of `{size_label(disk.total)}` "
            f"(`{round((disk.used / disk.total) * 100, 1) if disk.total else 0}%` used)\n"
            f"Skipped hidden/sensitive/unreadable items: `{skipped}`\n"
            f"Scan duration: `{duration}s`\n\n"
            "Top cleanup/move candidates:\n"
            "```text\n"
            "     size   age   reason                              path\n"
            f"{file_text}\n"
            "```\n\n"
            "Application review candidates:\n"
            "```text\n"
            "     size   age   app                                 path\n"
            f"{app_text}\n"
            "```\n\n"
            "Suggested safe moves usually mean installers/archives/videos go to `~/Documents/KIRA_Archive` or an external drive. "
            "Deletion must be explicit: the user must name exactly what to delete or move before KIRA queues MOVE_PATH or DELETE_PATH."
        )

    def _system_specs_summary(self):
        def run_read(cmd, timeout=4):
            try:
                res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
                return (res.stdout or res.stderr or "").strip()
            except Exception:
                return ""

        macos = run_read(["sw_vers"])
        cpu = run_read(["sysctl", "-n", "machdep.cpu.brand_string"])
        mem = run_read(["sysctl", "-n", "hw.memsize"])
        try:
            mem_label = f"{round(int(mem) / (1024 ** 3), 1)} GB"
        except Exception:
            mem_label = mem or "unknown"

        lines = []
        if macos:
            lines.append(macos)
        if cpu:
            lines.append("CPU: " + cpu)
        if mem_label:
            lines.append("Memory: " + mem_label)
        return "\n".join(lines) or "System specs unavailable."

    def _application_optimise_candidates(self, max_apps=35, deadline=None):
        roots = [
            self.computer_roots.get("applications"),
            self.computer_roots.get("user_applications")
        ]
        apps = []
        now = time.time()

        for root in roots:
            if not root or not os.path.isdir(root) or not self._is_read_allowed(root):
                continue

            try:
                entries = [entry for entry in os.scandir(root) if entry.name.endswith(".app")]
            except Exception:
                continue

            for entry in entries[:max_apps]:
                if deadline and time.time() > deadline:
                    break
                try:
                    stat = entry.stat()
                    size = self._folder_size_lite(entry.path, max_files=260, deadline=deadline)
                    apps.append({
                        "name": entry.name[:-4],
                        "path": entry.path,
                        "size": size,
                        "age_days": max(0, int((now - stat.st_mtime) / 86400))
                    })
                except Exception:
                    continue

        apps.sort(key=lambda item: (item["size"], item["age_days"]), reverse=True)
        return apps[:25]

    def _folder_size_lite(self, path, max_files=900, deadline=None):
        total = 0
        count = 0
        for root, dirs, files in os.walk(path):
            if deadline and time.time() > deadline:
                break
            dirs[:] = [dirname for dirname in dirs if not dirname.startswith(".")]
            for filename in files:
                if deadline and time.time() > deadline:
                    return total
                try:
                    total += os.path.getsize(os.path.join(root, filename))
                    count += 1
                except Exception:
                    continue
                if count >= max_files:
                    return total
        return total

    def _root_label_for_path(self, path):
        for label, root in self.computer_roots.items():
            if root and self._path_under(path, root):
                return label
        return "unknown"

    def _read_file_tool(self, path):
        try:
            if not os.path.exists(path):
                return f"READ_FILE: Path not found: `{path}`"
            if not os.path.isfile(path):
                return f"READ_FILE: Not a file: `{path}`"

            with open(path, "r", encoding="utf-8", errors="replace") as f:
                content = self._truncate(f.read(), 12000)

            return "READ_FILE: `" + path + "`\n```\n" + content + "\n```"
        except Exception as e:
            return f"READ_FILE ERROR: `{path}`\n{e}"

    def _list_dir_tool(self, path):
        try:
            if not os.path.exists(path):
                return f"LIST_DIR: Path not found: `{path}`"
            if not os.path.isdir(path):
                return f"LIST_DIR: Not a directory: `{path}`"

            entries = []
            for name in sorted(os.listdir(path))[:250]:
                full = os.path.join(path, name)
                kind = "dir" if os.path.isdir(full) else "file"
                size = os.path.getsize(full) if os.path.isfile(full) else "-"
                entries.append(f"{kind:4} {str(size):>10} {name}")

            output = "\n".join(entries) or "(empty)"
            return "LIST_DIR: `" + path + "`\n```\n" + output + "\n```"
        except Exception as e:
            return f"LIST_DIR ERROR: `{path}`\n{e}"

    def _search_files_tool(self, path, pattern):
        try:
            if not os.path.exists(path):
                return f"SEARCH_FILES: Path not found: `{path}`"

            try:
                res = self._run_seatbelt_subprocess(
                    ["rg", "-n", "--hidden", "--glob", "!.git/*", pattern, path],
                    mode="read_only",
                    timeout=12
                )
                output = res.stdout if res.stdout else res.stderr
                output = self._truncate(output.strip() or "(no matches)", 12000)
                return f"SEARCH_FILES: `{pattern}` in `{path}`\n```\n{output}\n```"
            except FileNotFoundError:
                matches = []
                regex = re.compile(pattern)
                deadline = time.time() + 10
                for root, dirs, files in os.walk(path):
                    if time.time() > deadline:
                        break
                    dirs[:] = [d for d in dirs if d != ".git"]
                    for filename in files:
                        if time.time() > deadline:
                            break
                        full = os.path.join(root, filename)
                        try:
                            with open(full, "r", encoding="utf-8", errors="replace") as f:
                                for line_no, line in enumerate(f, 1):
                                    if regex.search(line):
                                        matches.append(f"{full}:{line_no}:{line.rstrip()}")
                                        if len(matches) >= 200:
                                            break
                        except Exception:
                            continue
                    if len(matches) >= 200:
                        break

                output = self._truncate("\n".join(matches) or "(no matches)", 12000)
                return f"SEARCH_FILES: `{pattern}` in `{path}`\n```\n{output}\n```"
        except Exception as e:
            return f"SEARCH_FILES ERROR: {e}"

    def _find_in_computer_tool(self, scope, issue, pattern=""):
        if not os.path.exists(scope):
            return f"FIND_IN_COMPUTER: Scope not found: `{scope}`"

        search_pattern = pattern or self._keywords_to_pattern(issue)

        findings = [
            f"Read-only investigation scope: {scope}",
            f"Issue: {issue}",
            f"Pattern: {search_pattern}",
            self._search_files_tool(scope, search_pattern),
            "No fixes were applied. Fixing requires separate permission."
        ]

        return "\n\n".join(findings)

    def _pdf_to_pptx(self, source, title, max_pages="80"):
        try:
            from pptx import Presentation
            from pptx.util import Inches
            import fitz
        except Exception:
            return "PDF-to-PPTX needs `python-pptx` and `PyMuPDF` installed locally."

        try:
            if not os.path.exists(source):
                return f"PDF source not found: `{source}`"

            max_pages_int = max(1, min(int(max_pages or 80), 200))
            safe_title = self._safe_filename(title, "pdf_deck")
            pptx_path = self._unique_path(os.path.join(self.agentic_workspace, f"{safe_title}.pptx"))

            doc = fitz.open(source)
            prs = Presentation()
            prs.slide_width = Inches(13.333)
            prs.slide_height = Inches(7.5)

            count = min(len(doc), max_pages_int)
            image_paths = []

            for i in range(count):
                page = doc[i]
                pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
                image_path = os.path.join(self.agentic_workspace, f"{safe_title}_page_{i + 1}.png")
                pix.save(image_path)
                image_paths.append(image_path)

                slide = prs.slides.add_slide(prs.slide_layouts[6])
                slide.shapes.add_picture(image_path, 0, 0, width=prs.slide_width, height=prs.slide_height)

            prs.save(pptx_path)
            self._record_artifact(pptx_path, "presentation", title)

            pdf_export_note = "PPTX generated. Export to PDF from PowerPoint/Keynote if needed."
            return f"PDF converted to image-based PPTX: `{pptx_path}`\n{pdf_export_note}"
        except Exception as e:
            return f"PDF-to-PPTX Error: {e}"

    def _extract_blocks(self, text, tag):
        pattern = rf"\[\s*{tag}\s*\](.*?)\[\s*/\s*{tag}\s*\]"
        return re.findall(pattern, str(text or ""), re.DOTALL | re.IGNORECASE)

    def _replace_block_once(self, text, tag, block, replacement):
        exact = f"[{tag}]{block}[/{tag}]"
        if exact in str(text or ""):
            return str(text or "").replace(exact, replacement, 1)

        pattern = rf"(?is)\[\s*{tag}\s*\]{re.escape(block)}\[\s*/\s*{tag}\s*\]"
        return re.sub(pattern, lambda _match: replacement, str(text or ""), count=1)

    def _parse_fields(self, block):
        fields = {}
        current_key = None
        buffer = []

        def flush():
            if current_key:
                fields[current_key] = "\n".join(buffer).strip()

        for line in str(block or "").splitlines():
            match = re.match(r"^\s*([A-Z_]+)\s*:\s*(.*)$", line)
            if match:
                flush()
                current_key = match.group(1).lower()
                buffer = [match.group(2)]
            else:
                if current_key:
                    buffer.append(line)

        flush()
        return fields

    def _resolve_path(self, path):
        path = str(path or "").strip()
        if len(path) >= 2 and path[0] == path[-1] and path[0] in {"'", '"'}:
            path = path[1:-1].strip()
        if not path:
            return self.app_root

        if path in self.computer_roots:
            return self.computer_roots[path]

        alias = path.lower()
        if alias in {"computer", "my computer", "mac", "kira os", "os map", "workspace map"}:
            return self.computer_map_path
        if alias in {"architect", "technical architect", "architect workspace"}:
            return self.architect_workspace
        if alias in {"ide", "ide bridge", "editor bridge"}:
            return self.ide_bridge_path
        if alias in {"mcp", "mcp workspace", "connectors", "connector workspace"}:
            return self.mcp_workspace
        if alias in {"home", "~"}:
            return self.home_path

        path = os.path.expanduser(path)
        path = os.path.expandvars(path)

        if not os.path.isabs(path):
            path = os.path.abspath(os.path.join(self.app_root, path))

        return path

    def _real_path(self, path):
        try:
            return os.path.realpath(os.path.abspath(os.path.expanduser(str(path or ""))))
        except Exception:
            return os.path.abspath(os.path.expanduser(str(path or "")))

    def _path_under(self, path, root):
        try:
            path_real = self._real_path(path)
            root_real = self._real_path(root)
            return os.path.commonpath([path_real, root_real]) == root_real
        except Exception:
            return False

    def _is_sensitive_path(self, path):
        lower_path = self._real_path(path).lower()

        for marker in self.sensitive_path_markers:
            if marker.lower() in lower_path:
                return True

        basename = os.path.basename(lower_path)
        if basename.startswith(".") and basename not in {".", ".."}:
            return True

        return False

    def _is_read_allowed(self, path):
        if not path or self._is_sensitive_path(path):
            return False

        for root in self.readable_roots:
            if self._path_under(path, root):
                return True

        return False

    def _read_permission_preview(self, path):
        return (
            f"Read-only access requested outside the default KIRA OS readable map:\n{path}\n"
            "This may be broad or sensitive, so it needs your approval."
        )

    def _safe_filename(self, name, fallback):
        cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", str(name or "").strip()).strip("_")
        return cleaned[:80] or fallback

    def _unique_path(self, path):
        if not os.path.exists(path):
            return path

        base, ext = os.path.splitext(path)
        counter = 2

        while True:
            candidate = f"{base}_{counter}{ext}"
            if not os.path.exists(candidate):
                return candidate
            counter += 1

    def _truncate(self, text, limit=8000):
        text = str(text or "")
        if len(text) <= limit:
            return text
        return text[:limit] + "\n... truncated ..."

    def _format_timestamp(self, value):
        try:
            timestamp = float(value or 0)
            if timestamp <= 0:
                return ""
            return time.strftime("%b %d, %Y %I:%M %p", time.localtime(timestamp))
        except Exception:
            return ""

    def _keywords_to_pattern(self, issue):
        words = re.findall(r"[A-Za-z0-9_]{3,}", str(issue or ""))
        words = [w for w in words if w.lower() not in {"the", "and", "for", "with", "that", "this", "from"}]
        if not words:
            return "."
        return "|".join(re.escape(w) for w in words[:8])

    def _log_private_thoughts(self, thoughts):
        if thoughts:
            self._log_agentic_event("private_thought_process", {"thoughts": self._truncate(thoughts, 6000)})

    def _log_agentic_event(self, event_type, payload):
        try:
            log_path = os.path.join(self.agentic_logs_path, "agentic_events.jsonl")
            record = {
                "time": time.time(),
                "type": event_type,
                "payload": payload
            }
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(record, ensure_ascii=False) + "\n")
        except Exception:
            pass


# Legacy standalone action helpers kept for compatibility with older imports.
import os
import subprocess

def open_app(app_name: str) -> str:
    """Uses native macOS commands to open any application."""
    try:
        # The '-a' flag in macOS opens the app by name
        subprocess.run(["open", "-a", app_name], check=True)
        return f"Successfully launched {app_name}."
    except subprocess.CalledProcessError:
        return f"Could not find or open the application '{app_name}'."
    except Exception as e:
        return f"System Error: {str(e)}"

def web_research(query: str) -> str:
    """Performs a live DuckDuckGo search and returns a summary."""
    try:
        from duckduckgo_search import DDGS
        results = DDGS().text(query, max_results=3)
        if not results:
            return f"No results found on the web for '{query}'."
            
        summary = "\n".join([f"- {res['title']}: {res['body']}" for res in results])
        return f"Here is what I found on the web for '{query}':\n{summary}"
    except Exception as e:
        return f"Search engine connection failed: {str(e)}"

def run_terminal(command: str) -> str:
    """Executes background bash commands (Guardian Safety Filter needed here eventually)."""
    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=10)
        if result.returncode == 0:
            return f"Terminal Output:\n{result.stdout.strip()}"
        else:
            return f"Terminal Error:\n{result.stderr.strip()}"
    except Exception as e:
        return f"Failed to execute command: {str(e)}"

def create_presentation(topic: str) -> str:
    """Generates a PowerPoint and opens it instantly."""
    try:
        from pptx import Presentation
        prs = Presentation()
        # Create a simple title slide
        title_slide_layout = prs.slide_layouts[0]
        slide = prs.slides.add_slide(title_slide_layout)
        title = slide.shapes.title
        subtitle = slide.placeholders[1]
        
        title.text = topic
        subtitle.text = "Autonomously generated by Kira OS"
        
        # Save to desktop
        filename = f"{topic.replace(' ', '_')}.pptx"
        filepath = os.path.expanduser(f"~/Desktop/{filename}")
        prs.save(filepath)
        
        # Open the file automatically
        subprocess.run(["open", filepath])
        return f"Created presentation '{filename}' and saved it to your Desktop."
    except Exception as e:
        return f"Failed to build presentation: {str(e)}"

def create_word_doc(filename: str, content: str) -> str:
    """Generates a Word Document and opens it."""
    try:
        from docx import Document
        doc = Document()
        doc.add_heading(filename, 0)
        doc.add_paragraph(content)
        
        if not filename.endswith('.docx'):
            filename += '.docx'
            
        filepath = os.path.expanduser(f"~/Desktop/{filename}")
        doc.save(filepath)
        subprocess.run(["open", filepath])
        
        return f"Wrote the document '{filename}' and saved it to the Desktop."
    except Exception as e:
        return f"Failed to write document: {str(e)}"

def run_virus_scan() -> str:
    """Mock security scan of the Downloads folder."""
    try:
        downloads_path = os.path.expanduser("~/Downloads")
        files = os.listdir(downloads_path)[:10] # Check recent files
        return f"Security scan complete. Verified {len(files)} recent files in Downloads. System is clean."
    except Exception as e:
        return f"Scan failed to initiate: {str(e)}"
