import chromadb

# This creates a local database folder inside your Kira_OS folder.
# It's where Kira stores everything she learns about your projects.
client = chromadb.PersistentClient(path="./kira_memory_db")
collection = client.get_or_create_collection(name="project_lore")

def remember_project(project_name, code_snippet):
    """Call this function to 'teach' Kira about a specific project."""
    collection.add(
        documents=[code_snippet],
        metadatas=[{"source": project_name}],
        ids=[f"{project_name}_data"]
    )
    print(f"Kira: 'I've tucked the logic for {project_name} into my memory, Sai!'")

def recall_lore(query):
    """Kira uses this to search her past knowledge before answering you."""
    results = collection.query(query_texts=[query], n_results=1)
    if results['documents'] and len(results['documents'][0]) > 0:
        return results['documents'][0][0]
    return "No relevant past project data found."