#!/bin/zsh
cd "$(dirname "$0")"
if [ -d "venv" ]; then
  source venv/bin/activate
fi
python3 interface.py
