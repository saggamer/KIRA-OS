import speech_recognition as sr

def kira_listen():
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        print("\n[Kira is listening...]")
        recognizer.adjust_for_ambient_noise(source, duration=0.5)
        try:
            # Waits 8 seconds to start, records up to 20 seconds
            audio = recognizer.listen(source, timeout=8, phrase_time_limit=20)
            print("[Processing...]")
            text = recognizer.recognize_google(audio)
            print(f"You: {text}")
            return text
        except sr.WaitTimeoutError:
            return None
        except sr.UnknownValueError:
            print("[Kira didn't catch that]")
            return None
        except sr.RequestError as e:
            print(f"[Network Error]: {e}")
            return None

if __name__ == "__main__":
    result = kira_listen()
    if result:
        print(f"Heard: '{result}'")