# Place Orchestrator V1 Here

Download Orchestrator V1 from:

https://huggingface.co/saggamer/Orchestrator_V1

Put the model files in this folder before launching KIRA OS.
