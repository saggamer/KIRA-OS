#!/bin/zsh
cd "$(dirname "$0")/kira_os_site"
python3 -m http.server 8777
