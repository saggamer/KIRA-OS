import os
import re
import json
import threading
import time

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
VOICE_TEMP_DIR = os.path.join(BASE_DIR, "kira_voice_tmp")
try:
    os.makedirs(VOICE_TEMP_DIR, exist_ok=True)
    os.environ["TMPDIR"] = VOICE_TEMP_DIR
    os.environ["TEMP"] = VOICE_TEMP_DIR
    os.environ["TMP"] = VOICE_TEMP_DIR
except Exception:
    pass

_voice_module = None
_listen_module = None
VOICE_READY = False
LISTEN_READY = False
STTS_TERMINAL_LOG_PATH = os.path.join(VOICE_TEMP_DIR, "stts_terminal.log")
STTS_EVENT_LOG_PATH = os.path.join(VOICE_TEMP_DIR, "stts_events.jsonl")
STTS_SILENT_TEST = os.environ.get("KIRA_STTS_SILENT_TEST", "1").strip().lower() not in {"0", "false", "no", "off"}
_stts_terminal_started = False
_stts_log_lock = threading.Lock()


def _stts_label():
    return time.strftime("%Y-%m-%d %H:%M:%S")


def _stts_text(value, limit=6000):
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if len(text) > limit:
        return text[:limit] + "... [truncated]"
    return text


def _write_stts_event(kind, text="", extra=None):
    event = {
        "time": time.time(),
        "label": _stts_label(),
        "kind": str(kind or "EVENT").upper(),
        "text": _stts_text(text),
        "extra": extra or {}
    }

    try:
        os.makedirs(VOICE_TEMP_DIR, exist_ok=True)
        with _stts_log_lock:
            with open(STTS_EVENT_LOG_PATH, "a", encoding="utf-8") as f:
                f.write(json.dumps(event, ensure_ascii=False) + "\n")

            with open(STTS_TERMINAL_LOG_PATH, "a", encoding="utf-8") as f:
                f.write(f"[{event['label']}] {event['kind']}: {event['text']}\n")

        if os.environ.get("KIRA_STTS_PRINT", "").strip().lower() in {"1", "true", "yes", "on"}:
            print(f"[KIRA STTS] {event['kind']}: {event['text']}")
    except Exception as e:
        print(f"[!] STTS terminal log failed: {e}")

    return event


def ensure_stts_terminal():
    global _stts_terminal_started
    if _stts_terminal_started:
        return True

    try:
        os.makedirs(VOICE_TEMP_DIR, exist_ok=True)
        _stts_terminal_started = True
        _write_stts_event(
            "SESSION",
            "Silent STT/TTS terminal route online. Voice input/output is being logged for testing.",
            {"route": "silent_terminal", "log": STTS_TERMINAL_LOG_PATH}
        )
        return True
    except Exception as e:
        print(f"[!] STTS terminal unavailable: {e}")
        return False


def set_stts_silent_test(enabled=True):
    global STTS_SILENT_TEST
    STTS_SILENT_TEST = bool(enabled)
    ensure_stts_terminal()
    _write_stts_event(
        "CONFIG",
        "Silent STT/TTS test mode " + ("enabled." if STTS_SILENT_TEST else "disabled."),
        {"silent_test": STTS_SILENT_TEST}
    )
    return STTS_SILENT_TEST


def ensure_voice_engine():
    global _voice_module, VOICE_READY
    if _voice_module is not None:
        return VOICE_READY

    try:
        import sounddevice as sd
        from kokoro_onnx import Kokoro
        import onnxruntime as ort

        base_dir = os.path.dirname(os.path.abspath(__file__))
        model_path = os.path.join(base_dir, "kokoro-v1.0.onnx")
        voices_path = os.path.join(base_dir, "voices-v1.0.bin")
        providers = []
        available = ort.get_available_providers()
        if "CoreMLExecutionProvider" in available:
            providers.append("CoreMLExecutionProvider")
        if "CUDAExecutionProvider" in available:
            providers.append("CUDAExecutionProvider")
        if "DmlExecutionProvider" in available:
            providers.append("DmlExecutionProvider")
        providers.append("CPUExecutionProvider")
        session = ort.InferenceSession(model_path, providers=providers)
        _voice_module = type("LazyKiraVoice", (), {})()
        _voice_module.sd = sd
        _voice_module.kira_voice = Kokoro.from_session(session, voices_path)
        VOICE_READY = True
        print("[Voice] Kira voice engine loaded.")
    except Exception as e:
        VOICE_READY = False
        print(f"[!] Voice engine unavailable: {e}")
    return VOICE_READY


def ensure_listen_engine():
    global _listen_module, LISTEN_READY
    if _listen_module is not None:
        return LISTEN_READY
    try:
        import importlib
        _listen_module = importlib.import_module("listen")
        LISTEN_READY = callable(getattr(_listen_module, "kira_listen", None))
    except Exception as e:
        _listen_module = None
        LISTEN_READY = False
        print(f"[!] listen.py unavailable: {e}")
    return LISTEN_READY


def kira_speak(text, silent=None):
    if not text:
        return

    if silent is None:
        silent = STTS_SILENT_TEST

    if silent:
        ensure_stts_terminal()
        _write_stts_event("TTS_OUT", text, {"route": "silent_terminal"})
        return

    if not ensure_voice_engine():
        ensure_stts_terminal()
        _write_stts_event("TTS_FALLBACK", text, {"route": "silent_terminal", "reason": "voice_engine_unavailable"})
        return

    try:
        _write_stts_event("TTS_PLAYBACK", text, {"route": "audio"})
        samples, sample_rate = _voice_module.kira_voice.create(text, voice="af_sarah", speed=1.1, lang="en-us")
        _voice_module.sd.play(samples, sample_rate)
        _voice_module.sd.wait()
    except Exception as e:
        print(f"Audio Generation Error: {e}")


def stop_speaking():
    try:
        if ensure_voice_engine() and getattr(_voice_module, "sd", None):
            _voice_module.sd.stop()
        return {"ok": True}
    except Exception as e:
        return {"ok": False, "error": str(e)}


class KiraVoiceMixin:
    def toggle_voice_mode(self, state):
        self.voice_mode_active = bool(state)
        if self.voice_mode_active:
            ensure_stts_terminal()
            self._record_stts_event(
                "VOICE_MODE",
                "Voice mode activated. Orchestrator V1 is routed through the STT/TTS bridge.",
                {"silent_test": STTS_SILENT_TEST}
            )
            if not STTS_SILENT_TEST:
                ensure_voice_engine()
        else:
            self._record_stts_event(
                "VOICE_MODE",
                "Voice mode deactivated.",
                {"silent_test": STTS_SILENT_TEST}
            )
        return "Voice mode " + ("activated" if self.voice_mode_active else "deactivated")

    def toggle_voice(self, state):
        return self.toggle_voice_mode(state)

    def get_voice_status(self):
        return {
            "voice_mode_active": self.voice_mode_active,
            "voice_ready": VOICE_READY,
            "listen_ready": LISTEN_READY,
            "voice_loaded": _voice_module is not None,
            "listen_loaded": _listen_module is not None,
            "stts_ready": True,
            "stts_silent_test": STTS_SILENT_TEST,
            "stts_route": "silent_terminal" if STTS_SILENT_TEST else "audio",
            "stts_terminal_log": STTS_TERMINAL_LOG_PATH,
            "stts_event_log": STTS_EVENT_LOG_PATH,
            "speech_output": "voice.py" if VOICE_READY else "lazy/offline",
            "python_listen_fallback": "listen.py" if LISTEN_READY else "lazy/offline",
            "temp_dir": VOICE_TEMP_DIR
        }

    def set_voice_test_mode(self, enabled=True):
        enabled = set_stts_silent_test(enabled)
        return self.get_voice_status() | {"status": "silent_test_enabled" if enabled else "audio_enabled"}

    def record_voice_input(self, text, source="browser"):
        return self._record_stts_event("STT_IN", text, {"source": source or "voice"})

    def _record_stts_event(self, kind, text="", extra=None):
        event = _write_stts_event(kind, text, extra)
        try:
            if hasattr(self, "response_queue"):
                self.response_queue.put({
                    "type": "voice_event",
                    "event": event.get("kind"),
                    "content": event.get("text", ""),
                    "extra": event.get("extra", {}),
                    "label": event.get("label", "")
                })
        except Exception:
            pass
        return event

    def listen_once(self):
        ensure_stts_terminal()
        self._record_stts_event("STT_LISTEN_START", "Listening once through the Python microphone fallback.")

        if not ensure_listen_engine():
            self._record_stts_event(
                "STT_ERROR",
                "Python listening fallback is offline. Use browser speech recognition or typed voice input.",
                {"source": "listen.py"}
            )
            return {
                "ok": False,
                "text": "",
                "error": "Python listening fallback is offline. Use the typed live prompt or browser speech recognition."
            }

        try:
            text = _listen_module.kira_listen()
            if text:
                self._record_stts_event("STT_IN", text, {"source": "listen.py"})
            else:
                self._record_stts_event("STT_EMPTY", "No speech was recognized.", {"source": "listen.py"})
            return {
                "ok": bool(text),
                "text": text or "",
                "error": "" if text else "I did not catch that."
            }
        except Exception as e:
            self._record_stts_event("STT_ERROR", str(e), {"source": "listen.py"})
            return {
                "ok": False,
                "text": "",
                "error": str(e)
            }

    def stop_voice(self):
        try:
            if _voice_module is None:
                return {"ok": True}
            sd = getattr(_voice_module, "sd", None)
            if sd and hasattr(sd, "stop"):
                sd.stop()
            return {"ok": True}
        except Exception as e:
            return {"ok": False, "error": str(e)}

    def _speak_if_voice_active(self, text):
        if self.voice_mode_active:
            self._trigger_voice(text)

    def _voice_clean(self, text):
        clean = self._strip_private_reasoning(text)
        clean = self._strip_agentic_blocks(clean)
        clean = re.sub(r"```.*?```", "I completed the command and have the result.", clean, flags=re.DOTALL)
        clean = re.sub(r"`([^`]+)`", r"\1", clean)
        return clean.strip()

    def _trigger_voice(self, text):
        clean_text = self._voice_clean(text)
        if not clean_text:
            return

        self._record_stts_event("TTS_QUEUE", clean_text, {"silent_test": STTS_SILENT_TEST})

        def _voice_worker():
            try:
                kira_speak(clean_text)
            except Exception as e:
                self._record_stts_event("TTS_ERROR", str(e), {"silent_test": STTS_SILENT_TEST})
                print(f"Voice playback failed: {e}")

        threading.Thread(target=_voice_worker, daemon=True).start()


if __name__ == "__main__":
    kira_speak("Hardware diagnostics complete. Universal voice module is online.")
