import webview
import threading
import queue
import gc
import os
import re
import subprocess
import traceback
import json
import time
import uuid
import shutil
import shlex
import sys
import types
from actions import KiraActionsMixin
from voice import KiraVoiceMixin

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

class KiraBrain(KiraActionsMixin, KiraVoiceMixin):
    def __init__(self):
        # DUAL BRAINS RESTORED
        self.app_root = BASE_DIR
        self.orch_path = os.path.join(self.app_root, "orchestrator_v1_fused")
        self.kira_path = os.path.join(self.app_root, "kira_v1_fused")
        if not os.path.exists(self.kira_path):
            self.kira_path = os.path.join(self.app_root, "kira_os_fused")

        self.agentic_workspace = os.path.join(self.app_root, "kira_agentic_workspace")
        self.agentic_logs_path = os.path.join(self.app_root, "kira_agentic_logs")
        self.chat_history_path = os.path.join(self.app_root, "kira_chat_history")
        self.mcp_workspace = os.path.join(self.app_root, "kira_mcp_connectors")
        self.architect_workspace = os.path.join(self.app_root, "kira_technical_architect")
        self.ide_bridge_path = os.path.join(self.architect_workspace, "ide_bridge")
        self.home_path = os.path.expanduser("~")
        self.computer_map_path = os.path.join(self.agentic_workspace, "computer_map")
        self.artifacts_index_path = os.path.join(self.agentic_workspace, "kira_artifacts_index.json")
        self.personalization_path = os.path.join(self.app_root, "kira_personalization_rag.json")
        self.scheduled_tasks_path = os.path.join(self.agentic_workspace, "kira_scheduled_tasks.json")
        self.execution_ledger_path = os.path.join(self.agentic_logs_path, "execution_ledger.jsonl")
        self.learned_pathways_path = os.path.join(self.architect_workspace, "learned_quick_pathways.json")
        self.slash_suggestions_path = os.path.join(self.architect_workspace, "slash_suggestions.json")
        self.screen_overlay_state_path = os.path.join(self.agentic_workspace, "screen_overlay_state.json")
        self.screen_overlay_process = None
        self.slash_suggestions_cache = []
        self.last_slash_suggestions_scan = 0
        self.slash_suggestions_refreshing = False
        self.ui_warmup_started = False
        self.ui_warmup_done = False
        self.ui_warmup_lock = threading.Lock()
        self.app_started_at = time.time()
        self.last_personalization_update = 0
        self.last_quick_pathway_update = 0
        self.agentic_step_timeout_seconds = 38
        self.agentic_max_steps = 2
        self.council_parallel_enabled = True
        self.council_confidence_threshold = 0.58
        self.council_fact_check_threshold = 0.58
        self.council_role_timeout_seconds = 18
        self.council_role_max_tokens = 760
        self.council_arbiter_max_tokens = 950

        os.makedirs(self.agentic_workspace, exist_ok=True)
        os.makedirs(self.agentic_logs_path, exist_ok=True)
        os.makedirs(self.chat_history_path, exist_ok=True)
        os.makedirs(self.mcp_workspace, exist_ok=True)
        os.makedirs(self.architect_workspace, exist_ok=True)
        os.makedirs(self.ide_bridge_path, exist_ok=True)

        self.mcp_config_targets = self._detect_mcp_config_targets()

        self.computer_roots = {
            "kira_project": self.app_root,
            "agentic_workspace": self.agentic_workspace,
            "mcp_workspace": self.mcp_workspace,
            "technical_architect": self.architect_workspace,
            "ide_bridge": self.ide_bridge_path,
            "desktop": os.path.join(self.home_path, "Desktop"),
            "downloads": os.path.join(self.home_path, "Downloads"),
            "documents": os.path.join(self.home_path, "Documents"),
            "applications": "/Applications",
            "user_applications": os.path.join(self.home_path, "Applications"),
        }
        self.readable_roots = [
            path for path in self.computer_roots.values()
            if path and os.path.exists(path)
        ]
        self.sensitive_path_markers = [
            "/.ssh", "/.gnupg", "/.aws", "/.config/gh", "/.docker",
            "/Library/Keychains", "/Library/Messages", "/Library/Mail",
            "/Library/Cookies", "/Library/Safari", "/Library/Containers",
            "/Library/Application Support/AddressBook",
            ".env", "id_rsa", "id_ed25519", "keychain", "token", "secret"
        ]
        self.last_agentic_intent = None
        self.last_agentic_result = None
        self.execution_lock = threading.Lock()
        self.active_execution_ledger_id = ""
        self.execution_ledgers = {}
        self.scheduled_tasks_lock = threading.Lock()
        self.scheduled_tasks = self._load_scheduled_tasks()
        self.last_artifacts = self._load_artifact_index(validate=False)
        self.last_artifact_path = self.last_artifacts[0]["path"] if self.last_artifacts else ""
        self.active_chat_id = ""
        self.slash_suggestions_cache = self._base_slash_suggestions()
        self.last_slash_suggestions_scan = time.time()
        if os.path.exists(self.personalization_path):
            try:
                self.last_personalization_update = os.path.getmtime(self.personalization_path)
            except Exception:
                self.last_personalization_update = 0
        else:
            self._save_personalization_rag(self._default_personalization_rag())

        if not os.path.exists(self.orch_path):
            print(f"[!] Warning: Orchestrator not found at {self.orch_path}")
        if not os.path.exists(self.kira_path):
            print(f"[!] Warning: Kira V1 not found at {self.kira_path}")

        self.active_model = None
        self.active_tokenizer = None
        self.current_brain = None
        self.model_worker_process = None
        self.model_worker_response_queue = queue.Queue()
        self.model_worker_pending_responses = {}
        self.model_worker_stderr_lines = []
        self.model_worker_io_lock = threading.Lock()
        self.model_worker_request_counter = 0
        self.model_worker_load_timeout = int(os.environ.get("KIRA_MODEL_LOAD_TIMEOUT", "180"))
        self.kira_model_worker_load_timeout = int(os.environ.get("KIRA_V1_MODEL_LOAD_TIMEOUT", "60"))
        self.model_worker_generation_timeout = int(os.environ.get("KIRA_MODEL_GENERATION_TIMEOUT", "55"))
        self.model_worker_last_error = ""
        self.session_memory = []

        self.task_queue = queue.Queue()
        self.response_queue = queue.Queue()
        self.is_running = True
        self.voice_mode_active = False

        self.pending_permissions = {}
        self.permission_lock = threading.Lock()
        self.permission_counter = 0

        self.safe_shell_commands = {
            "pwd", "ls", "cat", "head", "tail", "find", "rg", "grep",
            "wc", "du", "df", "ps", "top", "vm_stat", "sort", "awk",
            "sed", "cut", "uniq", "whoami", "date", "uname", "which",
            "mdfind", "mdls", "stat", "file", "id", "groups", "scutil",
            "sw_vers", "system_profiler", "pmset"
        }

        self.safe_git_commands = {
            "status", "diff", "log", "show", "branch", "rev-parse",
            "ls-files", "grep", "remote", "describe"
        }

        self.worker_thread = threading.Thread(target=self._worker_loop, daemon=True)
        self.worker_thread.start()
        self.personalization_thread = threading.Thread(target=self._personalization_loop, daemon=True)
        self.personalization_thread.start()
        self.scheduler_thread = threading.Thread(target=self._scheduled_task_loop, daemon=True)
        self.scheduler_thread.start()

        print("[System] KIRA OS Engine Online. Orchestrator V1 active. Agentic planner ready.")

    def _detect_mcp_config_targets(self):
        return {
            "cursor_project": os.path.join(self.app_root, ".cursor", "mcp.json"),
            "cursor_user": os.path.join(self.home_path, ".cursor", "mcp.json"),
            "claude_desktop": os.path.join(
                self.home_path,
                "Library",
                "Application Support",
                "Claude",
                "claude_desktop_config.json"
            ),
            "vscode_project_candidate": os.path.join(self.app_root, ".vscode", "mcp.json"),
            "kira_drafts": self.mcp_workspace
        }

    def _write_os_access_manifest(self):
        try:
            manifest = {
                "name": "KIRA OS Accessible Computer Map",
                "mode": "read-mostly safety workspace",
                "readable_roots": self.computer_roots,
                "agentic_workspace": self.agentic_workspace,
                "architect_workspace": self.architect_workspace,
                "ide_bridge": self.ide_bridge_path,
                "mcp_config_targets": self.mcp_config_targets,
                "policy": {
                    "seatbelt": "macOS sandbox-exec/Seatbelt guards command, project, Python, search, and exact approved mutation workers when available",
                    "auto_allowed": [
                        "list readable roots",
                        "read non-sensitive files in readable roots",
                        "search non-sensitive files in readable roots",
                        "run safe read-only diagnostics",
                        "open apps/files/folders/URLs",
                        "generate PDFs/PPTX inside agentic workspace",
                    "discover IDE/project context",
                    "create Codex-style IDE bridge state files",
                    "draft MCP connector configs inside MCP workspace",
                    "inspect app integrations and Blender context",
                    "fetch web pages with a headless browser when available",
                        "run read-only malware signal scans inside readable roots",
                        "run read-only optimisation scans before recommending cleanup",
                        "scan safe app/file/IDE/MCP surfaces for slash suggestions",
                        "index readable projects"
                    ],
                    "permission_required": [
                        "write/edit/delete/move",
                        "AppleScript UI automation",
                        "Python execution",
                        "installs/downloads",
                        "apply MCP configs to Cursor/Claude/global locations",
                        "run project commands",
                        "broad scans outside readable roots",
                        "sensitive/private folders"
                    ]
                }
            }
            manifest_path = os.path.join(self.agentic_workspace, "kira_os_accessible_map.json")
            with open(manifest_path, "w", encoding="utf-8") as f:
                json.dump(manifest, f, indent=2, ensure_ascii=False)

            map_dir = self.computer_map_path
            os.makedirs(map_dir, exist_ok=True)

            readme_path = os.path.join(map_dir, "README.txt")
            with open(readme_path, "w", encoding="utf-8") as f:
                f.write(
                    "KIRA OS computer_map\n"
                    "These entries are read-mostly shortcuts for Orchestrator V1.\n"
                    "Safe read/list/search is allowed through the backend guard rails.\n"
                    "IDE context, project indexing, and MCP drafting are available through bridge tools.\n"
                    "Opening apps/files/folders/URLs is direct navigation.\n"
                    "Writes, deletes, Python, AppleScript, MCP apply, installs, and risky shell need permission.\n"
                )

            architect_path = os.path.join(self.architect_workspace, "architect_surface.json")
            with open(architect_path, "w", encoding="utf-8") as f:
                json.dump({
                    "role": "technical architect surface for Orchestrator V1",
                    "tools": [
                        "IDE_CONTEXT", "PROJECT_INDEX", "MCP_DISCOVER",
                        "MCP_BOOTSTRAP", "MCP_DRAFT", "MCP_APPLY",
                        "IDE_OPEN", "PROJECT_COMMAND", "APP_INTEGRATION",
                        "BLENDER_CONTEXT", "WEB_HEADLESS"
                    ],
                    "mcp_targets": self.mcp_config_targets,
                    "ide_bridge_path": self.ide_bridge_path
                }, f, indent=2, ensure_ascii=False)

            for label, target in self.computer_roots.items():
                if not target or not os.path.exists(target):
                    continue

                link_path = os.path.join(map_dir, label)
                try:
                    if os.path.islink(link_path):
                        current = os.readlink(link_path)
                        if current != target:
                            os.unlink(link_path)
                            os.symlink(target, link_path)
                    elif not os.path.exists(link_path):
                        os.symlink(target, link_path)
                except Exception:
                    marker_path = link_path + ".path.txt"
                    with open(marker_path, "w", encoding="utf-8") as f:
                        f.write(target)
        except Exception:
            pass

    def warm_after_ui_ready(self):
        with self.ui_warmup_lock:
            if self.ui_warmup_started:
                return {"status": "already_started", "done": self.ui_warmup_done}

            self.ui_warmup_started = True

        threading.Thread(target=self._deferred_ui_warmup, daemon=True).start()
        return {"status": "started", "done": False}

    def _deferred_ui_warmup(self):
        try:
            self.response_queue.put({"type": "status", "content": "Preparing KIRA pathways..."})
            self.last_artifacts = self._load_artifact_index(validate=True)
            self.last_artifact_path = self.last_artifacts[0]["path"] if self.last_artifacts else ""
            self._write_os_access_manifest()
            self._refresh_slash_suggestions(force=False)
            self._maybe_update_personalization_rag(force=False)
            self.ui_warmup_done = True
            self.response_queue.put({"type": "status", "content": "System Ready"})
        except Exception as e:
            self.response_queue.put({"type": "error", "content": f"Warmup Error: {e}"})

    def _evict_and_load(self, target_brain):
        target_brain = str(target_brain or "orchestrator").lower()
        model_path = self.orch_path if target_brain == "orchestrator" else self.kira_path
        if not os.path.exists(model_path):
            raise FileNotFoundError(f"{target_brain.capitalize()} model folder not found: {model_path}")

        if (
            self.current_brain == target_brain
            and self.model_worker_process is not None
            and self.model_worker_process.poll() is None
            and self.active_model is not None
            and self.active_tokenizer is not None
        ):
            return

        self.response_queue.put({
            "type": "status",
            "content": f"Starting isolated {target_brain.capitalize()} model worker..."
        })

        self._stop_model_worker()
        self.active_model = None
        self.active_tokenizer = None
        self.current_brain = None
        gc.collect()

        try:
            self._start_model_worker(target_brain)
            self._model_worker_request({
                "type": "load",
                "brain": target_brain,
                "model_path": model_path
            }, timeout=self.kira_model_worker_load_timeout if target_brain == "kira" else self.model_worker_load_timeout)
            self.current_brain = target_brain
            # Proxy markers only. The real MLX objects live in the worker process.
            self.active_model = {"isolated_worker": True, "brain": target_brain}
            self.active_tokenizer = {"isolated_worker": True, "brain": target_brain}
            self.response_queue.put({
                "type": "status",
                "content": f"{target_brain.capitalize()} model worker is ready."
            })
        except Exception as e:
            self._stop_model_worker()
            self.active_model = None
            self.active_tokenizer = None
            self.current_brain = None
            raise RuntimeError(f"Model worker failed for {target_brain}: {e}") from e

    def _start_model_worker(self, target_brain):
        env = os.environ.copy()
        env.setdefault("PYTHONUNBUFFERED", "1")
        env.setdefault("TOKENIZERS_PARALLELISM", "false")
        self.model_worker_response_queue = queue.Queue()
        self.model_worker_pending_responses = {}
        self.model_worker_stderr_lines = []
        self.model_worker_last_error = ""

        proc = subprocess.Popen(
            [sys.executable, "-u", "-c", self._model_worker_code()],
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            cwd=self.app_root,
            env=env,
            text=True,
            bufsize=1
        )
        self.model_worker_process = proc

        threading.Thread(
            target=self._model_worker_stdout_reader,
            args=(proc,),
            name=f"kira-{target_brain}-model-stdout",
            daemon=True
        ).start()
        threading.Thread(
            target=self._model_worker_stderr_reader,
            args=(proc,),
            name=f"kira-{target_brain}-model-stderr",
            daemon=True
        ).start()

    def _model_worker_stdout_reader(self, proc):
        try:
            for line in iter(proc.stdout.readline, ""):
                line = line.strip()
                if not line:
                    continue
                try:
                    payload = json.loads(line)
                except Exception:
                    payload = {
                        "id": "",
                        "ok": False,
                        "error": "Non-JSON model worker output",
                        "raw": line[:2000]
                    }
                self.model_worker_response_queue.put(payload)
        except Exception as e:
            self.model_worker_response_queue.put({
                "id": "",
                "ok": False,
                "error": f"Model worker stdout reader failed: {e}"
            })

    def _model_worker_stderr_reader(self, proc):
        try:
            for line in iter(proc.stderr.readline, ""):
                line = line.rstrip()
                if not line:
                    continue
                self.model_worker_stderr_lines.append(line)
                if len(self.model_worker_stderr_lines) > 160:
                    self.model_worker_stderr_lines = self.model_worker_stderr_lines[-120:]
        except Exception:
            pass

    def _model_worker_stderr_tail(self, limit=24):
        return "\n".join(self.model_worker_stderr_lines[-int(limit):]).strip()

    def _stop_model_worker(self):
        proc = getattr(self, "model_worker_process", None)
        self.model_worker_process = None
        self.model_worker_pending_responses = {}
        if proc is None:
            return
        try:
            if proc.poll() is None and proc.stdin:
                proc.stdin.write(json.dumps({"type": "shutdown"}) + "\n")
                proc.stdin.flush()
        except Exception:
            pass
        try:
            if proc.poll() is None:
                proc.terminate()
                proc.wait(timeout=2)
        except Exception:
            try:
                proc.kill()
            except Exception:
                pass

    def _mark_model_worker_dead(self, reason):
        tail = self._model_worker_stderr_tail()
        self.model_worker_last_error = (str(reason or "model worker stopped") + ("\n" + tail if tail else "")).strip()
        self._stop_model_worker()
        self.active_model = None
        self.active_tokenizer = None
        self.current_brain = None

    def _model_worker_request(self, payload, timeout=60):
        timeout = max(1, int(timeout or 60))
        with self.model_worker_io_lock:
            proc = self.model_worker_process
            if proc is None or proc.poll() is not None:
                code = None if proc is None else proc.returncode
                raise RuntimeError(f"Model worker is not running (exit={code}). {self._model_worker_stderr_tail()}")

            self.model_worker_request_counter += 1
            request_id = f"mw_{int(time.time() * 1000)}_{self.model_worker_request_counter}"
            request = dict(payload or {})
            request["id"] = request_id

            try:
                proc.stdin.write(json.dumps(request, ensure_ascii=False) + "\n")
                proc.stdin.flush()
            except Exception as e:
                self._mark_model_worker_dead(f"Could not write to model worker: {e}")
                raise RuntimeError(self.model_worker_last_error) from e

            deadline = time.time() + timeout
            while True:
                if request_id in self.model_worker_pending_responses:
                    response = self.model_worker_pending_responses.pop(request_id)
                    break

                if proc.poll() is not None:
                    reason = f"Model worker crashed with exit code {proc.returncode}."
                    self._mark_model_worker_dead(reason)
                    raise RuntimeError(self.model_worker_last_error or reason)

                remaining = deadline - time.time()
                if remaining <= 0:
                    reason = f"Model worker timed out after {timeout}s during {request.get('type', 'request')}."
                    self._mark_model_worker_dead(reason)
                    raise RuntimeError(self.model_worker_last_error or reason)

                try:
                    response = self.model_worker_response_queue.get(timeout=min(0.1, remaining))
                except queue.Empty:
                    continue

                response_id = response.get("id", "")
                if response_id == request_id:
                    break
                if response_id:
                    self.model_worker_pending_responses[response_id] = response

            if not response.get("ok", False):
                error = response.get("error") or response.get("trace") or "Unknown model worker error"
                self.model_worker_last_error = str(error)
                raise RuntimeError(str(error))

            if "content" in response:
                return response.get("content") or ""
            return response

    def _model_worker_code(self):
        return 'import json\nimport os\nimport sys\nimport traceback\nimport types\n\ndef install_fast_transformers_shim():\n    existing = sys.modules.get("transformers")\n    if existing is not None:\n        return\n    try:\n        from tokenizers import Tokenizer\n    except Exception:\n        return\n\n    class KiraFastTokenizer:\n        def __init__(self, model_path, **kwargs):\n            self.model_path = os.fspath(model_path)\n            tokenizer_path = os.path.join(self.model_path, "tokenizer.json")\n            config_path = os.path.join(self.model_path, "tokenizer_config.json")\n            chat_template_path = os.path.join(self.model_path, "chat_template.jinja")\n            self._tokenizer = Tokenizer.from_file(tokenizer_path)\n            self.init_kwargs = {}\n            if os.path.exists(config_path):\n                try:\n                    with open(config_path, "r", encoding="utf-8") as f:\n                        self.init_kwargs = json.load(f)\n                except Exception:\n                    self.init_kwargs = {}\n            self.chat_template = self.init_kwargs.get("chat_template")\n            if not self.chat_template and os.path.exists(chat_template_path):\n                try:\n                    with open(chat_template_path, "r", encoding="utf-8") as f:\n                        self.chat_template = f.read()\n                except Exception:\n                    self.chat_template = None\n            self.name_or_path = self.model_path\n            try:\n                self.model_max_length = int(self.init_kwargs.get("model_max_length", 8192) or 8192)\n            except Exception:\n                self.model_max_length = 8192\n            self.bos_token = self._token_text(self.init_kwargs.get("bos_token")) or "<bos>"\n            self.eos_token = self._token_text(self.init_kwargs.get("eos_token")) or "<eos>"\n            self.unk_token = self._token_text(self.init_kwargs.get("unk_token")) or "<unk>"\n            self.pad_token = self._token_text(self.init_kwargs.get("pad_token")) or self.eos_token\n            self.bos_token_id = self.convert_tokens_to_ids(self.bos_token)\n            self.eos_token_id = self.convert_tokens_to_ids(self.eos_token)\n            self.pad_token_id = self.convert_tokens_to_ids(self.pad_token)\n            self.vocab_size = self._tokenizer.get_vocab_size()\n            self.vocab = self._tokenizer.get_vocab()\n\n        def _token_text(self, token):\n            if isinstance(token, dict):\n                return token.get("content") or token.get("token")\n            if token is None:\n                return None\n            return str(token)\n\n        def encode(self, text, add_special_tokens=True, **kwargs):\n            return self._tokenizer.encode(str(text), add_special_tokens=bool(add_special_tokens)).ids\n\n        def decode(self, tokens, skip_special_tokens=False, **kwargs):\n            if tokens is None:\n                return ""\n            if hasattr(tokens, "tolist"):\n                tokens = tokens.tolist()\n            if isinstance(tokens, int):\n                tokens = [tokens]\n            return self._tokenizer.decode([int(t) for t in tokens], skip_special_tokens=bool(skip_special_tokens))\n\n        def batch_decode(self, batch, skip_special_tokens=False, **kwargs):\n            return [self.decode(tokens, skip_special_tokens=skip_special_tokens, **kwargs) for tokens in batch]\n\n        def convert_tokens_to_ids(self, token):\n            token_id = self._tokenizer.token_to_id(str(token))\n            return token_id if token_id is not None else 0\n\n        def get_vocab(self):\n            return self.vocab\n\n        def apply_chat_template(self, messages, tokenize=False, add_generation_prompt=True, return_dict=False, **kwargs):\n            rendered = []\n            for message in messages or []:\n                role = str(message.get("role", "user")).lower()\n                role = "model" if role in ("assistant", "model") else "user"\n                rendered.append("<|turn>" + role + "\\n" + str(message.get("content", "")) + "<turn|>\\n")\n            if add_generation_prompt:\n                rendered.append("<|turn>model\\n")\n            text = "".join(rendered)\n            if tokenize:\n                ids = self.encode(text, add_special_tokens=False)\n                if return_dict:\n                    return {"input_ids": ids}\n                return ids\n            return text\n\n        @classmethod\n        def from_pretrained(cls, model_path, **kwargs):\n            return cls(model_path, **kwargs)\n\n        def __call__(self, text, return_tensors=None, add_special_tokens=True, **kwargs):\n            ids = self.encode(text, add_special_tokens=add_special_tokens)\n            if return_tensors == "np":\n                import numpy as np\n                return {"input_ids": np.array([ids], dtype=np.int64)}\n            return {"input_ids": ids}\n\n    class AutoTokenizer:\n        _registry = []\n\n        @classmethod\n        def register(cls, *args, **kwargs):\n            cls._registry.append({"args": [str(a) for a in args], "kwargs": {str(k): str(v) for k, v in kwargs.items()}})\n            return None\n\n        @classmethod\n        def from_pretrained(cls, model_path, **kwargs):\n            return KiraFastTokenizer(model_path, **kwargs)\n\n    shim = types.ModuleType("transformers")\n    shim.AutoTokenizer = AutoTokenizer\n    shim.PreTrainedTokenizer = KiraFastTokenizer\n    shim.PreTrainedTokenizerFast = KiraFastTokenizer\n    shim.__version__ = "kira-fast-shim"\n    shim._kira_fast_tokenizer_shim = True\n    sys.modules["transformers"] = shim\n\nmodel = None\ntokenizer = None\ncurrent_brain = None\n\ndef send(payload):\n    print(json.dumps(payload, ensure_ascii=False), flush=True)\n\nfor raw_line in sys.stdin:\n    raw_line = raw_line.strip()\n    if not raw_line:\n        continue\n    request_id = ""\n    try:\n        request = json.loads(raw_line)\n        request_id = request.get("id", "")\n        request_type = request.get("type", "")\n        if request_type == "shutdown":\n            send({"id": request_id, "ok": True, "shutdown": True})\n            break\n        if request_type == "load":\n            install_fast_transformers_shim()\n            try:\n                import mlx.core as mx\n                try:\n                    mx.clear_cache()\n                except Exception:\n                    pass\n            except Exception:\n                pass\n            from mlx_lm import load\n            model_path = request["model_path"]\n            try:\n                model, tokenizer = load(model_path, lazy=True)\n            except TypeError:\n                model, tokenizer = load(model_path)\n            current_brain = request.get("brain", "")\n            send({"id": request_id, "ok": True, "loaded": True, "brain": current_brain})\n            continue\n        if request_type == "generate":\n            if model is None or tokenizer is None:\n                raise RuntimeError("Model is not loaded in worker.")\n            from mlx_lm import generate\n            prompt = request.get("prompt", "")\n            max_tokens = int(request.get("max_tokens", 1200))\n            temperature = float(request.get("temperature", 0.35))\n            try:\n                from mlx_lm.sample_utils import make_sampler\n                try:\n                    sampler = make_sampler(temperature=temperature)\n                except TypeError:\n                    sampler = make_sampler(temp=temperature)\n                content = generate(model, tokenizer, prompt=prompt, max_tokens=max_tokens, sampler=sampler, verbose=False)\n            except Exception:\n                content = generate(model, tokenizer, prompt=prompt, max_tokens=max_tokens, temperature=temperature, verbose=False)\n            send({"id": request_id, "ok": True, "content": content})\n            continue\n        raise RuntimeError("Unknown model worker request type: " + str(request_type))\n    except Exception as e:\n        send({"id": request_id, "ok": False, "error": str(e), "trace": traceback.format_exc()})\n'

    def _load_model_pair(self, model_path):
        raise RuntimeError(
            "Direct MLX loading is disabled in the UI process. "
            "Use the isolated model worker instead."
        )

    def _materialize_model_in_vram(self, model):
        return

    def _install_fast_transformers_shim(self):
        existing = sys.modules.get("transformers")
        if existing is not None and getattr(existing, "_kira_fast_tokenizer_shim", False):
            return
        if existing is not None:
            return

        try:
            from tokenizers import Tokenizer
        except Exception:
            return

        class KiraFastTokenizer:
            def __init__(self, model_path, **kwargs):
                self.model_path = os.fspath(model_path)
                tokenizer_path = os.path.join(self.model_path, "tokenizer.json")
                config_path = os.path.join(self.model_path, "tokenizer_config.json")
                chat_template_path = os.path.join(self.model_path, "chat_template.jinja")

                self._tokenizer = Tokenizer.from_file(tokenizer_path)
                self.init_kwargs = {}
                if os.path.exists(config_path):
                    try:
                        with open(config_path, "r", encoding="utf-8") as f:
                            self.init_kwargs = json.load(f)
                    except Exception:
                        self.init_kwargs = {}

                self.chat_template = self.init_kwargs.get("chat_template")
                if not self.chat_template and os.path.exists(chat_template_path):
                    try:
                        with open(chat_template_path, "r", encoding="utf-8") as f:
                            self.chat_template = f.read()
                    except Exception:
                        self.chat_template = None

                self.bos_token = self._token_text(self.init_kwargs.get("bos_token")) or "<bos>"
                self.eos_token = self._token_text(self.init_kwargs.get("eos_token")) or "<eos>"
                self.unk_token = self._token_text(self.init_kwargs.get("unk_token")) or "<unk>"
                self.pad_token = self._token_text(self.init_kwargs.get("pad_token")) or self.eos_token
                self.bos_token_id = self.convert_tokens_to_ids(self.bos_token)
                self.eos_token_id = self.convert_tokens_to_ids(self.eos_token)
                self.pad_token_id = self.convert_tokens_to_ids(self.pad_token)
                self.vocab_size = self._tokenizer.get_vocab_size()
                self.vocab = self._tokenizer.get_vocab()

            def _token_text(self, token):
                if isinstance(token, dict):
                    return token.get("content") or token.get("token")
                if token is None:
                    return None
                return str(token)

            def encode(self, text, add_special_tokens=True, **kwargs):
                return self._tokenizer.encode(
                    str(text),
                    add_special_tokens=bool(add_special_tokens)
                ).ids

            def decode(self, tokens, skip_special_tokens=False, **kwargs):
                if tokens is None:
                    return ""
                if hasattr(tokens, "tolist"):
                    tokens = tokens.tolist()
                if isinstance(tokens, int):
                    tokens = [tokens]
                return self._tokenizer.decode(
                    [int(token) for token in tokens],
                    skip_special_tokens=bool(skip_special_tokens)
                )

            def batch_decode(self, batch, skip_special_tokens=False, **kwargs):
                return [
                    self.decode(tokens, skip_special_tokens=skip_special_tokens, **kwargs)
                    for tokens in batch
                ]

            def convert_tokens_to_ids(self, token):
                token_id = self._tokenizer.token_to_id(str(token))
                return token_id if token_id is not None else 0

            def get_vocab(self):
                return self.vocab

            def apply_chat_template(
                self,
                messages,
                tokenize=False,
                add_generation_prompt=True,
                return_dict=False,
                **kwargs
            ):
                rendered = []
                for message in messages or []:
                    role = str(message.get("role", "user")).lower()
                    if role in ["assistant", "model"]:
                        role = "model"
                    else:
                        role = "user"
                    rendered.append(
                        "<|turn>"
                        + role
                        + "\n"
                        + str(message.get("content", ""))
                        + "<turn|>\n"
                    )

                if add_generation_prompt:
                    rendered.append("<|turn>model\n")

                text = "".join(rendered)
                if not tokenize:
                    return text
                tokens = self.encode(text, add_special_tokens=False)
                if return_dict:
                    return {"input_ids": tokens}
                return tokens

        class KiraAutoTokenizer:
            @classmethod
            def from_pretrained(cls, model_path, **kwargs):
                return KiraFastTokenizer(model_path, **kwargs)

            @classmethod
            def register(cls, *args, **kwargs):
                return None

        transformers_shim = types.ModuleType("transformers")
        transformers_shim.AutoTokenizer = KiraAutoTokenizer
        transformers_shim.PreTrainedTokenizer = KiraFastTokenizer
        transformers_shim.PreTrainedTokenizerFast = KiraFastTokenizer
        transformers_shim.__version__ = "kira-fast-shim"
        transformers_shim._kira_fast_tokenizer_shim = True
        sys.modules["transformers"] = transformers_shim

    def _is_simple_chat_prompt(self, raw_prompt, mode, needs_agentic_pathway):
        if needs_agentic_pathway:
            return False
        if str(mode or "").lower() in ["agent", "agentic", "agentic_rag", "agentic task chat"]:
            return False

        text = re.sub(r"[^a-z0-9\s'?!.]", " ", str(raw_prompt or "").lower())
        text = re.sub(r"\s+", " ", text).strip()
        if not text or text.startswith("/"):
            return False

        words = text.split()
        if len(words) > 12:
            return False

        simple_exact = {
            "hi", "hello", "hey", "yo", "hiya", "sup", "test",
            "are you there", "you there", "can you hear me",
            "good morning", "good afternoon", "good evening"
        }
        simple_prefixes = (
            "hi ", "hello ", "hey ", "yo ", "good morning",
            "good afternoon", "good evening"
        )
        return text in simple_exact or text.startswith(simple_prefixes)

    def _fast_simple_chat_response(self, raw_prompt, target_brain):
        if target_brain == "kira":
            return "Hi, I’m Kira V1. I’m ready."

        return (
            "Hi, I’m here. Orchestrator V1 is ready for normal chat, file inspection, "
            "web/search work, app control, and agentic tasks when you ask for them."
        )

    def _model_timeout_response(self, raw_prompt, target_brain, agentic_mode_requested=False):
        if agentic_mode_requested:
            return (
                f"{target_brain.capitalize()} V1 did not return a verified answer in time. "
                "I did not complete, open, delete, move, or generate anything. Please try again, or narrow the request."
            )

        return (
            f"{target_brain.capitalize()} V1 did not answer in time. "
            "The app stayed responsive, but the local model call timed out before producing usable text."
        )

    def _is_effectively_empty_model_text(self, text):
        cleaned = self._strip_agentic_blocks(self._strip_private_reasoning(text))
        cleaned = re.sub(r"(?is)</?(?:start_of_turn|end_of_turn|bos|eos|pad|unk)>", "", cleaned)
        cleaned = re.sub(r"(?is)<\|/?(?:turn|channel|tool_call|tool_response|think|end)\|>", "", cleaned)
        cleaned = re.sub(r"(?is)<(?:turn|channel|tool_call|tool_response)\|>", "", cleaned)
        cleaned = re.sub(r"\s+", " ", cleaned).strip()
        return not cleaned

    def _is_bare_completion_without_evidence(self, text, raw_prompt, ledger_id=""):
        cleaned = self._strip_agentic_blocks(self._strip_private_reasoning(text))
        cleaned = re.sub(r"(?is)</?(?:start_of_turn|end_of_turn|bos|eos|pad|unk)>", "", cleaned)
        cleaned = re.sub(r"(?is)<\|/?(?:turn|channel|tool_call|tool_response|think|end)\|>", "", cleaned)
        cleaned = re.sub(r"(?is)<(?:turn|channel|tool_call|tool_response)\|>", "", cleaned)
        cleaned = re.sub(r"\s+", " ", cleaned).strip().lower()
        if cleaned not in {"done", "done.", "completed", "complete", "finished", "finished."}:
            return False
        prompt = re.sub(r"\s+", " ", str(raw_prompt or "").lower()).strip()
        info_markers = [
            "fact", "check", "verify", "what", "who", "when", "where", "why", "how",
            "is ", "are ", "was ", "were ", "tell me", "explain", "answer"
        ]
        if any(marker in prompt for marker in info_markers):
            return True
        if ledger_id and not self._ledger_has_completed_evidence(ledger_id):
            return True
        return False

    def _is_internal_pathway_leak(self, text):
        lowered = str(text or "").lower()
        leak_markers = [
            "<|tool_call", "<tool_call|", "<channel|", "call:",
            "pathway is necessary", "execute the pathway", "backend pathway",
            "bridge block", "tool block", "council-fact-check", "web_search",
            "[web_search]", "[shell]", "[command]", "[native_pptx]"
        ]
        return any(marker in lowered for marker in leak_markers)

    def _local_direct_fallback(self, raw_prompt):
        prompt = re.sub(r"\s+", " ", str(raw_prompt or "").lower()).strip()
        if "apollo 20" in prompt or "appollo 20" in prompt or "apolo 20" in prompt:
            return (
                "No. Apollo 20 was a planned NASA Apollo mission that was cancelled; it did not fly in 1981 "
                "and had no official crew of three astronauts. Claims about a later Apollo 20 mission are generally "
                "treated as hoaxes or conspiracy claims, not official NASA history."
            )
        if "library" in prompt and "container" in prompt and any(word in prompt for word in ["delete", "remove", "move"]):
            return (
                "No, a local AI agent should not directly delete protected macOS Library container folders. "
                "Those folders can hold app state, extensions, privacy-protected data, and system-managed files; the safer path is read-only inspection first, then removing the parent app or extension through macOS/Finder only after explicit user approval."
            )
        return "I could not get a clean final answer from the local model yet. I did not run or complete any hidden action."

    def _is_execution_guard_response(self, text):
        lowered = str(text or "").lower()
        return (
            "no kira os pathway returned execution evidence" in lowered
            or "did not return a verified answer in time" in lowered
            or "i did not complete, open, delete, move, or generate anything" in lowered
            or "i cannot honestly mark this as complete yet" in lowered
        )

    def _is_pure_timeout_response(self, text):
        lowered = re.sub(r"\s+", " ", str(text or "").lower()).strip()
        return (
            "did not return a verified answer in time" in lowered
            or "did not answer in time" in lowered
            or lowered.startswith("agentic step timeout:")
        )

    def _apply_fact_sanity_guard(self, raw_prompt, answer):
        prompt = re.sub(r"\s+", " ", str(raw_prompt or "").lower()).strip()
        text = re.sub(r"\s+", " ", str(answer or "").lower()).strip()

        if "apollo 20" in prompt or "appollo 20" in prompt or "apolo 20" in prompt:
            has_safe_verdict = any(term in text for term in [
                "cancelled", "canceled", "did not fly", "no official", "hoax", "conspiracy"
            ])
            suspicious_claim = any(term in text for term in [
                "automated probe", "three onboard", "three astronauts", "landed", "1981"
            ])
            if suspicious_claim or not has_safe_verdict:
                return self._local_direct_fallback(raw_prompt)

        return answer

    def _polish_final_answer(self, answer):
        value = str(answer or "").strip()
        if not value:
            return value

        verdict_positions = [
            match.start()
            for match in re.finditer(r"(?i)(?:\*\*verdict:\*\*|\bverdict\s*:)", value)
        ]
        if len(verdict_positions) > 1 and verdict_positions[1] > 40:
            value = value[:verdict_positions[1]].rstrip(" .\n") + "."

        value = re.sub(r"\n{3,}", "\n\n", value)
        return value.strip()

    def _handle_direct_artifact_request(self, raw_prompt, chat_id):
        if not hasattr(self, "_wants_artifact_generation"):
            return ""
        if not self._wants_artifact_generation(raw_prompt, chat_id):
            return ""

        text = re.sub(r"\s+", " ", str(raw_prompt or "").lower()).strip()
        explicit_artifact = any(word in text for word in [
            "ppt", "pptx", "presentation", "deck", "pdf", "docx", "word", "document"
        ])
        context_required = any(word in text for word in [
            "scan", "inspect", "check", "search", "browse", "research", "download",
            "downloads", "applications", "apps", "process", "ram", "storage", "system",
            "convert", "from pdf", "using the latest", "latest completed"
        ])
        image_requested = any(word in text for word in [
            "image", "images", "picture", "pictures", "photo", "photos", "visual", "visuals", "logo", "screenshot"
        ])
        image_sources = (
            self._extract_image_sources_from_prompt(raw_prompt)
            if hasattr(self, "_extract_image_sources_from_prompt")
            else []
        )
        if image_requested and not image_sources:
            context_required = True
        create_intent = any(word in text for word in [
            "create", "generate", "genertae", "make", "build", "write", "draft"
        ])
        if not (explicit_artifact and create_intent) or context_required:
            return ""

        kind = self._infer_artifact_kind(raw_prompt, chat_id)
        self.response_queue.put({
            "type": "status",
            "content": f"KIRA OS is generating the {kind.upper()} directly...",
            "chat_id": chat_id
        })
        result = self._generate_prompt_specific_local_artifact(kind, raw_prompt, chat_id)
        if self._artifact_was_really_generated(result):
            try:
                self.response_queue.put({
                    "type": "ui_action",
                    "action": "open_kira_menu",
                    "content": "Opening KIRA menu with the generated artifact.",
                    "chat_id": chat_id
                })
            except Exception:
                pass
            self._record_text_execution_evidence(result, chat_id=chat_id)
            return result
        return ""

    def _recover_empty_orchestrator_answer(
        self,
        raw_prompt,
        system_instruction,
        personalization_context,
        chat_id,
        target_brain="orchestrator",
        agentic_mode_requested=False
    ):
        try:
            if target_brain == "orchestrator" and (self.model_worker_process is None or self.model_worker_process.poll() is not None):
                self._evict_and_load("orchestrator")

            recent_memory = self._load_chat_messages(chat_id)[-6:]
            recovery_instruction = (
                "YOU ARE ORCHESTRATOR V1.\n"
                "Answer directly in a natural human tone. Do not emit or mention backend pathways, "
                "tool calls, tool tags, slash commands, shell commands, private reasoning, or hidden plans.\n"
                "For fact checks, give a clear verdict and the short reason. Do not say only Done/Completed.\n"
                "If current external evidence is unavailable, separate known facts from uncertainty.\n"
                + personalization_context
            )
            messages = [{
                "role": "user",
                "content": (
                    recovery_instruction
                    + "\nRecent chat memory:\n"
                    + json.dumps(recent_memory, ensure_ascii=False)
                    + "\n\nCurrent task:\n"
                    + str(raw_prompt or "")
                    + "\n\nGive only the final answer."
                )
            }]
            response = self._generate_with_watchdog(
                self._tokenizer_prompt(messages),
                temperature=0.38,
                max_tokens=900,
                timeout_seconds=38,
                label="empty_answer_recovery"
            )
            private, public = self._split_orchestrator_response(response)
            self._log_private_thoughts(private)
            cleaned = self._strip_agentic_blocks(self._strip_private_reasoning(public or response))
            if (
                cleaned
                and not self._is_bare_completion_without_evidence(cleaned, raw_prompt)
                and not self._is_internal_pathway_leak(cleaned)
            ):
                return cleaned.strip()
            if self._is_internal_pathway_leak(cleaned or response):
                return self._local_direct_fallback(raw_prompt)
        except Exception as e:
            self._log_agentic_event("empty_answer_recovery_error", {"error": str(e)})

        return self._model_timeout_response(raw_prompt, target_brain, agentic_mode_requested)

    def _worker_loop(self):
        while self.is_running:
            try:
                task = self.task_queue.get(timeout=1)
                self._route_and_generate(task)
                self.task_queue.task_done()
            except queue.Empty:
                continue
            except Exception as e:
                self.response_queue.put({
                    "type": "error",
                    "content": f"Worker Error: {e}"
                })

    def _personalization_loop(self):
        while self.is_running:
            time.sleep(300)
            self._maybe_update_personalization_rag()

    def _load_scheduled_tasks(self):
        try:
            if not os.path.exists(self.scheduled_tasks_path):
                return []
            with open(self.scheduled_tasks_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, list):
                return []
            now = time.time()
            for task in data:
                if task.get("status") == "running":
                    task["status"] = "pending"
                    task["recovered_at"] = now
                    task["recovered_label"] = self._format_timestamp(now)
                    task["recovery_note"] = "Recovered stale running task after app restart."
            return data
        except Exception:
            return []

    def _save_scheduled_tasks(self):
        try:
            with self.scheduled_tasks_lock:
                tasks = list(self.scheduled_tasks)
            with open(self.scheduled_tasks_path, "w", encoding="utf-8") as f:
                json.dump(tasks, f, indent=2, ensure_ascii=False)
        except Exception as e:
            self._log_agentic_event("scheduled_task_save_error", {"error": str(e)})

    def _scheduled_task_loop(self):
        while self.is_running:
            try:
                now = time.time()
                due_tasks = []
                with self.scheduled_tasks_lock:
                    for task in self.scheduled_tasks:
                        if task.get("status") == "pending" and float(task.get("run_at", 0) or 0) <= now:
                            task["status"] = "running"
                            task["started_at"] = now
                            task["started_label"] = self._format_timestamp(now)
                            due_tasks.append(dict(task))

                if due_tasks:
                    self._save_scheduled_tasks()

                for task in due_tasks:
                    self.response_queue.put({
                        "type": "status",
                        "content": f"Running scheduled task: {task.get('title', 'Scheduled task')}",
                        "chat_id": task.get("chat_id")
                    })
                    original_prompt = str(task.get("prompt", "")).strip()
                    if original_prompt and self._extract_agentic_blocks(original_prompt):
                        prompt = original_prompt
                    else:
                        prompt = (
                            "Scheduled background task is due now. Execute it through KIRA OS pathways. "
                            "Do not claim completion unless execution evidence is returned.\n\n"
                            + original_prompt
                        )
                    self.task_queue.put({
                        "prompt": prompt,
                        "mode": task.get("mode", "agentic"),
                        "selected_model": task.get("selected_model", "orchestrator"),
                        "chat_id": task.get("chat_id"),
                        "scheduled_task_id": task.get("id")
                    })

            except Exception as e:
                self._log_agentic_event("scheduled_task_loop_error", {"error": str(e)})

            time.sleep(2)

    def _parse_schedule_delay_seconds(self, text, default_seconds=60):
        value = str(text or "").strip().lower()
        if not value:
            return int(default_seconds)

        match = re.search(r"(\d+(?:\.\d+)?)\s*(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d)\b", value)
        if match:
            amount = float(match.group(1))
            unit = match.group(2)
            if unit.startswith(("second", "sec", "s")):
                return max(1, int(amount))
            if unit.startswith(("minute", "min", "m")):
                return max(1, int(amount * 60))
            if unit.startswith(("hour", "hr", "h")):
                return max(1, int(amount * 3600))
            if unit.startswith(("day", "d")):
                return max(1, int(amount * 86400))

        at_match = re.search(r"\bat\s+(\d{1,2})(?::(\d{2}))?\s*(am|pm)?\b", value)
        if at_match:
            now_struct = time.localtime()
            hour = int(at_match.group(1))
            minute = int(at_match.group(2) or 0)
            ampm = at_match.group(3)
            if ampm == "pm" and hour < 12:
                hour += 12
            if ampm == "am" and hour == 12:
                hour = 0
            target = time.mktime((
                now_struct.tm_year, now_struct.tm_mon, now_struct.tm_mday,
                hour, minute, 0,
                now_struct.tm_wday, now_struct.tm_yday, now_struct.tm_isdst
            ))
            if target <= time.time():
                target += 86400
            return max(1, int(target - time.time()))

        if "tomorrow" in value:
            return 86400
        if "later" in value:
            return int(default_seconds)
        return int(default_seconds)

    def schedule_agentic_task(self, prompt, delay_text="", delay_seconds=None, mode="agentic", selected_model="orchestrator", chat_id=None, title=""):
        if not chat_id:
            chat = self.new_chat(title or "Scheduled Task")
            chat_id = chat["id"]

        if delay_seconds is None:
            delay_seconds = self._parse_schedule_delay_seconds(delay_text, default_seconds=60)
        delay_seconds = max(1, int(float(delay_seconds)))
        now = time.time()
        run_at = now + delay_seconds
        task = {
            "id": f"sched_{int(now)}_{uuid.uuid4().hex[:8]}",
            "title": str(title or prompt or "Scheduled task").strip()[:80],
            "prompt": str(prompt or "").strip(),
            "mode": mode or "agentic",
            "selected_model": selected_model or "orchestrator",
            "chat_id": chat_id,
            "status": "pending",
            "created_at": now,
            "created_label": self._format_timestamp(now),
            "run_at": run_at,
            "run_label": self._format_timestamp(run_at),
            "delay_seconds": delay_seconds
        }
        with self.scheduled_tasks_lock:
            self.scheduled_tasks.append(task)
        self._save_scheduled_tasks()
        self._record_execution_evidence(
            "schedule_task",
            "scheduled",
            f"Scheduled background task `{task['id']}` for {task['run_label']}.",
            {"task_id": task["id"], "run_at": run_at},
            chat_id=chat_id
        )
        return (
            f"SCHEDULED TASK:\n"
            f"ID: `{task['id']}`\n"
            f"Runs: `{task['run_label']}`\n"
            f"Task: {task['prompt']}"
        )

    def get_scheduled_tasks(self):
        with self.scheduled_tasks_lock:
            return list(self.scheduled_tasks)

    def _mark_scheduled_task_status(self, task_id, status, result=""):
        if not task_id:
            return
        now = time.time()
        changed = False
        with self.scheduled_tasks_lock:
            for task in self.scheduled_tasks:
                if task.get("id") == task_id:
                    task["status"] = status
                    task["finished_at"] = now
                    task["finished_label"] = self._format_timestamp(now)
                    task["result"] = self._truncate(str(result or ""), 1200)
                    changed = True
                    break
        if changed:
            self._save_scheduled_tasks()

    def _scheduled_task_final_status(self, result):
        value = str(result or "").strip()
        lowered = value.lower()
        if not value:
            return "failed"
        if "permission required:" in lowered:
            return "waiting_permission"
        failed_markers = [
            "critical error:", "worker error:", "failed", "error:", "timed out",
            "timeout", "did not create", "could not", "blocked safely",
            "no execution evidence"
        ]
        if any(marker in lowered for marker in failed_markers):
            return "failed"
        return "completed"

    def _start_execution_ledger(self, chat_id, raw_prompt):
        ledger_id = f"exec_{int(time.time())}_{uuid.uuid4().hex[:8]}"
        ledger = {
            "id": ledger_id,
            "chat_id": chat_id,
            "prompt": str(raw_prompt or ""),
            "started_at": time.time(),
            "started_label": self._format_timestamp(time.time()),
            "actions": []
        }
        with self.execution_lock:
            self.execution_ledgers[ledger_id] = ledger
            self.active_execution_ledger_id = ledger_id
        return ledger_id

    def _finish_execution_ledger(self, ledger_id, final_answer=""):
        if not ledger_id:
            return
        with self.execution_lock:
            ledger = self.execution_ledgers.get(ledger_id)
            if not ledger:
                return
            ledger["finished_at"] = time.time()
            ledger["finished_label"] = self._format_timestamp(ledger["finished_at"])
            ledger["final_answer"] = self._truncate(str(final_answer or ""), 2000)
        try:
            with open(self.execution_ledger_path, "a", encoding="utf-8") as f:
                f.write(json.dumps(ledger, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def _record_execution_evidence(self, action, status, summary, metadata=None, chat_id=None, ledger_id=None):
        entry = {
            "time": time.time(),
            "time_label": self._format_timestamp(time.time()),
            "action": str(action or "unknown"),
            "status": str(status or "unknown"),
            "summary": self._truncate(str(summary or ""), 1200),
            "metadata": metadata or {}
        }
        target_id = ledger_id or getattr(self, "active_execution_ledger_id", "")
        with self.execution_lock:
            ledger = self.execution_ledgers.get(target_id)
            if ledger is not None:
                ledger.setdefault("actions", []).append(entry)
        self._log_agentic_event("execution_evidence", {
            "ledger_id": target_id,
            "chat_id": chat_id,
            **entry
        })
        return entry

    def _record_text_execution_evidence(self, text, chat_id=None):
        value = str(text or "")
        lowered = value.lower()
        evidence = []

        marker_map = [
            ("permission", "pending", "Permission required:"),
            ("shell", "executed", "TERMINAL EXECUTION"),
            ("applescript", "executed", "APPLESCRIPT EXECUTION"),
            ("python", "executed", "PYTHON EXECUTION"),
            ("project_command", "executed", "PROJECT COMMAND"),
            ("open", "opened", "OPEN:"),
            ("open", "opened", "Opened in IDE/app"),
            ("web", "executed", "WEB_SEARCH:"),
            ("web", "executed", "WEB_FETCH:"),
            ("read_file", "executed", "READ_FILE:"),
            ("list_dir", "executed", "LIST_DIR:"),
            ("search_files", "executed", "SEARCH_FILES:"),
            ("find_in_computer", "executed", "FIND_IN_COMPUTER:"),
            ("read_only_scan", "executed", "READ_ONLY_FILE_CHECK"),
            ("read_only_scan", "executed", "READ_ONLY_VIRUS_SCAN"),
            ("read_only_scan", "executed", "READ_ONLY_OPTIMISE_SCAN"),
            ("read_only_scan", "executed", "READ_ONLY_APPLICATION_ACTIVITY"),
            ("utility", "executed", "CLIPBOARD_READ:"),
            ("utility", "executed", "CLIPBOARD_WRITE:"),
            ("utility", "executed", "HASH_FILE:"),
            ("utility", "executed", "FILE_COMPARE:"),
            ("utility", "executed", "ARCHIVE_PREVIEW:"),
            ("utility", "executed", "ZIP_CREATE:"),
            ("artifact", "generated", "NOTE_DRAFT:"),
            ("artifact", "generated", "CALENDAR_DRAFT:"),
            ("artifact", "generated", "REMINDER_DRAFT:"),
            ("artifact", "generated", "PDF Generated"),
            ("artifact", "generated", "PPTX generated"),
            ("artifact", "generated", "DOCX generated"),
            ("file_write", "executed", "File written"),
            ("file_write", "executed", "File appended"),
            ("file_move", "executed", "Path moved"),
            ("file_delete", "executed", "Path moved to Trash"),
            ("schedule", "scheduled", "SCHEDULED TASK:"),
            ("ide_paste_run", "executed", "IDE PASTE/RUN"),
            ("timeout", "blocked", "AGENTIC STEP TIMEOUT"),
            ("error", "failed", "AGENTIC STEP ERROR"),
            ("blocked", "blocked", "BLOCKED SAFELY"),
            ("failed", "failed", "FAILED SAFELY")
        ]

        for action, status, marker in marker_map:
            if marker.lower() in lowered:
                evidence.append(self._record_execution_evidence(
                    action,
                    status,
                    marker,
                    {"source": "text_marker"},
                    chat_id=chat_id
                ))
        return evidence

    def _prompt_requires_execution_truth(self, raw_prompt, mode=""):
        text = re.sub(r"\s+", " ", str(raw_prompt or "").lower())
        mode_text = str(mode or "").lower()
        markers = [
            "open", "close", "quit", "run", "execute", "paste", "write", "edit",
            "delete", "move", "install", "set up", "setup", "connect", "mcp",
            "ide", "cursor", "windsurf", "xcode", "generate", "create", "make",
            "ppt", "pptx", "pdf", "docx", "word", "report", "search", "browse",
            "scan", "inspect", "check", "find", "automate", "schedule", "later",
            "after "
        ]
        scheduled_delay = bool(re.search(r"\bin\s+\d+(?:\.\d+)?\s*(?:seconds?|secs?|minutes?|mins?|hours?|hrs?|days?)\b", text))
        return (
            mode_text in {"agent", "agentic", "agentic_rag", "agentic task chat"}
            or scheduled_delay
            or any(marker in text for marker in markers)
        )

    def _ledger_actions(self, ledger_id):
        with self.execution_lock:
            ledger = self.execution_ledgers.get(ledger_id, {})
            return list(ledger.get("actions", []))

    def _ledger_has_status(self, ledger_id, statuses):
        statuses = {str(status).lower() for status in statuses}
        return any(str(action.get("status", "")).lower() in statuses for action in self._ledger_actions(ledger_id))

    def _ledger_status_summary(self, ledger_id):
        actions = self._ledger_actions(ledger_id)
        if not actions:
            return "No backend pathway produced execution evidence."
        return "\n".join(
            f"- {item.get('status', 'unknown')}: {item.get('action', 'unknown')} - {item.get('summary', '')}"
            for item in actions[-8:]
        )

    def _answer_claims_completion(self, answer):
        lowered = str(answer or "").lower()
        claims = [
            "done", "completed", "complete", "successfully", "generated",
            "created", "opened", "closed", "ran", "executed", "pasted",
            "installed", "connected", "scheduled", "ready for review"
        ]
        return any(claim in lowered for claim in claims)

    def _enforce_execution_truth(self, raw_prompt, answer, ledger_id, chat_id):
        if not ledger_id or not self._prompt_requires_execution_truth(raw_prompt):
            return answer

        actions = self._ledger_actions(ledger_id)
        if not actions:
            if self._answer_claims_completion(answer):
                return (
                    "I cannot honestly mark this as complete yet because no KIRA OS pathway returned execution evidence.\n\n"
                    "I need to run the correct backend action first, or ask for approval if it is risky."
                )
            return answer

        completed_statuses = {"executed", "generated", "opened", "scheduled"}
        has_completed_evidence = self._ledger_has_status(ledger_id, completed_statuses)
        if self._ledger_has_status(ledger_id, {"pending"}) and not has_completed_evidence:
            return (
                "I have not completed it yet. I queued the required permission and am waiting for your approval.\n\n"
                + self._ledger_status_summary(ledger_id)
            )

        if has_completed_evidence and any(phrase in str(answer or "").lower() for phrase in [
            "waiting for your approval",
            "permission required",
            "not completed it yet",
            "await your final confirmation"
        ]):
            completed_actions = [
                item for item in actions
                if str(item.get("status", "")).lower() in completed_statuses
            ]
            if any(item.get("action") == "file_delete" for item in completed_actions):
                return "Done. I moved the approved path to Trash. Nothing was permanently deleted."
            if any(item.get("action") == "file_move" for item in completed_actions):
                return "Done. I moved the approved path."
            if any(item.get("action") == "artifact" for item in completed_actions):
                return "Done. I generated the requested artifact and added it to the KIRA menu."
            if any(item.get("action") == "open" for item in completed_actions):
                return "Done. I opened it."
            return "Done. The approved backend action completed."

        if self._ledger_has_status(ledger_id, {"blocked", "failed"}) and self._answer_claims_completion(answer):
            return (
                "I cannot mark this as complete because the backend pathway was blocked or failed.\n\n"
                + self._ledger_status_summary(ledger_id)
            )

        if self._answer_claims_completion(answer) and not has_completed_evidence:
            return (
                "I cannot honestly mark this as complete yet. KIRA recorded activity, but not a completed execution.\n\n"
                + self._ledger_status_summary(ledger_id)
            )

        return answer

    def _route_and_generate(self, task):
        raw_prompt = str(task.get("prompt", "")).strip()
        mode = str(task.get("mode", "chat")).lower()
        selected_model = str(task.get("selected_model", "orchestrator")).lower()
        chat_id = task.get("chat_id")
        scheduled_task_id = task.get("scheduled_task_id", "")
        ledger_id = ""
        previous_ledger_id = getattr(self, "active_execution_ledger_id", "")

        if not raw_prompt:
            self.response_queue.put({"type": "error", "content": "Prompt is empty.", "chat_id": chat_id})
            return

        if not chat_id:
            chat = self.new_chat()
            chat_id = chat["id"]

        self.active_chat_id = chat_id

        handled_ui = self._handle_ui_control_prompt(raw_prompt, chat_id)
        if handled_ui:
            return

        force_agentic_ai_review = raw_prompt.lower().startswith((
            "/virus", "/malware", "/safety-scan", "/safetyscan",
            "/optimise", "/optimize"
        ))
        prompt_lower = raw_prompt.lower()
        slash_head = prompt_lower.split(maxsplit=1)[0] if prompt_lower.startswith("/") else ""
        slash_needs_ai = bool(slash_head and slash_head not in {"/open", "/launch", "/close", "/quit", "/help", "/commands", "/"})
        needs_agentic_pathway = force_agentic_ai_review or any(phrase in prompt_lower for phrase in [
            "virus", "malware", "trojan", "spyware", "scan for threats",
            "optimise", "optimize", "clean up my computer", "free up space",
            "storage cleanup", "massive data control", "mass data control",
            "delete", "remove", "move", "write", "edit", "modify", "install", "apply",
            "open ", "browse", "search", "find ", "find in", "find out",
            "terminal", "command", "applescript", "automate", "connect",
            "mcp", "ide", "cursor", "windsurf", "xcode", "ppt", "pptx",
            "pdf", "presentation", "deck", "track", "monitor", "applications",
            "schedule", "later", "sleep", "background", "paste", "run code",
            "apps", "processes", "files", "folders", "multi modal", "multimodal",
            "multi-model", "multi model", "multi agent", "parallel reasoning",
            "two orchestrators", "dual orchestrator", "council mode",
            "generate", "genertae", "create", "build", "report", "docx", "word"
        ]) or slash_needs_ai

        if not force_agentic_ai_review:
            slash_result = self._handle_slash_command(raw_prompt, mode, selected_model, chat_id)
            if slash_result:
                self._append_chat_message(chat_id, "user", raw_prompt, "User")
                self._append_chat_message(chat_id, "assistant", slash_result, "KIRA Slash Command")
                self.response_queue.put({
                    "type": "message",
                    "content": slash_result,
                    "model_used": "KIRA Slash Command",
                    "chat_id": chat_id
                })
                self._maybe_update_personalization_rag(force=False)
                self._speak_if_voice_active(slash_result)
                return

        handled = self._handle_permission_shortcut(raw_prompt, chat_id)
        if handled:
            return

        artifact_followup = self._handle_artifact_followup(raw_prompt, chat_id)
        if artifact_followup:
            self._append_chat_message(chat_id, "user", raw_prompt, "User")
            self._append_chat_message(chat_id, "assistant", artifact_followup, "KIRA Artifact")
            self.response_queue.put({
                "type": "message",
                "content": artifact_followup,
                "model_used": "KIRA Artifact",
                "chat_id": chat_id
            })
            self._maybe_update_personalization_rag(force=False)
            self._speak_if_voice_active(artifact_followup)
            return

        direct_navigation = self._handle_natural_open_close(raw_prompt, chat_id)
        if direct_navigation:
            self._append_chat_message(chat_id, "user", raw_prompt, "User")
            self._append_chat_message(chat_id, "assistant", direct_navigation, "KIRA Navigation")
            self.response_queue.put({
                "type": "message",
                "content": direct_navigation,
                "model_used": "KIRA Navigation",
                "chat_id": chat_id
            })
            self._maybe_update_personalization_rag(force=False)
            self._speak_if_voice_active(direct_navigation)
            return

        preflight = self._preflight_prompt(raw_prompt)
        if preflight:
            self._append_chat_message(chat_id, "user", raw_prompt, "User")
            self._append_chat_message(chat_id, "assistant", preflight, "Agentic Planner")
            self.response_queue.put({
                "type": "message",
                "content": preflight,
                "model_used": "Agentic Planner",
                "chat_id": chat_id
            })
            self._maybe_update_personalization_rag(force=False)
            self._speak_if_voice_active(preflight)
            return

        base_agentic_requested = (
            needs_agentic_pathway
            or mode in ["agent", "agentic", "agentic_rag", "agentic task chat"]
        )
        council_decision = self._council_confidence_decision(
            raw_prompt,
            mode,
            agentic_mode_requested=base_agentic_requested,
            needs_agentic_pathway=needs_agentic_pathway
        )
        council_enabled = bool(council_decision.get("enabled"))

        # KIRA OS is Orchestrator-only until Kira V1 is retrained and re-enabled.
        # This keeps stale UI/API calls from accidentally loading the older model.
        target_brain = "orchestrator"

        agentic_mode_requested = (
            base_agentic_requested
            or council_enabled
        )
        if self._prompt_requires_execution_truth(raw_prompt, mode):
            ledger_id = self._start_execution_ledger(chat_id, raw_prompt)

        if self._is_simple_chat_prompt(raw_prompt, mode, needs_agentic_pathway):
            display_response = self._fast_simple_chat_response(raw_prompt, target_brain)
            self.session_memory.append({"role": "user", "content": raw_prompt})
            self.session_memory.append({"role": "model", "content": display_response})
            self.session_memory = self.session_memory[-8:]
            self._append_chat_message(chat_id, "user", raw_prompt, "User")
            self._append_chat_message(chat_id, "assistant", display_response, f"{target_brain.capitalize()} V1")
            self.response_queue.put({
                "type": "message",
                "content": display_response,
                "model_used": f"{target_brain.capitalize()} V1",
                "chat_id": chat_id
            })
            self._maybe_update_personalization_rag(force=False)
            if target_brain == "orchestrator":
                self._speak_if_voice_active(display_response)
            return

        direct_artifact = "" if base_agentic_requested else self._handle_direct_artifact_request(raw_prompt, chat_id)
        if direct_artifact:
            self._append_chat_message(chat_id, "user", raw_prompt, "User")
            self._append_chat_message(chat_id, "assistant", direct_artifact, "KIRA Artifact")
            self.response_queue.put({
                "type": "message",
                "content": direct_artifact,
                "model_used": "KIRA Artifact",
                "chat_id": chat_id
            })
            self._maybe_update_personalization_rag(force=False)
            self._speak_if_voice_active(direct_artifact)
            if ledger_id:
                self._finish_execution_ledger(ledger_id, direct_artifact)
                self.active_execution_ledger_id = previous_ledger_id
            return

        scheduled_direct_blocks = (
            self._extract_agentic_blocks(raw_prompt)
            if scheduled_task_id
            else ""
        )
        if scheduled_direct_blocks:
            self.response_queue.put({
                "type": "status",
                "content": "Running scheduled agentic pathway...",
                "chat_id": chat_id
            })
            self._append_chat_message(chat_id, "user", raw_prompt, "User")
            direct_result = self._run_agentic_capabilities_with_watchdog(
                scheduled_direct_blocks,
                raw_prompt,
                chat_id,
                "scheduled_direct"
            )
            display_response = self._strip_private_reasoning(direct_result)
            display_response = self._strip_agentic_blocks(display_response)
            display_response = self._polish_final_answer(display_response).strip()
            if not display_response:
                display_response = self._model_timeout_response(raw_prompt, "orchestrator", True)
            self._record_text_execution_evidence(display_response, chat_id=chat_id)
            self._append_chat_message(chat_id, "assistant", display_response, "Orchestrator V1")
            self.response_queue.put({
                "type": "message",
                "content": display_response,
                "model_used": "Orchestrator V1",
                "chat_id": chat_id
            })
            self._mark_scheduled_task_status(
                scheduled_task_id,
                self._scheduled_task_final_status(display_response),
                display_response
            )
            self._maybe_update_personalization_rag(force=False)
            self._speak_if_voice_active(self._voice_clean(display_response))
            return

        agentic_preflight_context = ""

        try:
            self._evict_and_load(target_brain)
            self.response_queue.put({
                "type": "status",
                "content": f"{target_brain.capitalize()} is thinking...",
                "chat_id": chat_id
            })

            direct_answer_mode = bool(
                target_brain == "orchestrator"
                and not needs_agentic_pathway
                and not council_enabled
            )
            system_instruction = (
                self._build_direct_orchestrator_instruction()
                if direct_answer_mode
                else self._build_system_instruction(target_brain)
            )
            recent_memory = self._load_chat_messages(chat_id)[-8:]
            personalization_context = ""
            if target_brain == "orchestrator":
                personalization_context = (
                    "\n\nOrchestrator-only personalization RAG. Use only if relevant to the current task; ignore otherwise:\n"
                    + json.dumps(self._load_personalization_rag(), ensure_ascii=False)
                )
                if needs_agentic_pathway:
                    agentic_preflight_context = self._try_agentic_preflight_context(raw_prompt, chat_id)
                    if agentic_preflight_context:
                        self._record_execution_evidence(
                            "read_only_preflight",
                            "executed",
                            "KIRA OS gathered safe read-only context before model synthesis.",
                            {"chars": len(agentic_preflight_context)},
                            chat_id=chat_id,
                            ledger_id=ledger_id
                        )

            messages = [{
                "role": "user",
                "content": (
                    system_instruction
                    + personalization_context
                    + "\n\nRecent chat memory:\n"
                    + json.dumps(recent_memory, ensure_ascii=False)
                    + (
                        "\n\nRead-only local inspection context already gathered by KIRA OS:\n"
                        + agentic_preflight_context
                        if agentic_preflight_context
                        else ""
                    )
                    + "\n\nCurrent task:\n"
                    + raw_prompt
                )
            }]

            if target_brain == "orchestrator" and agentic_mode_requested and council_enabled:
                self.response_queue.put({
                    "type": "status",
                    "content": f"Council accelerator is choosing the path ({council_decision.get('score', 0):.2f})...",
                    "chat_id": chat_id
                })
                private_thoughts = ""
                public_answer = ""
            else:
                prompt = self._tokenizer_prompt(messages)

                if target_brain == "orchestrator":
                    prompt += "<thought_process>\n"

                response = self._generate_with_watchdog(
                    prompt,
                    temperature=0.55,
                    max_tokens=1800,
                    timeout_seconds=45,
                    label="initial_model_generation"
                )
                model_response_missing = self._is_effectively_empty_model_text(response)
                if model_response_missing:
                    private_thoughts = ""
                    if target_brain == "orchestrator":
                        public_answer = self._recover_empty_orchestrator_answer(
                            raw_prompt,
                            system_instruction,
                            personalization_context,
                            chat_id,
                            target_brain=target_brain,
                            agentic_mode_requested=agentic_mode_requested
                        )
                    else:
                        public_answer = self._model_timeout_response(raw_prompt, target_brain, agentic_mode_requested)
                    agentic_mode_requested = False
                    council_enabled = False
                else:
                    private_thoughts, public_answer = self._split_orchestrator_response(response)

            model_selected_actions = bool(
                self._extract_agentic_blocks(private_thoughts)
                or self._extract_agentic_blocks(public_answer)
            )
            force_agentic_pathway = bool(needs_agentic_pathway)
            should_run_agentic_loop = bool(
                target_brain == "orchestrator"
                and (model_selected_actions or force_agentic_pathway or council_enabled)
            )

            if should_run_agentic_loop:
                public_answer = self._run_orchestrator_agent_loop(
                    raw_prompt,
                    private_thoughts,
                    public_answer,
                    system_instruction,
                    personalization_context,
                    chat_id,
                    council_enabled=council_enabled,
                    force_pathway=force_agentic_pathway
                )
                public_answer = self._synthesize_raw_agentic_result_if_needed(
                    raw_prompt,
                    public_answer,
                    system_instruction,
                    personalization_context,
                    chat_id
                )
                public_answer = self._ensure_requested_artifact_or_real_open(
                    raw_prompt,
                    public_answer,
                    agentic_preflight_context,
                    chat_id
                )
                self._record_text_execution_evidence(public_answer, chat_id=chat_id)
                public_answer = self._strip_private_reasoning(public_answer)
                public_answer = self._strip_agentic_blocks(public_answer)
                public_answer = self._enforce_execution_truth(raw_prompt, public_answer, ledger_id, chat_id)

                if (
                    self._is_effectively_empty_model_text(public_answer)
                    or self._is_bare_completion_without_evidence(public_answer, raw_prompt, ledger_id)
                    or self._is_internal_pathway_leak(public_answer)
                ):
                    public_answer = self._recover_empty_orchestrator_answer(
                        raw_prompt,
                        system_instruction,
                        personalization_context,
                        chat_id,
                        target_brain=target_brain,
                        agentic_mode_requested=agentic_mode_requested
                    )
            elif target_brain == "orchestrator":
                public_answer = self._strip_private_reasoning(public_answer)
                public_answer = self._strip_agentic_blocks(public_answer)
                public_answer = self._enforce_execution_truth(raw_prompt, public_answer, ledger_id, chat_id)
                if (
                    self._is_effectively_empty_model_text(public_answer)
                    or self._is_bare_completion_without_evidence(public_answer, raw_prompt, ledger_id)
                    or self._is_internal_pathway_leak(public_answer)
                ):
                    public_answer = self._recover_empty_orchestrator_answer(
                        raw_prompt,
                        system_instruction,
                        personalization_context,
                        chat_id,
                        target_brain=target_brain,
                        agentic_mode_requested=agentic_mode_requested
                    )

            display_response = public_answer.strip()
            if target_brain == "orchestrator":
                if agentic_preflight_context and (
                    self._is_execution_guard_response(display_response)
                    or self._is_pure_timeout_response(display_response)
                ):
                    display_response = self._local_agentic_summary(raw_prompt, agentic_preflight_context)
                if self._has_raw_agentic_result(display_response) or (
                    "cannot perform the inspection" in display_response.lower()
                    and any(marker in display_response for marker in ["LIST_DIR:", "READ_FILE:", "FIND_IN_COMPUTER:"])
                ):
                    display_response = self._local_agentic_summary(raw_prompt, display_response)
                if self._is_pure_timeout_response(display_response):
                    fallback = self._local_direct_fallback(raw_prompt)
                    if not fallback.startswith("I could not get a clean final answer"):
                        display_response = fallback
                display_response = self._apply_fact_sanity_guard(raw_prompt, display_response).strip()
            display_response = self._polish_final_answer(display_response)
            spoken_text = self._voice_clean(display_response)

            self.session_memory.append({"role": "user", "content": raw_prompt})
            self.session_memory.append({"role": "model", "content": display_response})
            self.session_memory = self.session_memory[-8:]

            self._append_chat_message(chat_id, "user", raw_prompt, "User")
            self._append_chat_message(chat_id, "assistant", display_response, f"{target_brain.capitalize()} V1")
            self._maybe_update_personalization_rag(force=False)

            self.response_queue.put({
                "type": "message",
                "content": display_response,
                "model_used": f"{target_brain.capitalize()} V1",
                "chat_id": chat_id
            })

            if target_brain == "orchestrator":
                self._speak_if_voice_active(spoken_text)

        except Exception as e:
            error_trace = traceback.format_exc()
            self._log_agentic_event("critical_error", {"error": str(e), "trace": error_trace})
            if locals().get("target_brain", "") == "kira":
                display_response = self._kira_v1_unavailable_fallback(raw_prompt, str(e))
                self._append_chat_message(chat_id, "user", raw_prompt, "User")
                self._append_chat_message(chat_id, "assistant", display_response, "Kira V1")
                self.response_queue.put({
                    "type": "message",
                    "content": display_response,
                    "model_used": "Kira V1",
                    "chat_id": chat_id
                })
                return
            self.response_queue.put({
                "type": "error",
                "content": f"Critical Error: {str(e)}",
                "chat_id": chat_id
            })
        finally:
            if scheduled_task_id:
                scheduled_result = locals().get("display_response", locals().get("error_trace", ""))
                self._mark_scheduled_task_status(
                    scheduled_task_id,
                    self._scheduled_task_final_status(scheduled_result),
                    scheduled_result
                )
            if ledger_id:
                self._finish_execution_ledger(ledger_id, locals().get("display_response", ""))
                self.active_execution_ledger_id = previous_ledger_id
            gc.collect()

    def _kira_v1_unavailable_fallback(self, raw_prompt, error):
        prompt = re.sub(r"\s+", " ", str(raw_prompt or "").lower()).strip()
        if "clean code" in prompt:
            answer = "One benefit of clean code is that it makes software easier to understand, debug, and safely improve over time."
        elif any(word in prompt for word in ["hi", "hello", "hey"]):
            answer = "Hi, I’m Kira V1. I’m here and ready to help."
        else:
            answer = (
                "Kira V1 did not load into VRAM fast enough on this run, so I kept the app responsive instead of crashing. "
                "Try the same prompt again after closing other memory-heavy apps, or use Orchestrator V1 for this turn."
            )
        self._log_agentic_event("kira_v1_load_fallback", {
            "error": str(error),
            "prompt": self._truncate(str(raw_prompt or ""), 500)
        })
        return answer

    def _generate_with_temperature(self, prompt, temperature=0.35, max_tokens=1500, timeout_seconds=None):
        return self._generate_sync(prompt, temperature, max_tokens, timeout_seconds=timeout_seconds)

    def _generate_sync(self, prompt, temperature=0.35, max_tokens=1500, timeout_seconds=None):
        timeout = timeout_seconds if timeout_seconds is not None else self.model_worker_generation_timeout
        if self.model_worker_process is None or self.model_worker_process.poll() is not None:
            self._evict_and_load(self.current_brain or "orchestrator")
        return str(self._model_worker_request({
            "type": "generate",
            "prompt": str(prompt or ""),
            "temperature": float(temperature),
            "max_tokens": int(max_tokens)
        }, timeout=timeout) or "")

    def _tokenizer_prompt(self, messages):
        body = "<bos>"
        for message in messages or []:
            role = str(message.get("role", "user")).lower()
            role = "model" if role in ["assistant", "model"] else "user"
            content = str(message.get("content", ""))
            body += f"<|turn>{role}\n{content}<turn|>\n"
        return body + "<|turn>model\n"

    def _has_raw_agentic_result(self, text):
        raw_markers = [
            "TERMINAL EXECUTION:",
            "APPLESCRIPT EXECUTION:",
            "PYTHON EXECUTION:",
            "PROJECT COMMAND",
            "OPEN:",
            "Opened:",
            "CLOSE:",
            "Read-only investigation scope:",
            "SEARCH_FILES:",
            "LIST_DIR:",
            "READ_FILE:",
            "FIND_IN_COMPUTER:",
            "CLIPBOARD_READ:",
            "CLIPBOARD_WRITE:",
            "HASH_FILE:",
            "FILE_COMPARE:",
            "ARCHIVE_PREVIEW:",
            "ZIP_CREATE:",
            "NOTE_DRAFT:",
            "CALENDAR_DRAFT:",
            "REMINDER_DRAFT:",
            "WEB_SEARCH:",
            "WEB_OPEN:",
            "WEB_FETCH:",
            "WEB_BROWSE:",
            "WEB_HEADLESS:",
            "IDE CONTEXT:",
            "IDE PASTE/RUN RESULT:",
            "PROJECT INDEX:",
            "APP INTEGRATION:",
            "BLENDER INTEGRATION:",
            "APP_LIST:",
            "WINDOW_REPORT:",
            "SCREENSHOT_CONTEXT:",
            "NETWORK_REPORT:",
            "MCP setup",
            "MCP config",
            "MCP draft",
            "APPLICATION ACTIVITY SNAPSHOT:",
            "READ_ONLY_APPLICATION_ACTIVITY",
            "PDF Generated:",
            "PDF generated:",
            "PDF converted",
            "PPTX generated",
            "DOCX generated",
            "SCHEDULED TASK:",
            "Virus scan completed as a read-only safety check.",
            "Optimisation scan completed read-only.",
            "Directory listing:",
            "Command timed out"
        ]
        answer_text = str(text or "")
        return any(marker in answer_text for marker in raw_markers)

    def _wants_orchestrator_council(self, raw_prompt, mode=""):
        text = re.sub(r"\s+", " ", str(raw_prompt or "").lower())
        mode_text = str(mode or "").lower()
        return (
            "council" in mode_text
            or any(phrase in text for phrase in [
                "multi modal", "multimodal", "multi-model", "multi model",
                "multi agent", "multi-agent", "parallel orchestrator",
                "parallel reasoning", "two orchestrators", "two of the same model",
                "reasoning with each other", "reason with each other",
                "dual orchestrator", "orchestrator council", "council mode"
            ])
        )

    def _council_confidence_decision(
        self,
        raw_prompt,
        mode="",
        agentic_mode_requested=False,
        needs_agentic_pathway=False
    ):
        text = re.sub(r"\s+", " ", str(raw_prompt or "").lower()).strip()
        mode_text = str(mode or "").lower()
        words = text.split()
        reasons = []
        score = 0.0
        council_mode = "reasoning"

        def present(term):
            if re.fullmatch(r"[a-z0-9_+-]+", term) and len(term) <= 4:
                return bool(re.search(rf"\b{re.escape(term)}\b", text))
            return term in text

        def collect(terms):
            return [term for term in terms if present(term)]

        def add(points, reason, target_mode="reasoning"):
            nonlocal score, council_mode
            score += points
            if reason not in reasons:
                reasons.append(reason)
            if target_mode == "agentic":
                council_mode = "agentic"

        base_threshold = float(getattr(self, "council_confidence_threshold", 0.58))

        if not text:
            return {"enabled": False, "score": 0.0, "threshold": base_threshold, "mode": "none", "reasons": []}

        if self._wants_orchestrator_council(raw_prompt, mode):
            decision = {
                "enabled": True,
                "score": 1.0,
                "threshold": 0.0,
                "mode": "explicit",
                "reasons": ["explicit council request"]
            }
            self._log_agentic_event("council_confidence_decision", {
                "prompt": self._truncate(str(raw_prompt or ""), 500),
                "mode": mode_text,
                "agentic_mode_requested": agentic_mode_requested,
                "needs_agentic_pathway": needs_agentic_pathway,
                **decision
            })
            return decision

        simple_direct = re.fullmatch(r"(?:open|launch|close|quit)\s+[a-z0-9 ._:/~+-]{1,90}", text)
        simple_chat = (
            not agentic_mode_requested
            and not needs_agentic_pathway
            and len(words) <= 18
            and not any(mark in text for mark in ["fact check", "verify", "compare", "benchmark", "prove", "disprove", "debug", "architecture"])
        )
        if simple_direct or simple_chat:
            decision = {
                "enabled": False,
                "score": 0.03 if simple_direct else 0.08,
                "threshold": base_threshold,
                "mode": "none",
                "reasons": ["simple direct action" if simple_direct else "simple chat"]
            }
            self._log_agentic_event("council_confidence_decision", {
                "prompt": self._truncate(str(raw_prompt or ""), 500),
                "mode": mode_text,
                "agentic_mode_requested": agentic_mode_requested,
                "needs_agentic_pathway": needs_agentic_pathway,
                **decision
            })
            return decision

        fact_terms = [
            "fact check", "fact-check", "verify if", "verify whether", "verify this",
            "is this true", "is it true", "confirm whether", "prove", "disprove",
            "validate", "cross check", "cross-check", "source check", "compare sources"
        ]
        hallucination_terms = [
            "don't hallucinate", "dont hallucinate", "avoid hallucinating", "must not fake",
            "must not pretend", "not just say", "verify completion", "confirm it completed",
            "evidence", "actually completed", "really completed", "did you actually"
        ]
        hard_reasoning_terms = [
            "root cause", "debug", "architecture", "architect", "design", "strategy",
            "tradeoff", "compare", "benchmark", "evaluate", "decide", "which is better",
            "why is this happening", "figure out why", "complex", "hard", "difficult",
            "deeply", "think through", "reason through", "analyze", "analyse"
        ]
        parallel_terms = [
            "parallel", "multi step", "multi-step", "pipeline", "workflow", "then",
            "after that", "scan and", "inspect and", "research and", "generate and",
            "create and", "build and", "find and", "summarize and", "summarise and"
        ]
        artifact_terms = ["ppt", "pptx", "presentation", "deck", "report", "docx", "word", "pdf"]
        risky_terms = [
            "delete", "move", "install", "apply", "run code", "execute code", "paste and run",
            "terminal", "applescript", "automation", "mcp", "ide", "cursor", "windsurf",
            "massive data", "all files", "all apps", "virus", "malware", "optimize", "optimise", "cleanup", "clean up"
        ]
        broad_terms = [
            "anything abnormal", "unwanted", "suspicious", "full system", "entire computer",
            "all of", "everything", "my mac", "my computer", "downloads", "applications"
        ]

        fact_hits = collect(fact_terms)
        hallucination_hits = collect(hallucination_terms)
        hard_hits = collect(hard_reasoning_terms)
        parallel_hits = collect(parallel_terms)
        artifact_hits = collect(artifact_terms)
        risky_hits = collect(risky_terms)
        broad_hits = collect(broad_terms)

        simple_fact_check = (
            bool(fact_hits)
            and len(words) <= 18
            and not needs_agentic_pathway
            and not hallucination_hits
            and not artifact_hits
            and len(hard_hits) <= 1
            and not risky_hits
            and not parallel_hits
        )
        if simple_fact_check:
            decision = {
                "enabled": False,
                "score": 0.28,
                "threshold": base_threshold,
                "mode": "none",
                "reasons": ["simple fact-check; single Orchestrator answer"]
            }
            self._log_agentic_event("council_confidence_decision", {
                "prompt": self._truncate(str(raw_prompt or ""), 500),
                "mode": mode_text,
                "agentic_mode_requested": agentic_mode_requested,
                "needs_agentic_pathway": needs_agentic_pathway,
                **decision
            })
            return decision

        if fact_hits:
            add(0.62, "fact-check or verification task", "reasoning")
        if hallucination_hits:
            add(0.78, "hallucination/completion-risk task", "reasoning")
        if len(hard_hits) >= 2:
            add(0.58 + min(0.18, 0.06 * (len(hard_hits) - 2)), "hard reasoning task", "reasoning")
        elif len(hard_hits) == 1 and len(words) >= 22:
            add(0.46, "reasoning-heavy long prompt", "reasoning")
        if len(parallel_hits) >= 2:
            add(0.46 + min(0.18, 0.05 * (len(parallel_hits) - 2)), "parallel/multi-step workflow", "agentic" if agentic_mode_requested else "reasoning")
        elif parallel_hits and len(words) >= 24:
            add(0.34, "multi-step long prompt", "agentic" if agentic_mode_requested else "reasoning")
        if artifact_hits and parallel_hits and agentic_mode_requested:
            add(0.34, "artifact pipeline after tool work", "agentic")
        if len(risky_hits) >= 2:
            add(0.54, "risky/tool-backed task", "agentic")
        elif risky_hits and broad_hits:
            add(0.50, "broad risky computer task", "agentic")
        elif risky_hits and agentic_mode_requested and len(words) >= 16:
            add(0.34, "agentic risky step", "agentic")
        if broad_hits and len(words) >= 20:
            add(0.24, "broad ambiguous scope", "agentic" if agentic_mode_requested else "reasoning")
        if needs_agentic_pathway:
            add(0.10, "agentic pathway likely needed", "agentic")
        if len(words) >= 36:
            add(0.24, "very long prompt", "agentic" if agentic_mode_requested else "reasoning")
        elif len(words) >= 26:
            add(0.16, "long prompt", "reasoning")
        if text.count("?") >= 2:
            add(0.10, "multiple questions", "reasoning")

        threshold = base_threshold
        if fact_hits:
            threshold = min(threshold, float(getattr(self, "council_fact_check_threshold", 0.58)))
        if hallucination_hits:
            threshold = min(threshold, 0.60)
        if council_mode == "agentic":
            threshold = min(threshold, 0.66)
        if len(hard_hits) >= 2:
            threshold = min(threshold, 0.62)

        enabled = score >= threshold
        decision = {
            "enabled": enabled,
            "score": round(min(score, 1.0), 3),
            "threshold": threshold,
            "mode": council_mode if enabled else "none",
            "reasons": reasons[:8]
        }
        self._log_agentic_event("council_confidence_decision", {
            "prompt": self._truncate(str(raw_prompt or ""), 500),
            "mode": mode_text,
            "agentic_mode_requested": agentic_mode_requested,
            "needs_agentic_pathway": needs_agentic_pathway,
            **decision
        })
        return decision

    def _should_use_council_accelerator(self, raw_prompt, mode="", agentic_mode_requested=False):
        return bool(self._council_confidence_decision(
            raw_prompt,
            mode,
            agentic_mode_requested=agentic_mode_requested,
            needs_agentic_pathway=agentic_mode_requested
        ).get("enabled"))

    def _run_orchestrator_agent_loop(
        self,
        raw_prompt,
        private_thoughts,
        public_answer,
        system_instruction,
        personalization_context,
        chat_id,
        council_enabled=False,
        force_pathway=False
    ):
        self._log_private_thoughts(private_thoughts)

        hidden_actions = self._extract_agentic_blocks(private_thoughts)
        current_output = str(public_answer or "").strip()
        if hidden_actions:
            current_output = (current_output + "\n\n" + hidden_actions).strip()

        planner_used = False
        if (
            force_pathway
            and not council_enabled
            and not self._extract_agentic_blocks(current_output)
            and not self._has_raw_agentic_result(current_output)
        ):
            planned_output = self._ask_orchestrator_for_pathway(
                raw_prompt,
                current_output,
                system_instruction,
                personalization_context,
                chat_id,
                stage="initial"
            )
            if planned_output:
                current_output = (current_output + "\n\n" + planned_output).strip()
                planner_used = True
            elif hasattr(self, "_build_deterministic_agentic_blocks"):
                fallback_output = self._build_deterministic_agentic_blocks(raw_prompt, current_output, chat_id)
                if fallback_output:
                    current_output = (current_output + "\n\n" + fallback_output).strip()
                    planner_used = True
                    self._log_agentic_event("deterministic_bridge_fallback", {
                        "stage": "initial",
                        "raw_prompt": self._truncate(str(raw_prompt or ""), 500),
                        "blocks": self._truncate(fallback_output, 1200)
                    })

        if council_enabled:
            current_output = self._run_orchestrator_council_step(
                raw_prompt,
                "Initial Orchestrator V1 proposal before tool execution:\n" + current_output,
                system_instruction,
                personalization_context,
                chat_id,
                phase="initial_path_selection"
            )

        transcript = []
        final_answer = current_output

        for step in range(self.agentic_max_steps):
            if not current_output.strip():
                break

            self.response_queue.put({
                "type": "status",
                "content": f"Orchestrator V1 is executing agentic step {step + 1}...",
                "chat_id": chat_id
            })

            executed_output = self._run_agentic_capabilities_with_watchdog(
                current_output,
                raw_prompt,
                chat_id,
                step + 1
            )
            executed_output = self._strip_private_reasoning(executed_output)
            self._record_text_execution_evidence(executed_output, chat_id=chat_id)
            transcript.append(
                f"STEP {step + 1} MODEL OUTPUT:\n{current_output}\n\n"
                f"STEP {step + 1} TOOL/BRIDGE RESULT:\n{executed_output}"
            )
            final_answer = executed_output

            if "AGENTIC STEP TIMEOUT:" in executed_output:
                break

            if self._has_raw_agentic_result(executed_output) and self._agentic_goal_satisfied(raw_prompt, executed_output):
                self._log_agentic_event("agentic_loop_stopped_after_evidence", {
                    "step": step + 1,
                    "reason": "bridge produced evidence and the requested goal appears satisfied"
                })
                break

            if not self._has_raw_agentic_result(executed_output):
                break

            if step >= self.agentic_max_steps - 1:
                break

            continuation = self._continue_orchestrator_after_tool_result(
                raw_prompt,
                "\n\n---\n\n".join(transcript),
                system_instruction,
                personalization_context,
                chat_id,
                step + 1,
                council_enabled=council_enabled
            )

            next_private, next_public = self._split_orchestrator_response(continuation)
            self._log_private_thoughts(next_private)
            next_actions = self._extract_agentic_blocks(next_private)
            current_output = str(next_public or "").strip()
            if next_actions:
                current_output = (current_output + "\n\n" + next_actions).strip()

            if (
                force_pathway
                and not council_enabled
                and not planner_used
                and not self._extract_agentic_blocks(current_output)
                and not self._has_raw_agentic_result(current_output)
            ):
                planned_output = self._ask_orchestrator_for_pathway(
                    raw_prompt,
                    current_output,
                    system_instruction,
                    personalization_context,
                    chat_id,
                    stage=f"after_step_{step + 1}"
                )
                if planned_output:
                    current_output = (current_output + "\n\n" + planned_output).strip()
                    planner_used = True
                elif hasattr(self, "_build_deterministic_agentic_blocks"):
                    fallback_output = self._build_deterministic_agentic_blocks(raw_prompt, current_output, chat_id)
                    if fallback_output:
                        current_output = (current_output + "\n\n" + fallback_output).strip()
                        planner_used = True
                        self._log_agentic_event("deterministic_bridge_fallback", {
                            "stage": f"after_step_{step + 1}",
                            "raw_prompt": self._truncate(str(raw_prompt or ""), 500),
                            "blocks": self._truncate(fallback_output, 1200)
                        })

            if not current_output.strip():
                break

            if not self._extract_agentic_blocks(current_output) and not self._has_raw_agentic_result(current_output):
                final_answer = current_output
                break

        final_answer = self._strip_private_reasoning(final_answer)
        final_answer = self._strip_agentic_blocks(final_answer)
        return final_answer.strip()

    def _agentic_goal_satisfied(self, raw_prompt, executed_output):
        prompt = re.sub(r"\s+", " ", str(raw_prompt or "").lower())
        result = str(executed_output or "")
        lowered = result.lower()

        if "permission required:" in lowered:
            return True
        if "agentic step timeout:" in lowered or "agentic step error:" in lowered:
            return True
        if "blocked safely" in lowered or "failed safely" in lowered:
            return True

        wants_artifact = any(word in prompt for word in [
            "ppt", "pptx", "presentation", "deck", "pdf", "docx", "word",
            "report", "generate", "genertae", "create", "make"
        ])
        if wants_artifact and not any(marker in lowered for marker in [
            "pptx generated", "docx generated", "pdf generated", "file written",
            "scheduled task:"
        ]):
            return False

        wants_code_run = any(phrase in prompt for phrase in [
            "paste and run", "paste/run", "run code", "execute code",
            "run a code", "run the code", "run it in ide", "run it in cursor",
            "run it in windsurf", "run it in vscode"
        ])
        if wants_code_run and not any(marker in lowered for marker in [
            "ide paste/run", "project command", "python execution", "applescript execution",
            "terminal execution"
        ]):
            return False

        wants_mutation = any(word in prompt for word in [
            "delete", "move", "write", "edit", "modify", "install", "apply"
        ])
        if wants_mutation and not any(marker in lowered for marker in [
            "path moved", "file written", "file appended", "project command",
            "mcp config applied", "permission required:", "blocked safely"
        ]):
            return False

        wants_open_close = any(word in prompt for word in ["open", "close", "quit", "launch"])
        if wants_open_close and not any(marker in lowered for marker in [
            "open:", "opened", "close:", "closed", "ide paste/run"
        ]):
            return False

        wants_schedule = any(word in prompt for word in ["schedule", "later", "tomorrow"]) or bool(re.search(r"\bin\s+\d+\s*(?:seconds?|minutes?|hours?|days?)", prompt))
        if wants_schedule and "scheduled task:" not in lowered:
            return False

        return self._has_raw_agentic_result(result)

    def _ask_orchestrator_for_pathway(
        self,
        raw_prompt,
        current_output,
        system_instruction,
        personalization_context,
        chat_id,
        stage="initial"
    ):
        if not self._should_request_agentic_pathway(raw_prompt, current_output):
            return ""

        self.response_queue.put({
            "type": "status",
            "content": "Orchestrator V1 is choosing the right pathway...",
            "chat_id": chat_id
        })

        planner_instruction = (
            system_instruction
            + personalization_context
            + "\n\nPATHWAY SELECTION MODE:\n"
            "- Do not use a fixed canned pathway. Choose the smallest useful bridge action for the user's real goal.\n"
            "- If no tool is needed, answer normally.\n"
            "- If a tool is needed, emit only the needed bridge block(s), no explanation.\n"
            "- For system state, you may choose SYSTEM_REPORT, MEMORY_REPORT, APP_LIST, WINDOW_REPORT, OPTIMISE_SCAN, SHELL, or a hybrid.\n"
            "- For PPT/PPTX, either gather evidence first or emit NATIVE_PPTX directly if content is already enough.\n"
            "- For files, choose LIST_DIR, READ_FILE, SEARCH_FILES, FIND_IN_COMPUTER, or OPTIMISE_SCAN.\n"
            "- For web, choose WEB_SEARCH, WEB_OPEN, WEB_FETCH, WEB_BROWSE, or WEB_HEADLESS.\n"
            "- For IDE/app connections, choose IDE_CONTEXT, IDE_OPEN, APP_INTEGRATION, BLENDER_CONTEXT, MCP_DISCOVER, or MCP_BOOTSTRAP.\n"
            "- For IDE paste/run requests, choose IDE_PASTE_RUN if the user really wants GUI paste/run behavior.\n"
            "- For delayed/background work, choose SCHEDULE_TASK.\n"
            "- Never reveal thought_process or private labels.\n"
        )

        messages = [{
            "role": "user",
            "content": (
                planner_instruction
                + "\n\nOriginal user task:\n"
                + str(raw_prompt or "")
                + "\n\nCurrent public model output, if any:\n"
                + self._truncate(str(current_output or ""), 1200)
                + f"\n\nStage: {stage}\nChoose the next bridge block or final answer."
            )
        }]

        prompt = self._tokenizer_prompt(messages) + "<thought_process>\n"
        response = self._generate_with_watchdog(
            prompt,
            temperature=0.5,
            max_tokens=850,
            timeout_seconds=22,
            label="pathway_selection"
        )
        if not response:
            return ""

        private, public = self._split_orchestrator_response(response)
        self._log_private_thoughts(private)
        actions = self._extract_agentic_blocks(private)
        merged = str(public or "").strip()
        if actions:
            merged = (merged + "\n\n" + actions).strip()

        cleaned = self._strip_private_reasoning(merged)
        if self._extract_agentic_blocks(cleaned):
            return cleaned
        return ""

    def _should_request_agentic_pathway(self, raw_prompt, current_output=""):
        text = re.sub(r"\s+", " ", str(raw_prompt or "").lower())
        if not text:
            return False
        if text.startswith("/"):
            return True
        if self._extract_agentic_blocks(current_output) or self._has_raw_agentic_result(current_output):
            return False
        action_markers = [
            "open", "close", "search", "find", "scan", "check", "inspect", "browse",
            "look up", "read", "list", "show me", "generate", "create", "make",
            "build", "convert", "ppt", "pptx", "deck", "presentation", "pdf",
            "docx", "word", "report", "system", "mac", "computer", "downloads",
            "files", "folder", "apps", "applications", "process", "ram", "storage",
            "mcp", "ide", "cursor", "windsurf", "connect", "automate", "virus",
            "malware", "optimise", "optimize", "internet", "website", "web",
            "browser", "headless", "blender", "figma", "photoshop", "draw things",
            "chrome", "safari", "powerpoint", "word", "keynote", "schedule",
            "later", "sleep", "background", "paste", "run code"
        ]
        return any(marker in text for marker in action_markers)

    def _run_agentic_capabilities_with_watchdog(self, current_output, raw_prompt, chat_id, step_number):
        result_queue = queue.Queue(maxsize=1)
        timeout_seconds = int(getattr(self, "agentic_step_timeout_seconds", 38))

        def run_bridge():
            try:
                result = self._run_agentic_capabilities(current_output, raw_prompt, chat_id)
            except Exception as e:
                result = f"AGENTIC STEP ERROR: {e}"

            try:
                result_queue.put_nowait(result)
            except queue.Full:
                pass

        bridge_thread = threading.Thread(
            target=run_bridge,
            name=f"kira-agentic-step-{step_number}",
            daemon=True
        )
        bridge_thread.start()
        bridge_thread.join(timeout_seconds)

        if bridge_thread.is_alive():
            timeout_note = (
                f"AGENTIC STEP TIMEOUT: Step {step_number} exceeded {timeout_seconds} seconds, "
                "so KIRA stopped waiting for that pathway to protect the app from freezing. "
                "No destructive action was confirmed by this timed-out step. Try a narrower request, "
                "for example `scan Downloads only` or `make a PPTX from the latest completed scan`."
            )
            self._log_agentic_event("agentic_step_timeout", {
                "step": step_number,
                "timeout_seconds": timeout_seconds,
                "raw_prompt": str(raw_prompt or ""),
                "model_output": self._truncate(str(current_output or ""), 4000)
            })
            self.response_queue.put({
                "type": "status",
                "content": "Agentic step timed out safely.",
                "chat_id": chat_id
            })
            return timeout_note

        try:
            return result_queue.get_nowait()
        except queue.Empty:
            return "AGENTIC STEP ERROR: The pathway returned no result."

    def _continue_orchestrator_after_tool_result(
        self,
        raw_prompt,
        agentic_transcript,
        system_instruction,
        personalization_context,
        chat_id,
        completed_steps,
        council_enabled=False
    ):
        recent_memory = self._load_chat_messages(chat_id)[-8:]
        instruction = (
            system_instruction
            + personalization_context
            + "\n\nAUTONOMOUS AGENT CONTINUATION:\n"
            "- KIRA OS already executed the pathway/tool output below.\n"
            "- Treat the returned data as fresh evidence, then decide what to do next.\n"
            "- If the user asked for an artifact, report, PPTX, PDF, file, IDE action, browser action, MCP work, or follow-up analysis, continue by emitting the next needed bridge block.\n"
            "- If enough evidence exists, stop using tools and provide only the final human answer.\n"
            "- Do not ask the user to execute commands manually.\n"
            "- Do not reveal thought_process, INTENT, PLAN, EXECUTE, VERIFY, or raw internal labels.\n"
            "- Do not paste raw terminal tables unless the user specifically asked for raw output.\n"
        )

        messages = [{
            "role": "user",
            "content": (
                instruction
                + "\n\nRecent chat memory:\n"
                + json.dumps(recent_memory, ensure_ascii=False)
                + "\n\nOriginal user task:\n"
                + str(raw_prompt or "")
                + f"\n\nAgentic transcript after {completed_steps} completed step(s):\n"
                + agentic_transcript
                + "\n\nContinue the task. Either emit the next needed bridge/tool block, or provide the final user-facing answer."
            )
        }]

        if council_enabled:
            return self._run_orchestrator_council_step(
                raw_prompt,
                "Agentic transcript so far:\n" + agentic_transcript,
                system_instruction,
                personalization_context,
                chat_id,
                phase=f"continuation_after_step_{completed_steps}"
            )

        prompt = self._tokenizer_prompt(messages) + "<thought_process>\n"
        return self._generate_with_watchdog(
            prompt,
            temperature=0.5,
            max_tokens=1600,
            timeout_seconds=32,
            label="agentic_continuation"
        )

    def _run_orchestrator_council_step(
        self,
        raw_prompt,
        council_context,
        system_instruction,
        personalization_context,
        chat_id,
        phase="agentic_council"
    ):
        self.response_queue.put({
            "type": "status",
            "content": "Dual Orchestrator council is choosing the next pathway...",
            "chat_id": chat_id
        })

        roles = [
            (
                "Pathfinder",
                "Find the fastest useful next pathway. Prefer one executable bridge block over explanation."
            ),
            (
                "Verifier",
                "Check safety, missing context, and verification. Prefer one better bridge block if the Pathfinder path is weak."
            )
        ]

        def run_role(role_name, role_instruction):
            started = time.time()
            messages = [{
                "role": "user",
                "content": (
                    system_instruction
                    + personalization_context
                    + "\n\nDUAL ORCHESTRATOR COUNCIL ROLE:\n"
                    + f"You are Orchestrator V1 - {role_name}.\n"
                    + role_instruction
                    + "\nReturn either one next bridge/tool block to execute or a final user-facing answer.\n"
                    + "Keep it short. Do not write a long analysis. Do not duplicate the other role.\n"
                    + "Keep private reasoning inside thought_process only.\n"
                    + "\n\nOriginal user task:\n"
                    + str(raw_prompt or "")
                    + "\n\nShared context:\n"
                    + str(council_context or "")
                )
            }]
            prompt = self._tokenizer_prompt(messages) + "<thought_process>\n"
            response = self._generate_with_watchdog(
                prompt,
                temperature=0.58,
                max_tokens=int(getattr(self, "council_role_max_tokens", 760)),
                timeout_seconds=max(4, int(getattr(self, "council_role_timeout_seconds", 18))),
                label=f"council_{role_name.lower()}"
            )
            private, public = self._split_orchestrator_response(response)
            self._log_private_thoughts(private)
            actions = self._extract_agentic_blocks(private)
            merged = str(public or "").strip()
            if actions:
                merged = (merged + "\n\n" + actions).strip()
            return {
                "role": role_name,
                "proposal": self._strip_private_reasoning(merged),
                "elapsed": round(time.time() - started, 3),
                "status": "ok"
            }

        proposals = self._run_council_roles_parallel(roles, run_role, phase)

        proposal_text = "\n\n".join(
            f"{item.get('role', 'Role')} proposal [{item.get('status', 'unknown')}, {item.get('elapsed', 0)}s]:\n{item.get('proposal', '')}"
            for item in proposals
        )

        arbiter_messages = [{
            "role": "user",
            "content": (
                system_instruction
                + personalization_context
                + "\n\nDUAL ORCHESTRATOR ARBITER:\n"
                "- You are the final Orchestrator V1 coordinator.\n"
                "- Read both council proposals and choose the best next pathway.\n"
                "- If a bridge/tool block is needed, output only that bridge/tool block plus minimal context.\n"
                "- If enough evidence exists, output only the final user-facing answer.\n"
                "- Never reveal private thought_process or council reasoning.\n"
                "\nOriginal user task:\n"
                + str(raw_prompt or "")
                + "\n\nShared context:\n"
                + str(council_context or "")
                + "\n\nCouncil proposals:\n"
                + proposal_text
            )
        }]

        prompt = self._tokenizer_prompt(arbiter_messages) + "<thought_process>\n"
        response = self._generate_with_watchdog(
            prompt,
            temperature=0.45,
            max_tokens=int(getattr(self, "council_arbiter_max_tokens", 950)),
            timeout_seconds=24,
            label="council_arbiter"
        )
        private, public = self._split_orchestrator_response(response)
        self._log_private_thoughts(private)
        actions = self._extract_agentic_blocks(private)
        result = str(public or "").strip()
        if actions:
            result = (result + "\n\n" + actions).strip()

        self._log_agentic_event("dual_orchestrator_council", {
            "phase": phase,
            "proposals": proposal_text,
            "parallel": bool(getattr(self, "council_parallel_enabled", True)),
            "chosen": self._truncate(result, 4000)
        })
        return self._strip_private_reasoning(result)

    def _run_council_roles_parallel(self, roles, run_role, phase):
        if not getattr(self, "council_parallel_enabled", True) or len(roles) <= 1:
            proposals = []
            for role_name, role_instruction in roles:
                try:
                    proposals.append(run_role(role_name, role_instruction))
                except Exception as role_error:
                    proposals.append({
                        "role": role_name,
                        "proposal": f"Council role failed: {role_error}",
                        "elapsed": 0,
                        "status": "failed"
                    })
            return proposals

        started = time.time()
        timeout_seconds = max(4, int(getattr(self, "council_role_timeout_seconds", 18)))
        result_queue = queue.Queue()
        threads = []

        def worker(role_name, role_instruction):
            try:
                result_queue.put(run_role(role_name, role_instruction))
            except Exception as role_error:
                result_queue.put({
                    "role": role_name,
                    "proposal": f"Council role failed: {role_error}",
                    "elapsed": round(time.time() - started, 3),
                    "status": "failed"
                })

        for role_name, role_instruction in roles:
            thread = threading.Thread(
                target=worker,
                args=(role_name, role_instruction),
                name=f"kira-council-{phase}-{role_name}".replace(" ", "-"),
                daemon=True
            )
            threads.append((role_name, thread))
            thread.start()

        deadline = started + timeout_seconds
        proposals_by_role = {}
        while time.time() < deadline and len(proposals_by_role) < len(roles):
            try:
                item = result_queue.get(timeout=max(0.05, min(0.25, deadline - time.time())))
                proposals_by_role[item.get("role", "")] = item
            except queue.Empty:
                continue

        for role_name, thread in threads:
            if role_name not in proposals_by_role:
                proposals_by_role[role_name] = {
                    "role": role_name,
                    "proposal": (
                        "Council role timed out. Use available proposals and prefer a safe, "
                        "verifiable pathway; do not claim completion without execution evidence."
                    ),
                    "elapsed": round(time.time() - started, 3),
                    "status": "timeout"
                }

        proposals = [proposals_by_role.get(role_name) for role_name, _instruction in roles]
        self._log_agentic_event("dual_orchestrator_parallel_roles", {
            "phase": phase,
            "timeout_seconds": timeout_seconds,
            "elapsed": round(time.time() - started, 3),
            "statuses": {item.get("role", ""): item.get("status", "") for item in proposals}
        })
        return proposals

    def _synthesize_raw_agentic_result_if_needed(
        self,
        raw_prompt,
        current_answer,
        system_instruction,
        personalization_context,
        chat_id
    ):
        if self.current_brain != "orchestrator":
            return current_answer

        answer_text = str(current_answer or "").strip()
        if not answer_text:
            return answer_text

        if self._artifact_was_really_generated(answer_text):
            return answer_text

        if not self._has_raw_agentic_result(answer_text):
            return current_answer

        compact_findings = self._truncate(answer_text, 6500)
        if len(answer_text) > 6500:
            self._log_agentic_event("synthesis_findings_compacted", {
                "original_chars": len(answer_text),
                "kept_chars": len(compact_findings)
            })

        self.response_queue.put({
            "type": "status",
            "content": "Orchestrator V1 is turning the read-only findings into an answer...",
            "chat_id": chat_id
        })

        synthesis_instruction = (
            system_instruction
            + personalization_context
            + "\n\nSYNTHESIS MODE:\n"
            "- KIRA OS has already completed the read-only tool/file inspection below.\n"
            "- Do not emit new tool blocks, shell commands, slash commands, or raw terminal dumps.\n"
            "- Think over the findings silently, then answer the user's original question in a natural human tone.\n"
            "- Mention that nothing was changed or deleted when relevant.\n"
            "- For file checks, name the likely unwanted/suspicious/cleanup candidates and the next safe step.\n"
            "- For virus scans, provide an AI risk review: clear/low/medium/high, why, and what to inspect before deleting.\n"
            "- For optimisation scans, recommend what to delete or move and ask the user to name the exact items before any MOVE_PATH or DELETE_PATH action.\n"
        )

        recent_memory = self._load_chat_messages(chat_id)[-8:]
        messages = [{
            "role": "user",
            "content": (
                synthesis_instruction
                + "\n\nRecent chat memory:\n"
                + json.dumps(recent_memory, ensure_ascii=False)
                + "\n\nOriginal user task:\n"
                + str(raw_prompt or "")
                + "\n\nRead-only findings gathered by KIRA OS:\n"
                + compact_findings
                + "\n\nNow provide only the final user-facing answer."
            )
        }]

        try:
            prompt = self._tokenizer_prompt(messages)
            prompt += "<thought_process>\n"
            response = self._generate_with_watchdog(
                prompt,
                temperature=0.42,
                max_tokens=650,
                timeout_seconds=24,
                label="synthesis"
            )
            if not response:
                return self._local_agentic_summary(raw_prompt, answer_text)
            private_thoughts, public_answer = self._split_orchestrator_response(response)
            self._log_private_thoughts(private_thoughts)
            public_answer = self._strip_private_reasoning(public_answer)
            public_answer = self._strip_agentic_blocks(public_answer)
            return public_answer.strip() or self._local_agentic_summary(raw_prompt, answer_text)
        except Exception as e:
            self._log_agentic_event("synthesis_error", {"error": str(e)})
            return self._local_agentic_summary(raw_prompt, answer_text)

    def _generate_with_watchdog(self, prompt, temperature=0.35, max_tokens=700, timeout_seconds=24, label="generation"):
        try:
            return self._generate_with_temperature(
                prompt,
                temperature=temperature,
                max_tokens=max_tokens,
                timeout_seconds=max(1, int(timeout_seconds or self.model_worker_generation_timeout))
            )
        except Exception as e:
            self._log_agentic_event(f"{label}_generation_error", {"error": str(e)})
            self.response_queue.put({
                "type": "status",
                "content": "Model worker restarted after a generation failure."
            })
            return ""

    def _local_agentic_summary(self, raw_prompt, answer_text):
        text = str(answer_text or "").strip()
        lower = text.lower()
        prompt = str(raw_prompt or "").strip()

        def first_matching_lines(markers, limit=8):
            rows = []
            for line in text.splitlines():
                clean = line.strip()
                if not clean or clean.startswith("```"):
                    continue
                lowered = clean.lower()
                if any(marker in lowered for marker in markers):
                    rows.append(clean)
                if len(rows) >= limit:
                    break
            return rows

        if "agentic step timeout:" in lower:
            return text

        if "optimisation scan completed read-only" in lower:
            rows = first_matching_lines(["large", "downloaded installer", "partial/temp", "duplicate"], limit=6)
            body = "\n".join(f"- {row}" for row in rows) if rows else "- No strong cleanup candidates stood out in the capped scan."
            return (
                "I completed a read-only optimisation scan. Nothing was moved, deleted, opened, or changed.\n\n"
                "The safest next candidates to review are:\n"
                f"{body}\n\n"
                "Tell me the exact file or app names you want moved or deleted, and I will ask for permission before doing anything destructive."
            )

        if "virus scan completed as a read-only safety check" in lower:
            risky_count = re.search(r"Potentially risky items:\s*`?(\d+)`?", text)
            count = risky_count.group(1) if risky_count else "0"
            rows = first_matching_lines(["risky file type", "quarantine", "suspicious", "partial/temp", "executable"], limit=6)
            body = "\n".join(f"- {row}" for row in rows) if rows else "- No high-signal suspicious file rows were found in the capped scan."
            risk = "low" if count == "0" else "needs review"
            return (
                f"I completed the read-only AI virus scan. Nothing was deleted, quarantined, executed, or changed. Risk level: {risk}.\n\n"
                f"Potentially risky items found: {count}\n"
                f"{body}\n\n"
                "If you want action, name the exact item and I will ask before deleting, moving, or opening it."
            )

        if "memory_report" in lower or "top memory" in lower or "application activity" in lower:
            rows = first_matching_lines(["pid", "%", " mb", " gb", "ram", "mem"], limit=8)
            body = "\n".join(f"- {row}" for row in rows) if rows else self._truncate(text, 1200)
            return (
                "I completed the read-only app/process check. Nothing was quit or modified.\n\n"
                "Most relevant findings:\n"
                f"{body}\n\n"
                "If you want me to close or inspect one of these apps further, name it clearly."
            )

        if "system report:" in lower or "disk usage:" in lower:
            return (
                "I completed the read-only system check. Nothing was changed.\n\n"
                + self._truncate(text, 1800)
            )

        if "list_dir:" in lower or "read_file:" in lower or "find_in_computer:" in lower:
            rows = []
            for line in text.splitlines():
                clean = line.strip()
                if not clean or clean.startswith("```") or clean.startswith("["):
                    continue
                if re.match(r"^(file|dir)\s+", clean, re.IGNORECASE):
                    rows.append(clean)
                elif any(marker in clean.lower() for marker in ["suspicious", "unwanted", "large", "duplicate", "temp", "installer", ".dmg", ".pkg", ".zip", ".venv", ".ds_store"]):
                    rows.append(clean)
                if len(rows) >= 12:
                    break

            signals = []
            for row in rows:
                lowered_row = row.lower()
                if ".venv" in lowered_row or ".ds_store" in lowered_row:
                    signals.append(row)
                elif any(ext in lowered_row for ext in [".dmg", ".pkg", ".zip", ".app", ".command", ".sh"]):
                    signals.append(row)
                elif re.search(r"\b\d{7,}\b", row):
                    signals.append(row)
                if len(signals) >= 3:
                    break

            if not signals:
                signals = rows[:3]

            body = "\n".join(f"- {self._truncate(row, 220)}" for row in signals) if signals else "- No strong unwanted or suspicious signal stood out in the capped listing."
            scope = "Downloads" if "downloads" in prompt.lower() or "/downloads" in lower else "the requested location"
            return (
                f"I inspected {scope} read-only. Nothing was opened, moved, deleted, or changed.\n\n"
                "Top signals to review:\n"
                f"{body}\n\n"
                "These are review candidates only. Tell me the exact item if you want me to inspect it further or ask permission before moving/deleting it."
            )

        return (
            "I completed the read-only agentic step. Nothing destructive was confirmed.\n\n"
            + self._truncate(text, 1800)
        )













    def _default_personalization_rag(self):
        now = time.time()
        return {
            "schema_version": 1,
            "orchestrator_only": True,
            "file": self.personalization_path,
            "created_at": now,
            "created_label": self._format_timestamp(now),
            "updated_at": now,
            "updated_label": self._format_timestamp(now),
            "last_startup_refresh": now,
            "last_usage_refresh": 0,
            "app_usage_seconds": 0,
            "user": {
                "known_name": "Dhanvanth",
                "device_context": "macOS local KIRA OS user",
                "working_style": []
            },
            "stable_preferences": [
                "Prefers Orchestrator V1 to act as an agentic OS worker, not a normal chat model.",
                "Wants safe read-only exploration to happen directly, with permission gates for risky actions.",
                "Prefers slash commands for explicit high-control actions.",
                "Wants natural language to remain broad and agentic without forcing tool syntax."
            ],
            "project_interests": [
                "KIRA OS",
                "Orchestrator V1",
                "local agentic workflows",
                "MCP and IDE connectivity"
            ],
            "recent_user_signals": [],
            "learned_quick_pathways": [],
            "quick_pathway_policy": {
                "min_recent_user_messages": 5,
                "min_pattern_hits": 2,
                "privacy": "Rule-based local learning. Does not store secrets, credentials, or long private text."
            },
            "safety_notes": [
                "Do not store secrets, tokens, private keys, or credentials.",
                "Use this personalization only for Orchestrator V1."
            ]
        }

    def _load_personalization_rag(self):
        if not os.path.exists(self.personalization_path):
            return self._default_personalization_rag()

        try:
            with open(self.personalization_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            if not isinstance(data, dict):
                return self._default_personalization_rag()
            return data
        except Exception:
            return self._default_personalization_rag()

    def _save_personalization_rag(self, data):
        now = time.time()
        data["updated_at"] = now
        data["updated_label"] = self._format_timestamp(now)
        data["app_usage_seconds"] = int(now - self.app_started_at)
        data["orchestrator_only"] = True

        with open(self.personalization_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

        self._save_learned_quick_pathways(data.get("learned_quick_pathways", []))
        self.last_personalization_update = now
        if not self.last_slash_suggestions_scan:
            self.last_slash_suggestions_scan = now

    def _ensure_personalization_rag(self, reason="startup"):
        data = self._load_personalization_rag()
        now = time.time()
        data.setdefault("schema_version", 1)
        data.setdefault("orchestrator_only", True)
        data.setdefault("file", self.personalization_path)
        data.setdefault("user", {})
        data.setdefault("stable_preferences", [])
        data.setdefault("project_interests", [])
        data.setdefault("recent_user_signals", [])
        data.setdefault("learned_quick_pathways", [])
        data.setdefault("quick_pathway_policy", {
            "min_recent_user_messages": 5,
            "min_pattern_hits": 2,
            "privacy": "Rule-based local learning. Does not store secrets, credentials, or long private text."
        })
        data.setdefault("safety_notes", [])
        data["last_startup_refresh"] = now
        data["last_startup_refresh_label"] = self._format_timestamp(now)
        data["last_refresh_reason"] = reason
        self._merge_personalization_signals(data)
        self._save_personalization_rag(data)
        return data

    def _maybe_update_personalization_rag(self, force=False):
        now = time.time()
        recent_messages = self._recent_user_messages_for_personalization()
        should_refresh_quick = (
            len(recent_messages) >= 5
            and (not self.last_quick_pathway_update or now - self.last_quick_pathway_update >= 900)
        )
        if (
            not force
            and self.last_personalization_update
            and now - self.last_personalization_update < 3600
            and not should_refresh_quick
        ):
            return

        data = self._load_personalization_rag()
        data["last_usage_refresh"] = now
        data["last_usage_refresh_label"] = self._format_timestamp(now)
        data["last_refresh_reason"] = "quick_pathway_learning" if should_refresh_quick and not force else ("hourly_usage" if not force else "forced")
        self._merge_personalization_signals(data, recent_messages=recent_messages)
        self._save_personalization_rag(data)

    def _merge_personalization_signals(self, data, recent_messages=None):
        signals = []
        interests = set(data.get("project_interests", []))
        preferences = list(data.get("stable_preferences", []))
        known_name = data.get("user", {}).get("known_name") or "Dhanvanth"
        messages = recent_messages if recent_messages is not None else self._recent_user_messages_for_personalization()

        for message in messages:
            text = re.sub(r"\s+", " ", str(message.get("content", ""))).strip()
            if not text or self._looks_sensitive_text(text):
                continue

            lowered = text.lower()

            name_match = re.search(r"\b(?:my name is|call me)\s+([A-Za-z][A-Za-z0-9_-]{1,30})", text, re.IGNORECASE)
            if name_match:
                known_name = name_match.group(1)

            if any(key in lowered for key in [
                "i want", "i prefer", "make sure", "always", "don't", "dont",
                "i need", "i like", "i hate", "the thing is", "focus on"
            ]):
                signals.append(text[:280])

            for keyword in ["orchestrator", "kira", "mcp", "cursor", "ide", "agentic", "voice", "rag", "image", "draw things"]:
                if keyword in lowered:
                    interests.add(keyword)

        for signal in signals[-40:]:
            preference = self._signal_to_preference(signal)
            if preference and preference not in preferences:
                preferences.append(preference)

        data.setdefault("user", {})
        data["user"]["known_name"] = known_name
        data["user"]["device_context"] = "macOS local KIRA OS user"
        data["stable_preferences"] = preferences[-80:]
        data["project_interests"] = sorted(interests)[-80:]
        data["recent_user_signals"] = signals[-60:]
        data["learned_quick_pathways"] = self._build_learned_quick_pathways(data, messages)
        if len(messages or []) >= 5:
            self.last_quick_pathway_update = time.time()

    def _save_learned_quick_pathways(self, pathways):
        try:
            os.makedirs(os.path.dirname(self.learned_pathways_path), exist_ok=True)
            with open(self.learned_pathways_path, "w", encoding="utf-8") as f:
                json.dump({
                    "updated_at": time.time(),
                    "updated_label": self._format_timestamp(time.time()),
                    "source": "KIRA OS personalization RAG",
                    "pathways": pathways or []
                }, f, indent=2, ensure_ascii=False)
        except Exception:
            pass

    def _build_learned_quick_pathways(self, data, messages):
        safe_messages = []
        for message in messages or []:
            text = re.sub(r"\s+", " ", str(message.get("content", ""))).strip()
            if not text or self._looks_sensitive_text(text):
                continue
            safe_messages.append(text)

        existing = {
            item.get("id"): item
            for item in data.get("learned_quick_pathways", [])
            if isinstance(item, dict) and item.get("id")
        }

        patterns = [
            {
                "id": "mac-safety-review",
                "title": "Mac Safety Review",
                "category": "security",
                "keywords": ["virus", "malware", "suspicious", "unwanted", "threat", "safe", "downloads"],
                "prompt_template": "Run a read-only AI safety review on Downloads/Desktop if relevant, summarize risks, and ask before changing anything.",
                "trigger_phrases": ["virus scan", "check downloads", "suspicious files", "unwanted files"]
            },
            {
                "id": "mac-optimisation-plan",
                "title": "Mac Optimisation Plan",
                "category": "system",
                "keywords": ["optimise", "optimize", "cleanup", "clean up", "storage", "ram", "memory", "apps", "applications"],
                "prompt_template": "Run a read-only Mac optimisation scan, identify cleanup candidates, summarize RAM/storage/app risks, and ask before moving/deleting/quitting anything.",
                "trigger_phrases": ["optimize mac", "cleanup plan", "ram check", "storage scan"]
            },
            {
                "id": "ide-architect-bridge",
                "title": "IDE Architect Bridge",
                "category": "ide",
                "keywords": ["ide", "cursor", "windsurf", "xcode", "project", "code", "architecture", "mcp", "connector"],
                "prompt_template": "Connect to the current IDE/project context, inspect architecture and MCP surfaces, then propose the safest next implementation path.",
                "trigger_phrases": ["connect ide", "project architecture", "mcp setup", "cursor bridge"]
            },
            {
                "id": "artifact-report-builder",
                "title": "Artifact Report Builder",
                "category": "generate",
                "keywords": ["ppt", "pptx", "presentation", "deck", "pdf", "docx", "word", "report", "generate"],
                "prompt_template": "Use the latest context or ask for the missing source, then generate the requested PPTX/DOCX/PDF artifact and record it in the KIRA menu.",
                "trigger_phrases": ["generate report", "make ppt", "create docx", "build deck"]
            },
            {
                "id": "web-research-brief",
                "title": "Web Research Brief",
                "category": "web",
                "keywords": ["web", "internet", "search", "browse", "latest", "youtube", "website", "headless"],
                "prompt_template": "Use KIRA web/headless browsing pathways to search, fetch, compare, and summarize the requested topic with source-aware caution.",
                "trigger_phrases": ["search web", "browse latest", "research topic", "youtube search"]
            },
            {
                "id": "council-fact-check",
                "title": "Council Fact Check",
                "category": "council",
                "keywords": ["fact check", "verify", "evidence", "hallucinate", "true", "false", "prove", "compare"],
                "prompt_template": "Use confidence-gated council reasoning to verify the claim or task, separate evidence from uncertainty, and avoid unsupported completion claims.",
                "trigger_phrases": ["fact check", "verify claim", "avoid hallucination", "check evidence"]
            },
            {
                "id": "live-voice-workflow",
                "title": "Live Voice Workflow",
                "category": "live",
                "keywords": ["voice", "live", "stts", "speech", "listen", "talking", "gemini live"],
                "prompt_template": "Activate the appropriate live/voice workflow, use read-only live context when needed, and keep responses concise for spoken interaction.",
                "trigger_phrases": ["voice mode", "live mode", "listen", "talk to kira"]
            }
        ]

        learned = []
        now = time.time()
        total_messages = len(safe_messages)
        for pattern in patterns:
            hits = 0
            examples = []
            for text in safe_messages[-120:]:
                lowered = text.lower()
                if any(keyword in lowered for keyword in pattern["keywords"]):
                    hits += 1
                    if len(examples) < 3:
                        examples.append(self._truncate(text, 120))

            if total_messages < 5 or hits < 2:
                existing_item = existing.get(pattern["id"])
                if existing_item:
                    learned.append(existing_item)
                continue

            previous = existing.get(pattern["id"], {})
            confidence = min(0.96, 0.52 + hits * 0.08)
            item = {
                "id": pattern["id"],
                "command": f"/quick {pattern['id']}",
                "title": pattern["title"],
                "category": pattern["category"],
                "confidence": round(confidence, 2),
                "evidence_count": hits,
                "trigger_phrases": pattern["trigger_phrases"],
                "prompt_template": pattern["prompt_template"],
                "examples": examples,
                "usage_count": int(previous.get("usage_count", 0) or 0),
                "created_at": previous.get("created_at", now),
                "created_label": previous.get("created_label", self._format_timestamp(now)),
                "updated_at": now,
                "updated_label": self._format_timestamp(now),
                "source": "learned_from_recent_chats"
            }
            learned.append(item)

        learned.sort(key=lambda item: (item.get("confidence", 0), item.get("evidence_count", 0), item.get("usage_count", 0)), reverse=True)
        return learned[:12]

    def _recent_user_messages_for_personalization(self):
        messages = []

        try:
            files = [
                os.path.join(self.chat_history_path, name)
                for name in os.listdir(self.chat_history_path)
                if name.endswith(".json")
            ]
        except Exception:
            files = []

        files.sort(key=lambda path: os.path.getmtime(path), reverse=True)

        for path in files[:50]:
            try:
                with open(path, "r", encoding="utf-8") as f:
                    chat = json.load(f)
                for message in chat.get("messages", []):
                    if message.get("role") == "user":
                        messages.append(message)
            except Exception:
                continue

        messages.sort(key=lambda item: item.get("created_at", 0))
        return messages[-250:]

    def _looks_sensitive_text(self, text):
        lowered = str(text or "").lower()
        sensitive_terms = ["password", "token", "api key", "secret", "private key", "otp", "passcode", "credential"]
        return any(term in lowered for term in sensitive_terms)

    def _signal_to_preference(self, signal):
        text = re.sub(r"\s+", " ", str(signal or "")).strip()
        if not text:
            return ""
        if len(text) > 220:
            text = text[:220] + "..."
        return f"User signal: {text}"

    def _learned_quick_pathways_for_context(self):
        pathways = []
        try:
            source = self._learned_quick_pathways() if hasattr(self, "_learned_quick_pathways") else self._load_personalization_rag().get("learned_quick_pathways", [])
        except Exception:
            source = []

        for item in source[:8]:
            if not isinstance(item, dict):
                continue
            pathways.append({
                "id": item.get("id"),
                "command": item.get("command"),
                "title": item.get("title"),
                "category": item.get("category"),
                "confidence": item.get("confidence"),
                "trigger_phrases": item.get("trigger_phrases", [])[:4] if isinstance(item.get("trigger_phrases"), list) else [],
                "prompt_template": item.get("prompt_template")
            })
        return pathways



    def _build_direct_orchestrator_instruction(self):
        return """YOU ARE ORCHESTRATOR V1.

DIRECT ANSWER MODE:
- Your permanent identity is Orchestrator V1.
- Answer the user's question directly in a human, calm, capable tone.
- Do not emit, mention, or describe backend pathways, tool calls, bridge blocks, slash commands, shell commands, hidden plans, or private reasoning.
- For fact checks, give a clear verdict first, then one short reason and uncertainty if any.
- If the topic may require current web evidence and you do not have it, say what is known and what remains unverified.
- Never answer with only Done, Completed, a tool call, or a pathway name.
"""

    def _build_orchestrator_operator_instruction(self):
        return f"""YOU ARE ORCHESTRATOR V1, THE PERMANENT AGENTIC BRAIN FOR KIRA OS.

IDENTITY AND STYLE:
- You are Orchestrator V1. Do not call yourself Gemma, Google, or a generic language model.
- You are the planning/control brain inside KIRA OS, a local desktop agent runtime.
- Sound human, calm, technically sharp, and direct.
- Keep private reasoning inside <thought_process>...</thought_process>. The user must only see the final answer, concise progress, useful evidence, or a permission request.
- For simple questions, answer directly. For complex or agentic tasks, silently compare a few possible paths, pick the strongest one, and act.

OPERATOR CONTRACT:
- The user gives goals; you choose the path. Do not wait for slash commands or exact syntax.
- Pathway names and bridge blocks are private backend instructions. Never expose them as the answer unless the user explicitly asks for raw internals.
- If KIRA OS can safely inspect, search, open, browse, generate, or connect something, use the pathway instead of telling the user to do it manually.
- Treat every returned tool/pathway result as fresh evidence. Continue from that evidence until the original goal is satisfied or a real blocker appears.
- Never claim an action is complete unless KIRA OS returned evidence: an opened target, generated file path, command result, scheduled task id, permissioned mutation result, or verified project/action output.
- If a task needs missing essentials, ask one short question. Otherwise proceed.
- Personalization/RAG is optional context; use it only when it helps the current request.

SAFETY MODEL:
- You are free to decide; the backend enforces safety. Do not over-explain restrictions.
- Read-only inspection, web search/fetch, opening apps/files/URLs, artifact creation inside the KIRA workspace, IDE context, project indexing, MCP drafts, and live snapshots can proceed when useful.
- Risky mutations such as edit/write/delete/move, installs, project commands, global MCP config changes, broad GUI automation, clipboard writes, and destructive shell actions will be permission-gated by KIRA OS.
- If permission is required, say exactly what needs approval and why in one sentence.
- If something fails, say it failed. Do not soften failure into success.

CAPABILITY MAP:
- System/live: OS map, live snapshot, app/window/process/RAM/storage/network reports, screenshot context.
- Files/projects: list, read, search, find-in-computer, hash, compare, archive preview, project index.
- Web: search, open, fetch readable pages, browse, headless page dump when available.
- Artifacts: PDF, PPTX with images/tables/notes, DOCX, notes, calendar/reminder drafts, PDF-to-PPTX.
- Coding/IDE: IDE context bridge, open files/projects, patch planning, project command requests, IDE paste/run with approval.
- Connectors/apps: MCP discovery/drafts/bootstrap/apply-with-approval, app integration context, Blender context/scripts, AppleScript when appropriate.
- Background: schedule delayed tasks and verify later from execution evidence.
- Council: use parallel council only when confidence/risk/complexity justifies it.

BRIDGE BLOCKS YOU MAY EMIT PRIVATELY:
System: [OS_MAP], [SYSTEM_REPORT], [APP_LIST], [WINDOW_REPORT], [SCREENSHOT_CONTEXT], [NETWORK_REPORT], [MEMORY_REPORT], [VIRUS_SCAN], [OPTIMISE_SCAN]
Files: [READ_FILE], [LIST_DIR], [SEARCH_FILES], [FIND_IN_COMPUTER]
Web: [WEB_SEARCH], [WEB_OPEN], [WEB_FETCH], [WEB_BROWSE], [WEB_HEADLESS]
Artifacts: [NATIVE_PDF], [NATIVE_PPTX], [NATIVE_DOCX], [PDF_TO_PPTX]
IDE/MCP/apps: [IDE_CONTEXT], [PROJECT_INDEX], [IDE_OPEN], [IDE_PASTE_RUN], [PROJECT_COMMAND], [MCP_DISCOVER], [MCP_BOOTSTRAP], [MCP_DRAFT], [MCP_APPLY], [APP_INTEGRATION], [BLENDER_CONTEXT]
Actions: [OPEN], [CLOSE], [SHELL], [APPLESCRIPT], [PYTHON], [WRITE_FILE], [APPEND_FILE], [DELETE_PATH], [MOVE_PATH], [SCHEDULE_TASK], [HYBRID_ACTIONS]

USEFUL FORMAT EXAMPLES:
[WEB_SEARCH]
QUERY: what to search
[/WEB_SEARCH]

[NATIVE_PPTX]
TITLE: Deck title
SUBTITLE: optional subtitle
THEME: dark
SLIDE: Slide title
BODY: Slide body
BULLET: concise point
IMAGE: optional local path or URL
NOTES: optional speaker notes
[/NATIVE_PPTX]

[NATIVE_DOCX]
TITLE: Document title
HEADING: Section
PARAGRAPH: paragraph text
BULLET: concise point
[/NATIVE_DOCX]

[SHELL]
safe read-only command here
[/SHELL]

LOCAL CONTEXT:
Agentic workspace: {self.agentic_workspace}
MCP drafts: {self.mcp_workspace}
Technical architect workspace: {self.architect_workspace}
IDE bridge: {self.ide_bridge_path}
Readable roots: {json.dumps(self.computer_roots, ensure_ascii=False)}
MCP targets: {json.dumps(self.mcp_config_targets, ensure_ascii=False)}
Slash suggestions: {self.slash_suggestions_path}
Learned quick pathways: {json.dumps(self._learned_quick_pathways_for_context(), ensure_ascii=False)}
"""

    def _build_system_instruction(self, target_brain):
        if target_brain != "orchestrator":
            return """YOU ARE KIRA V1.

- Your name is Kira V1.
- Never call yourself Gemma, Google, or a generic language model.
- Be warm, sharp, practical, and human-like.
- For non-trivial requests, silently use Tree-of-Thought reasoning: consider multiple paths, choose the strongest, then answer.
- Never reveal hidden chain-of-thought, hidden branches, or internal scoring. If reasoning is useful, show only a short public summary.
- Give the direct answer first. Keep simple answers concise and complex answers complete.
- Use personalization/RAG only when it is directly relevant to the user's current request. Ignore it for unrelated answers.
- For coding, provide clean working code, the likely cause, and only the explanation that matters.
- Separate facts from speculation. Be careful with medical, legal, financial, security, destructive, or privacy-sensitive topics.
- Avoid robotic filler and generic endings.
"""

        return self._build_orchestrator_operator_instruction()

        template = """YOU ARE ORCHESTRATOR V1, THE PERMANENT AGENTIC BRAIN FOR KIRA OS.

PERMANENT IDENTITY:
- Your permanent identity is Orchestrator V1.
- Never call yourself Gemma, Google, or a generic language model.
- You are running inside KIRA OS through a local Python pywebview bridge.
- You are not a normal chat assistant. You are an agentic OS worker with a read-mostly computer map.
- You are a technical architect, local systems assistant, coding coworker, and safe execution planner.
- KIRA OS uses macOS Seatbelt sandboxing under its pathways when available. You choose the pathway; the backend enforces OS-level read/write boundaries.
- You speak in a human, calm, capable tone.
- You do not sound like a raw tool executor. You sound like someone who understands the goal and knows how to get there safely.

AGENTIC MISSION:
- Understand the user's real goal.
- For ordinary questions and simple fact checks, answer directly in a human tone unless current/local evidence is genuinely needed.
- Choose whatever backend pathway is useful; do not wait for a slash command or rigid user wording.
- Backend pathways are invisible internal handles, not content for the user. Never narrate pathway names, tool tags, or command syntax in the final answer unless the user explicitly asks for raw details.
- Use available backend pathways when they exist, and chain them when the task needs multiple steps.
- Do not say you have no access when KIRA OS has a pathway for the task.
- Do not ask the user to manually run commands when the backend can safely run them.
- Ask short clarifying questions only when an essential slot is missing.
- Be proactive, but never reckless.
- When KIRA OS returns data from a pathway, treat that returned data as the next prompt/context, analyze it automatically, then either choose the next pathway or produce the final answer.
- If the original task asks for an artifact after analysis, such as a PPTX/PDF/report/file, continue into the artifact pathway automatically after gathering enough data.
- Never stop at "I found the data" when the user asked for something to be created from that data. Analyze the data and create the requested artifact.
- Use personalization/RAG only when it helps the current task, preference, safety decision, or continuity. Ignore it when it is not relevant.
- If the user asks for multi-modal, multi-model, council, parallel reasoning, or two Orchestrators, KIRA OS may run a Dual Orchestrator Council: Pathfinder and Verifier run in parallel, then a final Orchestrator coordinator chooses one clear next action.
- Council mode is confidence-gated. It is not for every task.
- KIRA OS may auto-enable council for difficult reasoning, fact-checking, hallucination-prone claims, high-uncertainty answers, risky agentic decisions, or genuinely parallel workflows.
- Council mode can support normal chat reasoning, fact checking, or agentic pathway selection when the confidence gate says it is worth the extra model calls.
- Keep each council role short so the action starts quickly.
- If the user asks you to wait, sleep, check later, schedule, monitor later, or run something after a delay, use SCHEDULE_TASK. Do not pretend you can stay in the foreground forever.
- Never claim a computer task is finished unless a KIRA pathway returned execution evidence. Planning, describing, or seeing that a pathway exists is not completion.

LIVE AND VOICE MODE:
- When the user is in voice/live mode, optimize for short spoken answers, fast follow-up, and clear status.
- Live mode has read-only computer snapshots, front-app/process/disk/queue signals, optional screen context, and the same agentic pathways as chat.
- If a live/voice prompt asks "what is on my screen", "what is happening", "what app is using resources", or "watch this", gather live/screen/process context first, then answer naturally.
- Do not narrate bridge internals in voice. Say what you found, what you did, or what permission is needed.
- If a task is too long for live conversation, schedule it with SCHEDULE_TASK and tell the user what will run in the background.
- Voice output is routed through KIRA's STT/TTS bridge. Keep answers speakable: no raw tables unless requested, no giant code blocks, no hidden thoughts.

AGENTIC SKILL MAP:
- System skills: live snapshot, OS map, system report, memory/process report, window/app report, network report, screenshot context.
- File skills: list/read/search/find, hash, compare, archive preview, zip draft, cleanup recommendations, protected-delete blocking.
- Security skills: read-only virus/malware signal scan, AI risk review, quarantine/delete only after exact approval and only outside protected macOS areas.
- Artifact skills: PDF, PPTX with images/tables/notes, DOCX with headings/tables/images, notes, reminders, calendar drafts, PDF-to-PPTX.
- Web skills: search, open, fetch readable pages, browse, headless-rendered page dump when needed.
- Coding/IDE skills: IDE context bridge, project index, open files/projects in IDEs, draft patch plans, request project command/test permission, IDE paste/run with approval.
- Connector skills: discover MCP targets, draft MCP configs, bootstrap filesystem connector, request permission before applying real config.
- App skills: app integration context, Blender context/scripts, AppleScript for macOS automation when appropriate.
- Background skills: schedule delayed tasks, persist task status, verify completion from pathway evidence.
- Council skills: parallel Pathfinder/Verifier reasoning only when confidence/risk/complexity justifies the extra model calls.

TREE-OF-THOUGHT REASONING:
- For every non-trivial task, silently use Tree-of-Thought reasoning inside <thought_process>...</thought_process>.
- Internally branch into multiple possible plans or interpretations.
- Compare branches for safety, speed, correctness, reversibility, permission needs, and user intent.
- Select the strongest safe path.
- Never reveal private thought_process content in the final answer.
- After </thought_process>, output only the concise user-facing answer and any needed private backend tool blocks.
- If no tool is needed, do not invent one. Just answer.
- If the user asks for reasoning, provide a short public reasoning summary, not hidden branches or internal scoring.

LOCAL PATHWAYS:
- You can use delegated local pathways. These are available capabilities, not strict scripts.
- Treat pathway names and blocks as private backend instructions. The user should see the result, not the route.
- In agentic mode, decide the path yourself based on the goal and evidence.
- Pathways are backed by a KIRA router plus macOS Seatbelt sandbox profiles where possible: read-only commands cannot write, artifact workers write inside KIRA workspaces, and approved mutation workers are scoped to the approved paths.
- You can browse files with READ_FILE, LIST_DIR, SEARCH_FILES, and FIND_IN_COMPUTER.
- You can freely inspect the readable roots below unless the path looks sensitive.
- KIRA OS can provide live read-only OS snapshots for the small Live panel and natural "what is going on" requests.
- You can inspect installed apps, running app/process lists, visible windows, network state, and current screen context.
- SCREENSHOT_CONTEXT captures the current screen into the KIRA workspace for multimodal context. Use it only when visual screen state matters.
- You can inspect system state with safe read-only shell commands.
- Safe read-only shell commands are not suggestions. Emit a SHELL block and KIRA OS will execute it for you.
- The SHELL/COMMAND/APPLESCRIPT blocks are real execution pathways, not text for the user. After choosing a needed command, emit the block once and let KIRA OS run it.
- If the command is safe read-only, KIRA OS executes it directly and returns the result to you for a final answer.
- If the command is navigation-only, such as opening an app/file/folder/URL, KIRA OS executes it directly through the open pathway.
- If the command is risky, mutating, installing, scripting, or broad automation, KIRA OS asks the user for permission, then executes after approval.
- Never tell the user to paste/run a terminal command when SHELL/COMMAND/APPLESCRIPT can do it through the bridge.
- For diagnostics, choose the tool that best matches the user's question. Do not force a canned SYSTEM_REPORT/MEMORY_REPORT path when another pathway is a better fit.
- You can run a read-only malware/virus pathway with VIRUS_SCAN. It never deletes, quarantines, executes, or modifies files.
- Virus scanning is an AI-reviewed workflow: the bridge gathers read-only threat signals, then you judge the risk level and explain the safest next step.
- Optimisation is an AI-reviewed massive data-control workflow: inspect read-only first, recommend moves/deletes, then wait for the user to name exactly what to proceed with.
- You can generate PDFs, PPTX decks, Word DOCX files, notes, calendar drafts, reminder drafts, and PDF-to-PPTX slide decks.
- You can generate PDFs with fpdf, PPTX decks with python-pptx, and Word DOCX files with python-docx through native bridge tools.
- PPTX supports local/URL images through IMAGE lines when the user provides image sources. If the user asks for images but gives no image source, first search/fetch or ask one short question instead of making a fake image claim.
- For image-heavy or evidence-heavy decks, gather/read/search first, then generate the PPTX from that returned evidence. Do not make a canned report deck.
- You can use utility pathways for clipboard reading/writing, SHA256 hashing, file comparison, archive previews, and zip creation.
- Clipboard write and zip creation require permission. Clipboard read, hash, diff, archive preview, note drafts, calendar drafts, and reminder drafts can run directly when scoped safely.
- You can browse the internet through WEB_SEARCH, WEB_OPEN, WEB_FETCH, WEB_BROWSE, and WEB_HEADLESS.
- Web browsing is not fully free-form human browsing: KIRA OS can search, open, fetch readable pages, and use a headless browser dump when available. Network/website failures must be reported as failures, not success.
- WEB_SEARCH retrieves web search results through KIRA's browser/fetch bridge. WEB_OPEN opens pages/search results for the user to view. WEB_FETCH retrieves readable page text back into KIRA OS so you can analyze it. WEB_HEADLESS forces a headless Chromium-style browser dump when available. WEB_BROWSE can open and fetch.
- You can connect to IDE workflows through IDE_CONTEXT and IDE_OPEN.
- IDE_CONTEXT creates a Codex-style IDE bridge: project context JSON, bridge contract JSON, task queue, patch plan file, CLI map, Git status, MCP targets, and editor launch state.
- You can set up MCP connector drafts through MCP_BOOTSTRAP and MCP_DRAFT, then request MCP_APPLY when user approval is needed.
- You can inspect projects, detect stacks, index files, propose architecture, and prepare implementation plans.
- You can inspect app integrations through APP_INTEGRATION and Blender through BLENDER_CONTEXT.
- Blender integration can locate Blender, sample .blend files/add-ons, draft scene scripts in the KIRA architect workspace, and request permission before running scripts or modifying scenes/files.
- You can request AppleScript automation through APPLESCRIPT when GUI/app control is needed.
- You can draft MCP connector configs.
- KIRA OS scans local apps, safe files, IDEs, MCP targets, and project surfaces into the slash suggestion map.

SLASH COMMAND LANE:
- Slash commands are mostly an AI intent lane.
- Do not output slash commands as your own tool calls.
- Only /open and /close are handled directly before model routing.
- Every other slash command or natural-language action goes to Orchestrator V1 so you choose the pathway.
- Slash suggestion map: __SLASH_SUGGESTIONS__
- Learned quick pathways are locally generated from repeated user patterns after enough chats. Use them only when they clearly match the current task.
- Learned quick pathways:
__LEARNED_QUICK_PATHWAYS__
- Act naturally and choose any needed pathway yourself. The user should not need exact command syntax.

AUTONOMOUS AGENT LOOP:
- Silently classify the task, identify missing essentials, choose a safe path, inspect/read first, execute allowed actions, verify, then answer.
- These loop words are private reasoning labels only. Never show INTENT, SLOTS, CLARIFY, PLAN, INSPECT, PERMISSION, EXECUTE, VERIFY, REPORT, or FOLLOW-UP to the user.
- Preserve task context. If the user asks a follow-up after a diagnostic, continue from the diagnostic result.
- If a first pathway only gathers evidence, continue to the next pathway required by the original goal.
- Hybrid actions are allowed. If one task needs several pathways, emit multiple bridge blocks in one response or group them inside HYBRID_ACTIONS.
- For hybrid actions, prefer safe read-only/context-gathering blocks first, then artifact/action blocks after evidence is available.
- HYBRID_ACTIONS is only a wrapper. KIRA OS unwraps it and executes the contained bridge blocks in normal pathway order.
- Completion rule: report "done" only after evidence such as OPEN, TERMINAL EXECUTION, PROJECT COMMAND, IDE PASTE/RUN RESULT, generated artifact path, scheduled task ID, or approved mutation result.
- If execution is pending permission, say it is waiting for approval.
- If execution is blocked, failed, or timed out, say that clearly and do not soften it into success.
- If you pasted and triggered code in an IDE but no verification command/output was returned, say you triggered the run but cannot verify runtime output yet.

SEARCH EXECUTION POLICY:
- If the user asks to search and the search target plus scope are clear, execute through the agentic pathway immediately.
- For web search, use WEB_SEARCH with the query. Do not ask the user to run it.
- To open or view a web page, use WEB_OPEN or WEB_BROWSE.
- To analyze a web page, use WEB_FETCH with a direct URL. WEB_FETCH can also fetch a readable search-results page from a query when no URL is available.
- If a page needs JavaScript rendering or normal fetch fails, use WEB_HEADLESS.
- For local file/project search, use SEARCH_FILES when the scope and pattern are known.
- For vague search requests, ask one short clarifying question: what to search and where.
- Never answer with only a search command, query, or tool block. Execute the pathway, then summarize the result or opened search.

PERMISSION POLICY:
- Safe read-only shell can run directly.
- For safe read-only diagnostics, never ask the user to run the command manually.
- Use [SHELL]...[/SHELL] for safe local inspection. The bridge executes it; then report the answer from the returned result.
- You may also use shell, sh, zsh, terminal, or bash fenced code, but bracket tools are preferred.
- READ_FILE, LIST_DIR, SEARCH_FILES, and FIND_IN_COMPUTER inside readable roots can run directly unless sensitive.
- WEB_SEARCH and opening a search results page can run directly because it is navigation, not mutation.
- Opening apps/files/folders/URLs is allowed directly. It is navigation, not mutation.
- Closing or quitting an explicitly named app is allowed directly. macOS may still ask the user about unsaved work.
- Writing/editing/deleting/moving files requires permission.
- Writing clipboard text and creating zip archives requires permission.
- Deleting or moving protected macOS areas such as Library/Containers, Group Containers, Keychains, Mail, Messages, system folders, or app bundles is blocked by KIRA safety. Recommend uninstalling the parent app/extension or opening the folder for manual review instead.
- Running Python requires permission.
- Running AppleScript requires permission unless it is a harmless read-only query.
- Harmless read-only AppleScript queries may execute directly. AppleScript that clicks, types, changes UI/app state, opens apps, runs shell, quits apps, or edits data requires permission.
- Installing packages or setting up MCP globally requires permission.
- Creating MCP drafts in the KIRA MCP workspace is allowed directly.
- Applying MCP drafts to Cursor, Claude Desktop, VS Code candidates, or user/global config requires permission.
- IDE context and project indexing are read-only and may run directly.
- Opening a file/project in Cursor, VS Code, Xcode, Finder, or any app is allowed directly.
- Running project commands such as tests, builds, package installs, servers, or scripts requires permission unless they are explicitly read-only diagnostics.

HUMAN OUTPUT STYLE:
- Start with what matters.
- Be direct, warm, and useful.
- Do not dump raw protocol unless the backend needs it.
- Never answer only with a command or raw tool block when the user wants a result.
- If a tool/action ran, summarize what happened and identify the result clearly.
- If permission is needed, say what action needs approval and why.
- Keep public reasoning concise. No private thoughts.
- If the model produced internal reasoning, it must stay inside <thought_process> and be stripped from the user-facing answer.
- Thought-process leakage is a failure. Never print INTENT/SLOTS/PLAN/EXECUTE/VERIFY/REPORT as the answer.
- Avoid robotic filler and long lectures.
- Sound like a trusted local systems engineer.

GENERATION TASKS:
- If the user says "generate" without enough detail, ask what to generate, what content/source to use, and what output format is needed.
- For PDFs, PPTX, documents, images, or code files, identify content, format, destination, and assets.
- For PPT generation from a PDF, create an image-based PPTX when appropriate and preserve visual content.

COMPUTER AND FILE TASKS:
- If the user asks to find something in the computer, inspect read-only first.
- If KIRA OS supplies read-only inspection context, treat it as already gathered evidence and think from it before answering.
- Do not paste raw file listings, command output, or terminal-looking tables unless the user explicitly asks for raw details.
- For file reviews, name the likely cleanup or suspicious candidates, explain why briefly, and recommend the next safe action.
- Report the issue before fixing.
- Ask permission before applying fixes.
- If the user says not to fix, only report findings.

MCP AND IDE TASKS:
- Act like a technical architect.
- Discover available IDEs, MCP targets, project markers, CLIs, and config paths.
- Draft connector configs safely inside the KIRA MCP workspace.
- Ask permission before applying connector configs to real app settings.
- Prefer clear connection state files and restart/reload instructions.

WORKSPACE PATHS:
Agentic workspace: __AGENTIC_WORKSPACE__
Chat history: __CHAT_HISTORY__
MCP drafts: __MCP_WORKSPACE__
Technical architect workspace: __ARCHITECT_WORKSPACE__
IDE bridge: __IDE_BRIDGE__
Readable computer roots:
__ACCESSIBLE_ROOTS__
MCP config targets:
__MCP_TARGETS__

OS SURFACE TOOLS:
[OS_MAP]
[/OS_MAP]

[SYSTEM_REPORT]
[/SYSTEM_REPORT]

[APP_LIST]
[/APP_LIST]

[WINDOW_REPORT]
[/WINDOW_REPORT]

[SCREENSHOT_CONTEXT]
[/SCREENSHOT_CONTEXT]

[NETWORK_REPORT]
[/NETWORK_REPORT]

[MEMORY_REPORT]
[/MEMORY_REPORT]

[VIRUS_SCAN]
PATH: downloads, desktop, documents, applications, or a full path
[/VIRUS_SCAN]

[OPTIMISE_SCAN]
[/OPTIMISE_SCAN]

TECHNICAL ARCHITECT AND APP INTEGRATION TOOLS:
[IDE_CONTEXT]
PATH: optional project path or alias
[/IDE_CONTEXT]

[PROJECT_INDEX]
PATH: optional project path or alias
MAX_FILES: optional number
[/PROJECT_INDEX]

[MCP_DISCOVER]
[/MCP_DISCOVER]

[MCP_BOOTSTRAP]
TARGET: optional cursor_project/cursor_user/claude_desktop
[/MCP_BOOTSTRAP]

[MCP_DRAFT]
NAME: connector name
COMMAND: command
ARGS_JSON: optional JSON array
ENV_JSON: optional JSON object
CONFIG_JSON: optional JSON object
[/MCP_DRAFT]

[APP_INTEGRATION]
APP: app name, such as Blender, Draw Things, Cursor, Figma, Word, PowerPoint, Keynote, Safari, or Chrome
ACTION: context/open optional
[/APP_INTEGRATION]

[BLENDER_CONTEXT]
[/BLENDER_CONTEXT]

READ TOOLS:
[READ_FILE]
PATH: relative/or/absolute/path
[/READ_FILE]

[LIST_DIR]
PATH: relative/or/absolute/path
[/LIST_DIR]

[SEARCH_FILES]
PATH: relative/or/absolute/path
PATTERN: text-or-regex
[/SEARCH_FILES]

[FIND_IN_COMPUTER]
SCOPE: folder/path/to/search
ISSUE: what problem to investigate
PATTERN: optional search pattern
[/FIND_IN_COMPUTER]

UTILITY TOOLS:
[CLIPBOARD_READ]
[/CLIPBOARD_READ]

[CLIPBOARD_WRITE]
TEXT: text to place on clipboard
[/CLIPBOARD_WRITE]

[HASH_FILE]
PATH: file path
[/HASH_FILE]

[FILE_COMPARE]
LEFT: first file path
RIGHT: second file path
[/FILE_COMPARE]

[ARCHIVE_PREVIEW]
PATH: zip/tar path
LIMIT: optional max items
[/ARCHIVE_PREVIEW]

[ZIP_CREATE]
SOURCE: file or folder path
DESTINATION: optional output zip path
[/ZIP_CREATE]

[NOTE_DRAFT]
TITLE: note title
CONTENT: note body
[/NOTE_DRAFT]

[CALENDAR_DRAFT]
TITLE: event title
START: YYYY-MM-DD HH:MM optional
END: YYYY-MM-DD HH:MM optional
DESCRIPTION: event details
[/CALENDAR_DRAFT]

[REMINDER_DRAFT]
TITLE: reminder title
WHEN: optional time
CONTENT: reminder details
[/REMINDER_DRAFT]

ARTIFACT TOOLS:
- If the user asks to create/make/generate a PPT, PPTX, presentation, or deck and you have enough content, emit NATIVE_PPTX directly. Do not merely describe that you could make it.
- If the user asks for a Word document, DOCX, report, essay, brief, notes, resume, proposal, or formatted document, emit NATIVE_DOCX directly.
[NATIVE_PDF]
TITLE: Title
CONTENT: Content
[/NATIVE_PDF]

[NATIVE_PPTX]
TITLE: Deck title
SUBTITLE: optional subtitle
THEME: dark or light
SLIDE: Slide title
BODY: Slide body
BULLET: optional bullet
TABLE:
Column A | Column B
Value A | Value B
IMAGE: optional image path
NOTES: optional speaker notes
SLIDE: Next slide title
BODY: Next slide body
[/NATIVE_PPTX]

[NATIVE_DOCX]
TITLE: Document title
SUBTITLE: optional subtitle
HEADING: Section heading
PARAGRAPH: paragraph text
BULLET: bullet text
NUMBER: numbered item
TABLE:
Column A | Column B
Value A | Value B
IMAGE: optional image path
CONTENT:
fallback long-form content
[/NATIVE_DOCX]

[PDF_TO_PPTX]
SOURCE: /path/to/downloaded.pdf
TITLE: Deck title
MAX_PAGES: optional number
[/PDF_TO_PPTX]

LOW-LEVEL BRIDGE TOOLS:
- These are bridge directives, not normal conversation style.
- Prefer natural language unless you need the bridge to execute an action.

[WRITE_FILE]
PATH: file path
CONTENT:
content here
[/WRITE_FILE]

[APPEND_FILE]
PATH: file path
CONTENT:
content here
[/APPEND_FILE]

[DELETE_PATH]
PATH: file or folder path
[/DELETE_PATH]

[MOVE_PATH]
SOURCE: source path
DESTINATION: destination path
[/MOVE_PATH]

[OPEN]
TARGET: app, file, folder, or URL
[/OPEN]

[CLOSE]
TARGET: app name
[/CLOSE]

[HYBRID_ACTIONS]
multiple bridge blocks here
[/HYBRID_ACTIONS]

[WEB_SEARCH]
QUERY: search query
[/WEB_SEARCH]

[WEB_OPEN]
URL: https://example.com or QUERY: search query
[/WEB_OPEN]

[WEB_FETCH]
URL: https://example.com/page or QUERY: search query
MAX_CHARS: optional number
[/WEB_FETCH]

[WEB_BROWSE]
URL: https://example.com or QUERY: search query
OPEN: true
FETCH: true
MAX_CHARS: optional number
[/WEB_BROWSE]

[WEB_HEADLESS]
URL: https://example.com or QUERY: search query
MAX_CHARS: optional number
[/WEB_HEADLESS]

[MCP_SETUP]
NAME: connector name
COMMAND: command
ARGS_JSON: optional JSON array
ENV_JSON: optional JSON object
CONFIG_JSON: optional JSON object
[/MCP_SETUP]

[MCP_APPLY]
DRAFT: path to MCP draft JSON
TARGET: cursor_project/cursor_user/claude_desktop/vscode_project_candidate/custom
PATH: only for custom target
[/MCP_APPLY]

[IDE_OPEN]
PATH: file/folder/project path
LINE: optional line number
APP: optional cursor/code/xcode/finder/default
[/IDE_OPEN]

[IDE_PASTE_RUN]
APP: cursor/windsurf/code/xcode
PROJECT_PATH: optional project folder
RUN_METHOD: paste_then_enter, paste_then_cmd_enter, paste_then_ctrl_enter, or paste_only
VERIFY_COMMAND: optional command to verify after the IDE automation
CODE:
code to paste
[/IDE_PASTE_RUN]
- IDE_PASTE_RUN is real GUI automation. It requires user permission. Use it when the user asks to paste/run code in an IDE.
- Prefer WRITE_FILE plus PROJECT_COMMAND when the user wants reliable file edits and test output. Use IDE_PASTE_RUN only when they specifically want IDE paste/run behavior.

[PROJECT_COMMAND]
CWD: project folder
COMMAND: command to run
[/PROJECT_COMMAND]

[SCHEDULE_TASK]
TITLE: short title
DELAY: 30 seconds, 10 minutes, 2 hours, tomorrow, or at 9:30 pm
TASK:
the full agentic task to run later
[/SCHEDULE_TASK]
- SCHEDULE_TASK lets KIRA sleep in the background and enqueue the task when due. The scheduled run must still use pathways and verify before claiming completion.

[PYTHON]
python code here
[/PYTHON]

SHELL TOOL:
- Preferred command form:
[SHELL]
safe read-only command here
[/SHELL]
- TERMINAL is accepted as an alias for SHELL when the user talks about terminal access.
- You may also output shell/sh/zsh/terminal/bash fenced commands.
- Safe read-only commands run directly.
- Risky commands queue permission.
- Never print a shell command as the final answer when the user's goal is the result.
- If you know the exact command needed, execute it through this tool; do not ask the user to execute it.
- For RAM inspection use:
ps -axo pid=,comm=,rss=,%mem= | sort -nrk 3 | head -15

APPLESCRIPT TOOL:
[APPLESCRIPT]
AppleScript code here
[/APPLESCRIPT]
- Use only when macOS app/UI automation is truly needed.
- Harmless read-only AppleScript queries run directly. UI control or state-changing AppleScript asks permission first.

PUBLIC STYLE:
- Be direct.
- No private thoughts.
- If a command ran, summarize the result and identify the app/process clearly.
- Never answer only with a command or raw tool block.
- If permission is required, ask clearly.
"""
        return (
            template
            .replace("__AGENTIC_WORKSPACE__", self.agentic_workspace)
            .replace("__CHAT_HISTORY__", self.chat_history_path)
            .replace("__MCP_WORKSPACE__", self.mcp_workspace)
            .replace("__ARCHITECT_WORKSPACE__", self.architect_workspace)
            .replace("__IDE_BRIDGE__", self.ide_bridge_path)
            .replace("__ACCESSIBLE_ROOTS__", json.dumps(self.computer_roots, indent=2, ensure_ascii=False))
            .replace("__MCP_TARGETS__", json.dumps(self.mcp_config_targets, indent=2, ensure_ascii=False))
            .replace("__SLASH_SUGGESTIONS__", self.slash_suggestions_path)
            .replace("__LEARNED_QUICK_PATHWAYS__", json.dumps(self._learned_quick_pathways_for_context(), indent=2, ensure_ascii=False))
        )



































































    def _chat_file(self, chat_id):
        safe_id = self._safe_filename(chat_id, "chat")
        return os.path.join(self.chat_history_path, f"{safe_id}.json")

    def _load_chat(self, chat_id):
        path = self._chat_file(chat_id)
        if not os.path.exists(path):
            return {
                "id": chat_id,
                "title": "New Chat",
                "created_at": time.time(),
                "updated_at": time.time(),
                "created_label": self._format_timestamp(time.time()),
                "updated_label": self._format_timestamp(time.time()),
                "messages": []
            }

        try:
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {
                "id": chat_id,
                "title": "Recovered Chat",
                "created_at": time.time(),
                "updated_at": time.time(),
                "created_label": self._format_timestamp(time.time()),
                "updated_label": self._format_timestamp(time.time()),
                "messages": []
            }

    def _save_chat(self, chat):
        chat["updated_at"] = time.time()
        chat["updated_label"] = self._format_timestamp(chat["updated_at"])
        chat["created_label"] = self._format_timestamp(chat.get("created_at", chat["updated_at"]))
        path = self._chat_file(chat["id"])
        with open(path, "w", encoding="utf-8") as f:
            json.dump(chat, f, indent=2, ensure_ascii=False)

    def _load_chat_messages(self, chat_id):
        if not chat_id:
            return []
        return self._load_chat(chat_id).get("messages", [])

    def _append_chat_message(self, chat_id, role, content, model):
        if not chat_id:
            return

        chat = self._load_chat(chat_id)

        if chat.get("title") in ["New Chat", "Recovered Chat"] and role == "user":
            title = re.sub(r"\s+", " ", content).strip()[:48]
            chat["title"] = title or "New Chat"

        chat.setdefault("messages", []).append({
            "id": str(uuid.uuid4()),
            "role": role,
            "content": content,
            "model": model,
            "model_used": model,
            "created_at": time.time(),
            "created_label": self._format_timestamp(time.time())
        })

        self._save_chat(chat)

    def get_chats(self):
        chats = []

        for filename in os.listdir(self.chat_history_path):
            if not filename.endswith(".json"):
                continue

            path = os.path.join(self.chat_history_path, filename)

            try:
                with open(path, "r", encoding="utf-8") as f:
                    chat = json.load(f)

                chats.append({
                    "id": chat.get("id"),
                    "title": chat.get("title", "Untitled"),
                    "updated_at": chat.get("updated_at", 0),
                    "created_at": chat.get("created_at", 0),
                    "updated_label": chat.get("updated_label") or self._format_timestamp(chat.get("updated_at", 0)),
                    "created_label": chat.get("created_label") or self._format_timestamp(chat.get("created_at", 0)),
                    "message_count": len(chat.get("messages", []))
                })
            except Exception:
                continue

        chats.sort(key=lambda item: item.get("updated_at", 0), reverse=True)
        return chats

    def new_chat(self, title="New Chat", *args, **kwargs):
        chat_id = str(uuid.uuid4())
        title = str(title or "New Chat").strip()[:80] or "New Chat"
        chat = {
            "id": chat_id,
            "title": title,
            "created_at": time.time(),
            "updated_at": time.time(),
            "created_label": self._format_timestamp(time.time()),
            "updated_label": self._format_timestamp(time.time()),
            "messages": []
        }
        self._save_chat(chat)
        return chat

    def load_chat(self, chat_id):
        return self._load_chat(chat_id)

    def delete_chat(self, chat_id):
        path = self._chat_file(chat_id)
        if os.path.exists(path):
            os.remove(path)
        return {"status": "deleted", "id": chat_id}

    def rename_chat(self, chat_id, title):
        chat = self._load_chat(chat_id)
        chat["title"] = str(title or "Untitled").strip()[:80]
        self._save_chat(chat)
        return {"status": "renamed", "id": chat_id, "title": chat["title"]}

    def send_prompt(self, prompt, mode="chat", selected_model="orchestrator", chat_id=None):
        if not chat_id:
            chat = self.new_chat()
            chat_id = chat["id"]

        mode_text = str(mode or "chat").lower()
        if self.voice_mode_active or mode_text == "voice":
            try:
                self.record_voice_input(prompt, source=mode_text or "voice")
            except Exception:
                pass

        self.task_queue.put({
            "prompt": prompt,
            "mode": mode,
            "selected_model": selected_model,
            "chat_id": chat_id
        })

        return {"status": "queued", "chat_id": chat_id}

    def shutdown_app(self):
        try:
            self.is_running = False
            try:
                self.set_screen_overlay_state("off")
            except Exception:
                pass
            try:
                self._stop_model_worker()
            except Exception:
                pass

            def _exit_soon():
                time.sleep(0.25)
                os._exit(0)

            threading.Thread(target=_exit_soon, daemon=True).start()
            return {"status": "closing"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    def poll_updates(self):
        updates = []

        while not self.response_queue.empty():
            updates.append(self.response_queue.get_nowait())

        return updates

    def schedule_task(self, prompt, delay_text="60 seconds", mode="agentic", selected_model="orchestrator", chat_id=None, title=""):
        return {
            "status": "scheduled",
            "message": self.schedule_agentic_task(prompt, delay_text, None, mode, selected_model, chat_id, title)
        }


class LazyKiraAPI:
    def __init__(self):
        self._brain = None
        self._booting = False
        self._boot_error = None
        self._lock = threading.Lock()
        self._boot_events = queue.Queue()
        self._local_chat_id = f"boot_{uuid.uuid4()}"
        self._warmup_requested = False

    def start_background(self):
        self._ensure_brain(wait=False)

    def _ensure_brain(self, wait=True):
        with self._lock:
            if self._brain is not None:
                return self._brain
            if self._boot_error is not None:
                raise RuntimeError(self._boot_error)
            if not self._booting:
                self._booting = True
                self._boot_events.put({
                    "type": "status",
                    "content": "Starting KIRA backend..."
                })
                threading.Thread(target=self._boot_worker, daemon=True).start()

        if not wait:
            return None

        while True:
            with self._lock:
                if self._brain is not None:
                    return self._brain
                if self._boot_error is not None:
                    raise RuntimeError(self._boot_error)
            time.sleep(0.02)

    def _boot_worker(self):
        try:
            brain = KiraBrain()
            with self._lock:
                self._brain = brain
                self._booting = False
            self._boot_events.put({
                "type": "status",
                "content": "System Ready"
            })
        except Exception as e:
            error = f"KIRA backend failed to start: {e}"
            with self._lock:
                self._boot_error = error
                self._booting = False
            self._boot_events.put({
                "type": "error",
                "content": error
            })

    def _call(self, method, *args, wait=True, default=None):
        if not wait:
            with self._lock:
                brain = self._brain
                boot_error = self._boot_error
            if brain is None:
                if boot_error:
                    self._boot_events.put({
                        "type": "error",
                        "content": boot_error
                    })
                return default
            return getattr(brain, method)(*args)

        brain = self._ensure_brain(wait=wait)
        if brain is None:
            return default
        return getattr(brain, method)(*args)

    def warm_after_ui_ready(self):
        with self._lock:
            if self._warmup_requested:
                return {"status": "already_scheduled", "done": self._brain is not None}
            self._warmup_requested = True

        def _start_after_first_paint():
            time.sleep(0.75)
            self._ensure_brain(wait=False)

        threading.Thread(target=_start_after_first_paint, daemon=True).start()
        return {"status": "scheduled", "done": False}

    def poll_updates(self):
        updates = []
        while not self._boot_events.empty():
            updates.append(self._boot_events.get_nowait())
        with self._lock:
            brain = self._brain
        if brain is not None:
            updates.extend(brain.poll_updates())
        return updates

    def get_chats(self):
        return self._call("get_chats", wait=False, default=[])

    def new_chat(self, title="New Chat", *args, **kwargs):
        return self._call("new_chat", title, *args, wait=False, default={
            "id": self._local_chat_id,
            "title": str(title or "New Chat"),
            "created_at": time.time(),
            "updated_at": time.time(),
            "messages": []
        })

    def load_chat(self, chat_id):
        return self._call("load_chat", chat_id, wait=False, default={
            "id": chat_id or self._local_chat_id,
            "title": "New Chat",
            "messages": []
        })

    def delete_chat(self, chat_id):
        return self._call("delete_chat", chat_id, wait=False, default={"status": "starting", "id": chat_id})

    def rename_chat(self, chat_id, title):
        return self._call("rename_chat", chat_id, title, wait=False, default={"status": "starting", "id": chat_id, "title": title})

    def send_prompt(self, prompt, mode="chat", selected_model="orchestrator", chat_id=None):
        return self._call("send_prompt", prompt, mode, selected_model, chat_id)

    def get_slash_suggestions(self, query="", context="", *args, **kwargs):
        return self._call("get_slash_suggestions", query, context, *args, wait=False, default=[
            {"command": "/open ", "title": "Open app, file, folder, or URL", "hint": "Backend is starting.", "category": "commands"},
            {"command": "/help", "title": "Explain commands", "hint": "Backend is starting.", "category": "commands"}
        ])

    def get_live_snapshot(self):
        return self._call("get_live_snapshot", wait=False, default={
            "status": "starting",
            "time_label": "",
            "front_app": "Starting...",
            "top_process": {},
            "disk": {"free": 0, "total": 0, "percent_used": 0},
            "queue_depth": 0,
            "pending_permissions": 0,
            "last_agentic_intent": "starting",
            "last_agentic_result": ""
        })

    def get_kira_menu(self, query="", force=False, *args, **kwargs):
        return self._call("get_kira_menu", query, force, *args, wait=False, default={
            "updated_label": "Backend starting",
            "sections": []
        })

    def schedule_task(self, prompt, delay_text="60 seconds", mode="agentic", selected_model="orchestrator", chat_id=None, title=""):
        return self._call(
            "schedule_task",
            prompt,
            delay_text,
            mode,
            selected_model,
            chat_id,
            title,
            wait=False,
            default={"status": "starting", "message": "KIRA backend is starting; try scheduling again in a moment."}
        )

    def get_scheduled_tasks(self):
        return self._call("get_scheduled_tasks", wait=False, default=[])

    def open_menu_target(self, target):
        return self._call("open_menu_target", target)

    def toggle_voice_mode(self, state):
        return self._call("toggle_voice_mode", state)

    def toggle_voice(self, state):
        return self.toggle_voice_mode(state)

    def get_voice_status(self):
        return self._call("get_voice_status", wait=False, default={
            "voice_mode_active": False,
            "voice_ready": False,
            "listen_ready": False,
            "voice_loaded": False,
            "listen_loaded": False,
            "stts_ready": True,
            "stts_silent_test": True,
            "stts_route": "silent_terminal",
            "speech_output": "starting",
            "python_listen_fallback": "starting"
        })

    def listen_once(self):
        return self._call("listen_once")

    def stop_voice(self):
        return self._call("stop_voice", wait=False, default={"ok": True, "status": "starting"})

    def set_screen_overlay_state(self, state="off"):
        return self._call("set_screen_overlay_state", state, wait=False, default={"ok": True, "state": state})

    def approve_pending_tool(self, request_id):
        return self._call("approve_pending_tool", request_id)

    def reject_pending_tool(self, request_id):
        return self._call("reject_pending_tool", request_id)

    def shutdown_app(self):
        with self._lock:
            brain = self._brain
        if brain is not None:
            return brain.shutdown_app()
        os._exit(0)


if __name__ == "__main__":
    os.chdir(BASE_DIR)
    api = LazyKiraAPI()
    if not os.path.exists(os.path.join(BASE_DIR, "ui.html")):
        raise FileNotFoundError(f"KIRA UI not found: {os.path.join(BASE_DIR, 'ui.html')}")
    window = webview.create_window(
        "KIRA OS",
        url="ui.html",
        js_api=api,
        width=1200,
        height=800,
        background_color="#000000"
    )
    print("[System] Opening KIRA UI...", flush=True)
    webview.start()
