# KIRA Executable Local Agentic Harness Results

Score: **75.0 / 100**

This score was produced by running local KIRA OS prototype pathways where possible. It is not an official Harness-Bench score.

The score intentionally reserves points for model-in-loop Orchestrator execution and official external Harness-Bench evaluation, because those were not performed by this harness.

| Category | Earned | Weight | Checks |
| --- | ---: | ---: | ---: |
| Executable local agentic pathways | 45.0 | 45 | 9/9 |
| Agentic pathway coverage | 15.0 | 15 | 13/13 |
| Packaging and model separation | 8.0 | 8 | 5/5 |
| Website release surface | 7.0 | 7 | 6/6 |
| Model-in-loop Orchestrator execution | 0.0 | 15 | 0/1 |
| Official external Harness-Bench | 0.0 | 10 | 0/1 |

Run after installing KIRA OS requirements:

```bash
python3 benchmarks/kira_local_agentic_harness.py
```
