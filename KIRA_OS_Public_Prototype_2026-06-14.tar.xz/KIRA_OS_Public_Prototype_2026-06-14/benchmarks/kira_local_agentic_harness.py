#!/usr/bin/env python3
"""
KIRA Executable Local Agentic Harness

This harness performs local KIRA OS prototype checks. It is deliberately
stricter than a static readiness scan: it runs real local pathways where
possible, then reserves score for model-in-loop and official external
Harness-Bench work that is not executed here.

This is not an official Harness-Bench score.
"""

from __future__ import annotations

import json
import os
import queue
import re
import sys
import tarfile
import tempfile
import threading
import time
from datetime import datetime, timezone
from pathlib import Path


sys.dont_write_bytecode = True

ROOT = Path(__file__).resolve().parents[1]
RESULT_JSON = ROOT / "benchmarks" / "kira_local_agentic_harness_results.json"
RESULT_MD = ROOT / "benchmarks" / "kira_local_agentic_harness_results.md"


def read_text(path: Path) -> str:
    return path.read_text(encoding="utf-8", errors="replace") if path.exists() else ""


def repo_files() -> list[Path]:
    return [
        path
        for path in ROOT.rglob("*")
        if path.is_file() and ".git" not in path.relative_to(ROOT).parts
    ]


def score_category(name: str, weight: int, checks: list[tuple[str, bool, str]]) -> dict:
    passed = sum(1 for _, ok, _ in checks if ok)
    total = len(checks)
    earned = weight * (passed / total) if total else 0
    return {
        "name": name,
        "weight": weight,
        "earned": round(earned, 2),
        "passed": passed,
        "total": total,
        "checks": [
            {"name": check_name, "passed": bool(ok), "detail": str(detail)}
            for check_name, ok, detail in checks
        ],
    }


def extract_path(text: str, suffix: str) -> Path | None:
    pattern = r"`([^`]+\." + re.escape(suffix.lstrip(".")) + r")`"
    match = re.search(pattern, text or "", re.IGNORECASE)
    return Path(match.group(1)) if match else None


def executable_local_pathways() -> dict:
    sys.path.insert(0, str(ROOT))
    try:
        from actions import KiraActionsMixin
    except Exception as exc:
        return score_category(
            "Executable local agentic pathways",
            45,
            [("import actions.py", False, f"import failed: {exc}")],
        )

    class BenchKira(KiraActionsMixin):
        def __init__(self, tmp_root: Path):
            self.app_root = str(ROOT)
            self.home_path = str(tmp_root / "home")
            self.agentic_workspace = str(tmp_root / "kira_agentic_workspace")
            self.agentic_logs_path = str(tmp_root / "kira_agentic_logs")
            self.architect_workspace = str(tmp_root / "kira_technical_architect")
            self.mcp_workspace = str(tmp_root / "kira_mcp_connectors")
            self.ide_bridge_path = str(Path(self.architect_workspace) / "ide_bridge")
            self.computer_map_path = str(tmp_root / "computer_map.json")
            self.artifacts_index_path = str(Path(self.agentic_workspace) / "artifacts.json")
            self.active_chat_id = "bench"
            self.last_artifacts = []
            self.last_artifact_path = ""
            self.response_queue = queue.Queue()
            self.permission_lock = threading.Lock()
            self.permission_counter = 0
            self.pending_permissions = {}
            self.evidence = []
            self.mcp_config_targets = {
                "cursor_project": str(tmp_root / ".cursor" / "mcp.json"),
                "claude_desktop": str(tmp_root / "Claude" / "claude_desktop_config.json"),
            }
            self.computer_roots = {
                "home": self.home_path,
                "downloads": str(Path(self.home_path) / "Downloads"),
                "desktop": str(Path(self.home_path) / "Desktop"),
                "documents": str(Path(self.home_path) / "Documents"),
                "workspace": self.agentic_workspace,
            }
            self.sensitive_path_markers = [
                "/.ssh",
                "/.aws",
                "/.gnupg",
                "/Library/Keychains",
                "/private/var/db",
                "keychain",
            ]
            self.readable_roots = [
                self.home_path,
                self.agentic_workspace,
                self.architect_workspace,
                self.mcp_workspace,
                self.app_root,
                str(tmp_root),
            ]
            for path in [
                self.home_path,
                self.agentic_workspace,
                self.agentic_logs_path,
                self.architect_workspace,
                self.mcp_workspace,
                self.ide_bridge_path,
                *self.computer_roots.values(),
            ]:
                os.makedirs(path, exist_ok=True)

        def _record_execution_evidence(self, *args, **kwargs):
            self.evidence.append({"args": args, "kwargs": kwargs})

        def _load_chat_messages(self, chat_id):
            return []

    checks: list[tuple[str, bool, str]] = []
    with tempfile.TemporaryDirectory(prefix="kira_exec_harness_") as tmp:
        bench = BenchKira(Path(tmp))

        try:
            stripped = bench._strip_private_reasoning("<thought_process>private branch</thought_process>Visible answer.")
            checks.append(("private reasoning stripped", "private branch" not in stripped and "Visible answer" in stripped, stripped))
        except Exception as exc:
            checks.append(("private reasoning stripped", False, exc))

        try:
            profile = bench._seatbelt_profile("read_only", read_paths=[bench.home_path])
            checks.append(("macOS seatbelt profile generated", "(deny default)" in profile and "(allow file-read*" in profile, profile[:160]))
        except Exception as exc:
            checks.append(("macOS seatbelt profile generated", False, exc))

        try:
            pending = bench._queue_permission(
                "delete_path",
                {"path": str(Path(bench.computer_roots["downloads"]) / "remove_me.tmp")},
                "remove_me.tmp",
                chat_id="bench",
            )
            checks.append(("permission queue executes", "Permission required" in pending and len(bench.pending_permissions) == 1, pending))
        except Exception as exc:
            checks.append(("permission queue executes", False, exc))

        try:
            pdf_result = bench._generate_native_pdf(
                "[NATIVE_PDF]\nTITLE: KIRA Benchmark PDF\nCONTENT: Evidence-backed PDF generation.\n[/NATIVE_PDF]"
            )
            pdf_path = extract_path(pdf_result, "pdf")
            checks.append(("native PDF generation executes", bool(pdf_path and pdf_path.exists()), pdf_result))
        except Exception as exc:
            checks.append(("native PDF generation executes", False, exc))

        try:
            docx_result = bench._generate_native_docx(
                "TITLE: KIRA Benchmark DOCX\n"
                "SUBTITLE: Executable local harness\n"
                "PARAGRAPH: This document was generated by the benchmark harness.\n"
                "BULLET: Real file output\n"
                "BULLET: Artifact path recorded"
            )
            docx_path = extract_path(docx_result, "docx")
            checks.append(("native DOCX generation executes", bool(docx_path and docx_path.exists()), docx_result))
        except Exception as exc:
            checks.append(("native DOCX generation executes", False, exc))

        try:
            image_path = Path(bench.agentic_workspace) / "bench_image.png"
            try:
                from PIL import Image, ImageDraw

                image = Image.new("RGB", (720, 420), "#0b0d12")
                draw = ImageDraw.Draw(image)
                draw.ellipse((220, 80, 500, 360), outline="#f2c9a8", width=8)
                draw.text((250, 190), "KIRA", fill="#ffffff")
                image.save(image_path)
                image_line = f"IMAGE: {image_path}"
            except Exception:
                image_line = ""

            pptx_result = bench._generate_native_pptx(
                "TITLE: KIRA Benchmark Deck\n"
                "SUBTITLE: Executable local harness\n"
                "THEME: dark\n"
                "SLIDE: Pathway Evidence\n"
                "BODY: This slide was generated by KIRA OS during the benchmark.\n"
                f"{image_line}\n"
                "SLIDE: Completion Rule\n"
                "BODY: KIRA should verify file paths before claiming completion."
            )
            pptx_path = extract_path(pptx_result, "pptx")
            checks.append(("native PPTX generation executes", bool(pptx_path and pptx_path.exists()), pptx_result))
        except Exception as exc:
            checks.append(("native PPTX generation executes", False, exc))

        try:
            suspicious = Path(bench.computer_roots["downloads"]) / "suspicious_payload.command"
            suspicious.write_text("#!/bin/zsh\necho test\n", encoding="utf-8")
            virus_result = bench._virus_scan_tool("downloads", max_files=20)
            ok = "Virus scan" in virus_result or "AI" in virus_result or "risk" in virus_result.lower()
            checks.append(("read-only virus scan executes", ok, virus_result[:500]))
        except Exception as exc:
            checks.append(("read-only virus scan executes", False, exc))

        try:
            archive = Path(bench.computer_roots["downloads"]) / "old_installer.zip"
            archive.write_bytes(b"0" * 1024)
            optimise_result = bench._optimise_scan_tool()
            ok = "optim" in optimise_result.lower() or "storage" in optimise_result.lower() or "candidate" in optimise_result.lower()
            checks.append(("read-only optimise scan executes", ok, optimise_result[:500]))
        except Exception as exc:
            checks.append(("read-only optimise scan executes", False, exc))

        try:
            latest = bench._latest_artifact({".pptx", ".docx", ".pdf"}, chat_id="bench")
            checks.append(("artifact index records generated files", bool(latest and Path(latest).exists()), latest or "missing"))
        except Exception as exc:
            checks.append(("artifact index records generated files", False, exc))

    return score_category("Executable local agentic pathways", 45, checks)


def pathway_surface() -> dict:
    actions = read_text(ROOT / "actions.py")
    interface = read_text(ROOT / "interface.py")
    code = actions + "\n" + interface
    markers = {
        "open app/file/url": "_open_target_tool",
        "web search": "_web_search_tool",
        "web fetch": "_web_fetch_tool",
        "headless browser": "_headless_browser_dump_dom",
        "IDE context": "_ide_context_tool",
        "IDE connect": "_connect_ide_tool",
        "MCP discover": "_mcp_discover_tool",
        "MCP bootstrap": "_mcp_bootstrap_tool",
        "virus scan": "_virus_scan_tool",
        "optimise scan": "_optimise_scan_tool",
        "latest artifact lookup": "_latest_artifact",
        "council routing": "_run_council_roles_parallel",
        "background task language": "schedule delayed tasks",
    }
    return score_category("Agentic pathway coverage", 15, [(label, marker in code, marker) for label, marker in markers.items()])


def packaging_and_model_split() -> dict:
    readme = read_text(ROOT / "README.md")
    model_setup = read_text(ROOT / "MODEL_SETUP.md")
    model_stub = read_text(ROOT / "orchestrator_v1_fused" / "README.md")
    combined = "\n".join([readme, model_setup, model_stub])
    files = repo_files()
    rels = [str(path.relative_to(ROOT)) for path in files]
    dist_archives = sorted((ROOT / "dist").glob("*.tar.xz"))
    running_unpacked_package = ROOT.name.startswith("KIRA_OS_Public_Prototype")
    archive_ok = (
        running_unpacked_package
        or (bool(dist_archives) and all(path.stat().st_size < 25 * 1024 * 1024 for path in dist_archives))
    )
    forbidden_suffixes = {".safetensors", ".bin", ".gguf", ".jsonl"}
    forbidden_parts = {"venv", "kira_memory", "kira_os_fused", "kira_v1_fused"}
    forbidden_hits = [
        rel
        for rel in rels
        if Path(rel).suffix.lower() in forbidden_suffixes
        or any(part in forbidden_parts for part in Path(rel).parts)
    ]
    tar_ok = running_unpacked_package
    if dist_archives:
        try:
            with tarfile.open(dist_archives[0], "r:xz") as archive:
                names = archive.getnames()
            tar_ok = not [
                name for name in names
                if Path(name).suffix.lower() in forbidden_suffixes
                or any(part in forbidden_parts for part in Path(name).parts)
            ]
        except Exception:
            tar_ok = False

    return score_category(
        "Packaging and model separation",
        8,
        [
            ("compact package or unpacked release context", archive_ok, f"{len(dist_archives)} archive(s)"),
            ("no model weights/private stores bundled", not forbidden_hits, ", ".join(forbidden_hits[:8]) or "clean"),
            ("archive excludes model/private files", tar_ok, "clean or unpacked context"),
            ("Orchestrator download link documented", "https://huggingface.co/saggamer/Orchestrator_V1" in combined, "HF link"),
            ("model folder pairing documented", "orchestrator_v1_fused" in combined and "separately" in readme.lower(), "separate model/runtime flow"),
        ],
    )


def website_release_surface() -> dict:
    site = read_text(ROOT / "kira_os_site" / "index.html")
    docs = read_text(ROOT / "docs" / "index.html")
    combined = site + "\n" + docs
    return score_category(
        "Website release surface",
        7,
        [
            ("black hole background wired", "interstellar_blackhole.jpg" in combined and "cosmic-bg" in combined, "hero background"),
            ("GitHub repo link present", "https://github.com/saggamer/KIRA-OS" in combined, "repo"),
            ("Hugging Face model link present", "https://huggingface.co/saggamer/Orchestrator_V1" in combined, "model"),
            ("author X link present", "https://x.com/saggamer2241" in combined, "X"),
            ("author Instagram link present", "https://www.instagram.com/true_gamerz_inc/" in combined, "Instagram"),
            ("benchmark disclaimer present", "official Harness-Bench" in combined and "pending" in combined, "disclaimer"),
        ],
    )


def model_in_loop_pending() -> dict:
    return score_category(
        "Model-in-loop Orchestrator execution",
        15,
        [
            (
                "load Orchestrator V1 weights and run tool-selection tasks",
                False,
                "not run in this public-package harness; requires local Orchestrator weights and VRAM",
            )
        ],
    )


def official_harness_pending() -> dict:
    return score_category(
        "Official external Harness-Bench",
        10,
        [
            (
                "run KIRA OS through official Harness-Bench evaluator",
                False,
                "pending; do not treat this local score as an official Harness-Bench result",
            )
        ],
    )


def main() -> int:
    categories = [
        executable_local_pathways(),
        pathway_surface(),
        packaging_and_model_split(),
        website_release_surface(),
        model_in_loop_pending(),
        official_harness_pending(),
    ]
    score = round(sum(item["earned"] for item in categories), 2)
    result = {
        "benchmark": "KIRA Executable Local Agentic Harness",
        "version": "2026-06-15",
        "score": score,
        "max_score": 100,
        "score_type": "performed local executable prototype benchmark",
        "official_harness_bench": "pending",
        "model_in_loop": "pending",
        "summary": (
            "Runs real local KIRA pathways where possible, verifies static pathway coverage and public "
            "release surfaces, and reserves points for Orchestrator model-in-loop plus official external "
            "Harness-Bench work that was not run here."
        ),
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "python": sys.executable,
        "categories": categories,
    }
    RESULT_JSON.write_text(json.dumps(result, indent=2), encoding="utf-8")

    lines = [
        "# KIRA Executable Local Agentic Harness Results",
        "",
        f"Score: **{score} / 100**",
        "",
        "This score was produced by running local KIRA OS prototype pathways where possible. It is not an official Harness-Bench score.",
        "",
        "The score intentionally reserves points for model-in-loop Orchestrator execution and official external Harness-Bench evaluation, because those were not performed by this harness.",
        "",
        "| Category | Earned | Weight | Checks |",
        "| --- | ---: | ---: | ---: |",
    ]
    for category in categories:
        lines.append(
            f"| {category['name']} | {category['earned']} | {category['weight']} | {category['passed']}/{category['total']} |"
        )
    lines.extend([
        "",
        "Run after installing KIRA OS requirements:",
        "",
        "```bash",
        "python3 benchmarks/kira_local_agentic_harness.py",
        "```",
    ])
    RESULT_MD.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps({"score": score, "result": str(RESULT_JSON.relative_to(ROOT))}, indent=2))
    return 0 if score >= 70 else 1


if __name__ == "__main__":
    raise SystemExit(main())
