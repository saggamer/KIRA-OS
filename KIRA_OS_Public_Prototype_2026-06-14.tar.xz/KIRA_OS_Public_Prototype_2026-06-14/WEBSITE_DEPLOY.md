# Website Deploy Notes

The public website is a static site in:

```text
kira_os_site/
```

For GitHub Pages, the same static site is also copied to:

```text
docs/
```

Recommended setup:

```text
Settings -> Pages -> Build and deployment -> Deploy from a branch
Branch: main
Folder: /docs
```

It can be deployed from any static host. The repository buttons currently point to:

```text
https://github.com/saggamer/KIRA-OS
https://github.com/saggamer/KIRA-OS/releases/latest
```

Current public model link:

https://huggingface.co/saggamer/Orchestrator_V1

A custom domain such as `kiraos.com` requires buying or owning the domain and pointing DNS to the chosen host. The static website itself does not require a paid server.
