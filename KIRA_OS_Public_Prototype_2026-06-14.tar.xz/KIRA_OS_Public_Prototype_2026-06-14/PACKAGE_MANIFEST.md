# Package Manifest

## Included Runtime Files

- `interface.py`
- `actions.py`
- `voice.py`
- `listen.py`
- `vision.py`
- `memory.py`
- `ui.html`
- `commands.json`
- `assets/kira_logo_sample4.png`
- `assets/kira_logo_icon.png`
- `kira_mcp_connectors/kira_filesystem_bridge.mcp.json`

## Included Website Files

- `kira_os_site/index.html`
- `kira_os_site/assets/kira_logo_sample4.png`
- `kira_os_site/assets/interstellar_blackhole.jpg`

## GitHub Pages Website Files

- `docs/index.html`
- `docs/assets/kira_logo_sample4.png`
- `docs/assets/interstellar_blackhole.jpg`

## Benchmark Files

- `benchmarks/kira_local_agentic_harness.py`
- `benchmarks/kira_local_agentic_harness_results.json`
- `benchmarks/kira_local_agentic_harness_results.md`

## Repository

- `https://github.com/saggamer/KIRA-OS`

## Author Links

- X: `https://x.com/saggamer2241`
- Instagram: `https://www.instagram.com/true_gamerz_inc/`

## Packaged Download

- `dist/KIRA_OS_Public_Prototype_2026-06-14.tar.xz`

The `.tar.xz` archive is used because it is much smaller than the original zip package.

## Included Empty Runtime Folders

- `orchestrator_v1_fused/`
- `kira_agentic_workspace/`
- `kira_agentic_logs/`
- `kira_chat_history/`
- `kira_technical_architect/ide_bridge/`

## Excluded On Purpose

- Orchestrator V1 weights. Download them from Hugging Face.
- Kira V1 weights and Kira V1 training files.
- personal memory, chat history, and personalization data.
- generated smoke-test PPTX/DOCX/PDF artifacts.
- virtual environments and Python caches.
- private benchmark logs and local-only app state.
