# Orchestrator V1 Setup

KIRA OS expects Orchestrator V1 in this local folder:

```text
orchestrator_v1_fused/
```

Recommended files:

```text
config.json
generation_config.json
tokenizer.json
tokenizer_config.json
chat_template.jinja
model.safetensors
model.safetensors.index.json
README.md
```

You can download the model from:

https://huggingface.co/saggamer/Orchestrator_V1

If the app starts before the model is present, the UI can still open, but generation will not work until the model folder is populated.
