# KIRA OS Prototype

KIRA OS is a local agentic desktop environment built for Orchestrator V1. It gives the model controlled pathways for desktop inspection, app opening, web workflows, document generation, PPTX generation, IDE/MCP planning, permission-gated actions, and evidence-based completion.

This package contains the public prototype runtime and website. It intentionally does not include private chat history, memory databases, training datasets, virtual environments, generated smoke-test files, Kira V1 weights, or Orchestrator V1 model weights.

People should download KIRA OS from this repository and download Orchestrator V1 separately from Hugging Face. Put the Orchestrator V1 files into `orchestrator_v1_fused/`, then run KIRA OS locally. That keeps the app package small while letting the same public model power the local agentic environment.

Repository:

https://github.com/saggamer/KIRA-OS

## Included

- `interface.py` - main PyWebView app bridge and model routing.
- `actions.py` - agentic actions, artifact generation, web/file/app pathways, permissions, and sandbox helpers.
- `voice.py` - voice/live-mode bridge with silent STT/TTS logging fallback.
- `ui.html` - KIRA OS desktop UI.
- `assets/` - app logo assets.
- `kira_os_site/` - public static website.
- `kira_mcp_connectors/` - connector template area.
- Empty runtime folders for artifacts, logs, chat history, and IDE bridge state.

## Not Included

- `orchestrator_v1_fused/model.safetensors`
- Kira V1 model folders
- training datasets
- personal memory / personalization files
- chat history
- generated reports and PPTX smoke tests
- `venv/`, `__pycache__/`, `.DS_Store`

## Model

Download Orchestrator V1 from Hugging Face:

https://huggingface.co/saggamer/Orchestrator_V1

Place the model files inside:

```text
orchestrator_v1_fused/
```

The app expects at least the model weights, tokenizer files, config files, generation config, and chat template in that folder.

## Pairing KIRA OS With Orchestrator V1

KIRA OS and Orchestrator V1 are intentionally split:

- KIRA OS is the desktop app, UI, agentic pathways, permissions, artifact generation, web/IDE/MCP bridges, and local proof layer.
- Orchestrator V1 is the model brain. It should be downloaded from Hugging Face and placed in `orchestrator_v1_fused/`.
- KIRA OS can boot without bundling model weights, but full model responses require the Orchestrator V1 folder to contain the downloaded weights and tokenizer/config files.
- This repository should stay lightweight. Do not commit Orchestrator weights, Kira V1 weights, training datasets, private memory, chat history, generated smoke tests, or local virtual environments.

## Quick Start

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 interface.py
```

To preview the website:

```bash
cd kira_os_site
python3 -m http.server 8777
```

Then open:

```text
http://127.0.0.1:8777/
```

## Website

The public website is included twice:

- `kira_os_site/` for local preview and editing.
- `docs/` for GitHub Pages deployment.

Recommended free hosting: GitHub Pages from the `main` branch and `/docs` folder.

## Compact Package

A compact archive is included at:

```text
dist/KIRA_OS_Public_Prototype_2026-06-14.tar.xz
```

This archive is kept small by excluding model weights, private memory, training data, generated artifacts, and unused website image formats.

## Benchmark

KIRA OS includes an executable local prototype harness:

```bash
python3 benchmarks/kira_local_agentic_harness.py
```

Current local score: **75 / 100** for the KIRA OS + Orchestrator V1 prototype environment.

This harness actually runs local KIRA pathways where possible: private reasoning stripping, macOS sandbox profile generation, permission queueing, native PDF generation, native DOCX generation, native PPTX generation with an image, read-only AI virus scanning, read-only optimisation scanning, and artifact indexing.

The score intentionally reserves points for Orchestrator model-in-loop execution and official external Harness-Bench evaluation, because those are not performed by this public-package harness.

This is not an official Harness-Bench result. Official external Harness-Bench submission is pending.

## Author

Follow the project:

- X: https://x.com/saggamer2241
- Instagram: https://www.instagram.com/true_gamerz_inc/

## Safety Model

KIRA OS is designed around read-first agentic behavior. Read-only inspection, generated artifacts, and app/file opening can happen directly. Risky actions such as deletion, moving files, writing outside the workspace, installs, broad automation, or sensitive-path access should request explicit user approval and return evidence of what happened.

## Prototype Status

This is a prototype release package. Treat it as a developer-facing local agentic environment, not a polished installer.
