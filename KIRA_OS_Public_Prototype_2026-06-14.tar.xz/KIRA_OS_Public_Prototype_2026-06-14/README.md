# KIRA OS Prototype

KIRA OS is a local agentic desktop environment built for Orchestrator V1. It gives the model controlled pathways for desktop inspection, app opening, web workflows, document generation, PPTX generation, IDE/MCP planning, permission-gated actions, and evidence-based completion.

This package contains the public prototype runtime and website. It intentionally does not include private chat history, memory databases, training datasets, virtual environments, generated smoke-test files, Kira V1 weights, or Orchestrator V1 model weights.

Repository:

https://github.com/saggamer/KIRA-OS

## Included

- `interface.py` - main PyWebView app bridge and model routing.
- `actions.py` - agentic actions, artifact generation, web/file/app pathways, permissions, and sandbox helpers.
- `voice.py` - voice/live-mode bridge with silent STT/TTS logging fallback.
- `ui.html` - KIRA OS desktop UI.
- `assets/` - app logo assets.
- `kira_os_site/` - public static website.
- `kira_mcp_connectors/` - connector template area.
- Empty runtime folders for artifacts, logs, chat history, and IDE bridge state.

## Not Included

- `orchestrator_v1_fused/model.safetensors`
- Kira V1 model folders
- training datasets
- personal memory / personalization files
- chat history
- generated reports and PPTX smoke tests
- `venv/`, `__pycache__/`, `.DS_Store`

## Model

Download Orchestrator V1 from Hugging Face:

https://huggingface.co/saggamer/Orchestrator_V1

Place the model files inside:

```text
orchestrator_v1_fused/
```

The app expects at least the model weights, tokenizer files, config files, generation config, and chat template in that folder.

## Quick Start

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python3 interface.py
```

To preview the website:

```bash
cd kira_os_site
python3 -m http.server 8777
```

Then open:

```text
http://127.0.0.1:8777/
```

## Website

The public website is included twice:

- `kira_os_site/` for local preview and editing.
- `docs/` for GitHub Pages deployment.

Recommended free hosting: GitHub Pages from the `main` branch and `/docs` folder.

## Safety Model

KIRA OS is designed around read-first agentic behavior. Read-only inspection, generated artifacts, and app/file opening can happen directly. Risky actions such as deletion, moving files, writing outside the workspace, installs, broad automation, or sensitive-path access should request explicit user approval and return evidence of what happened.

## Prototype Status

This is a prototype release package. Treat it as a developer-facing local agentic environment, not a polished installer.
